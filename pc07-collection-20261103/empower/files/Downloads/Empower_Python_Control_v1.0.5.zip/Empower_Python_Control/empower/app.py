"""Qt frontend bridge; no blocking device I/O runs in the GUI thread."""
import argparse
import sys
from PySide6.QtCore import QObject, Signal, Slot, QTimer
from PySide6.QtWidgets import QApplication, QMessageBox
from . import __version__
from .gui import MainWindow
from .controller import SessionController


class Bridge(QObject):
    event = Signal(str, object)

    def __init__(self, window, log_directory=None):
        super().__init__(window)
        self.window = window
        self.closing = False
        self.event.connect(self.dispatch)
        self.controller = SessionController(self.event.emit, log_directory)
        window.connect_requested.connect(lambda port: self.controller.submit("connect", port))
        window.disconnect_requested.connect(lambda: self.controller.submit("disconnect"))
        window.action_requested.connect(self.controller.submit)
        window.closeRequested.connect(self.close)

    @Slot(str, object)
    def dispatch(self, kind, value):
        if kind == "snapshot":
            self.window.update_snapshot(value)
        elif kind == "action_result":
            self.window.action_result(value)
        elif kind == "connection":
            self.window.set_connection(*value)
        elif kind == "log":
            self.window.append_log(value)
        elif kind in ("error", "warning"):
            self.window.statusBar().showMessage(str(value), 15000)
            # Nonmodal errors leave STOP available. Logs retain full details.
            self.window.append_log(kind.upper() + ": " + str(value))
        elif kind == "ended":
            if not value:
                QMessageBox.warning(self.window, "Output state unconfirmed",
                                    "Communication could not confirm that the laser stopped.\n"
                                    "Use the physical keyswitch/interlock before leaving the system.")
            self.window.allow_close = True
            self.window.close()

    @Slot()
    def close(self):
        if not self.closing:
            self.closing = True
            self.window.statusBar().showMessage("Sending STOP and closing the connection…")
            self.controller.submit("shutdown")


def main(argv=None):
    parser = argparse.ArgumentParser(description="Empower Python Control")
    parser.add_argument("--demo", action="store_true", help="Connect the built-in simulator")
    parser.add_argument("--log-dir", help="Override the per-session log directory")
    parser.add_argument("--version", action="version", version=__version__)
    args = parser.parse_args(argv)
    app = QApplication(sys.argv[:1])
    app.setApplicationName("Empower Python Control")
    app.setApplicationVersion(__version__)
    window = MainWindow()
    bridge = Bridge(window, args.log_dir)
    window._bridge = bridge  # retain signal and worker ownership
    window.show()
    if args.demo:
        QTimer.singleShot(0, lambda: bridge.controller.submit("connect", "SIMULATOR"))
    app.exec()
    # Normal exit is signalled only after the worker has closed the port.
    if bridge.controller.thread.is_alive():
        bridge.controller.submit("shutdown")
        bridge.controller.thread.join(timeout=5)


if __name__ == "__main__":
    main()
