"""Synchronous device logic. Called only by the session's single worker."""
from __future__ import annotations
import math
import time
from collections import deque
from copy import deepcopy
from . import commands as c
from .responses import parse_response
from .framing import ProtocolError, decode
from .sessionlog import timestamp


class SettingReadbackWarning(Exception):
    """Validated setting response differs without establishing a link failure."""


class CurrentReadbackWarning(SettingReadbackWarning):
    """Valid current ACK differs; the serial connection is still healthy."""


class ServiceReadbackWarning(SettingReadbackWarning):
    """A service change is unconfirmed; do not retry or invent acceptance."""


class ActionCancelled(ValueError):
    """Pending explicit STOP/exit or authorization withdrawal cancelled work."""


class Device:
    def __init__(self, transport, simulated=False, clock=time.monotonic):
        self.transport = transport
        self.clock = clock
        self.enabled = False
        self.service_enabled = False
        self.last_status = None
        self.lbo_samples = deque(maxlen=180)
        self.last_lbo_sample = -float("inf")
        self.lbo_enabled = True
        self.lbo_fault = False
        self.interrupt_poll = lambda: False
        self.interrupt_write = lambda service=False: False
        self._rx_checksum_mode = None
        self._unavailable_reads = {
            "Soft-start readout": "No nonmutating soft-start query is established; "
            "confirm explicit Service soft-start configuration before RUN."
        }
        self._service_setting_warnings = {}
        self.data = {
            "connected": True, "simulated": simulated, "comm_ok": False,
            "state": "UNKNOWN", "emission": None, "faults": [], "service": {
                "soft_start": "Unconfirmed; explicit configuration required",
                "soft_start_enabled": None, "soft_start_rate_a_s": None,
            },
        }

    def snapshot(self):
        result = deepcopy(self.data)
        result["setting_warning"] = "\n".join(filter(None, (
            self.data.get("setting_warning"), self.data.get("service_setting_warning"))))
        result["timestamp"] = timestamp()
        result["control_enabled"] = self.enabled
        result["service_enabled"] = self.service_enabled and self.enabled
        age = None if self.last_status is None else max(0.0, self.clock() - self.last_status)
        result["status_age_s"] = age
        result["status_fresh"] = bool(self.data["comm_ok"] and age is not None and age <= 3.0)
        result["compatibility"] = ("Unavailable: " + "; ".join(self._unavailable_reads) + ". See communication log.") if self._unavailable_reads else "No unavailable optional readouts detected"
        result["compatibility_details"] = "; ".join(self._unavailable_reads.values())
        result["rx_checksum"] = ("Additive checksum verified" if self._rx_checksum_mode is True else
                                 "Legacy response layout (checksum unconfirmed)" if self._rx_checksum_mode is False else
                                 "Response layout unconfirmed")
        result["service"]["lbo_stability_enabled"] = self.lbo_enabled
        result["service"]["lbo_monitor"] = (
            "FAULT — STOP requested" if self.lbo_fault else
            (f"Warming up {len(self.lbo_samples)}/180 samples" if len(self.lbo_samples) < 180 else "Monitoring: 180 / 10 sample means; at least 1 s spacing")
        ) if self.lbo_enabled else "Disabled"
        if self.lbo_fault:
            result["faults"] = list(result["faults"]) + ["LBO stability (host monitor)"]
            result["state"] = "FAULT"
        return result

    def _validate_frame(self, frame):
        # The supplied real log settles this session's framing: 12-byte firmware
        # response and a trailing additive checksum (FW 1.2 in the capture).
        # Keep legacy synthetic/no-checksum layouts usable without imposing a
        # claim that every revision has the same response format.
        if self._rx_checksum_mode is None and frame.opcode == 0x62:
            if len(frame.raw) == 12:
                decode(frame.raw, verify_checksum=True)
                self._rx_checksum_mode = True
            elif len(frame.raw) == 11:
                self._rx_checksum_mode = False
            else:
                raise ProtocolError(
                    "Unsupported firmware response layout: expected 11 legacy or 12 checksummed bytes; "
                    f"got {len(frame.raw)}")
        if self._rx_checksum_mode:
            decode(frame.raw, verify_checksum=True)
            minimum = {0x11: 30, 0x12: 30, 0x62: 12, 0x72: 10,
                       0x1A: 14, 0x69: 11, 0x70: 21, 0x73: 11,
                       0x75: 9}.get(frame.opcode)
            if minimum is not None and len(frame.raw) < minimum:
                raise ProtocolError(f"Checksummed response 0x{frame.opcode:02X} requires at least {minimum} bytes; got {len(frame.raw)}")

    def _merge(self, frame):
        self._validate_frame(frame)
        updates = parse_response(frame, self.data.get("firmware_tuple"))
        if "state" in updates and updates["state"] != self.data.get("state"):
            # A power sample from the previous operating state is no longer a
            # current readout. The independent optional query can refresh it.
            self.data["power_w"] = None
        self.data["service"].update(updates.pop("service", {}))
        # Preserve raw source0: a previous EXTERNAL readback does not establish
        # that a later0 is still EXTERNAL or safe for normal RUN.
        self.data.update(updates)
        if frame.opcode in (0x11, 0x12):
            self.last_status = self.clock()
            self.data["comm_ok"] = True

    def _query(self, raw, expected):
        self._merge(self.transport.exchange(raw, expected))

    def _optional_read(self, name, packet, expected, unavailable):
        """A missing optional readout is not evidence that status I/O failed.

        Only the observed opaque 0x18 response is explicitly accepted as an
        alternative. It is never decoded as soft start or power. A timeout or
        this alternative must be followed by a successful required status
        query. Bad checksums and malformed expected responses remain errors.
        """
        if name in self._unavailable_reads:
            return False
        try:
            frame = self.transport.exchange(packet, (*expected, 0x18))
        except TimeoutError as error:
            detail = str(error)
        else:
            self._validate_frame(frame)
            if frame.opcode in expected:
                self._merge(frame)
                return True
            detail = f"request 0x{packet[5]:02X} received opaque 0x18, not " + "/".join(f"0x{x:02X}" for x in expected)
        # A genuine cable/status failure still ends the connection. No repeated
        # optional probes in the same session and no automatic configuration.
        if self.interrupt_poll():
            return False
        self._query(c.query_status(), (0x11, 0x12))
        self._unavailable_reads[name] = f"{name} unavailable: {detail}"
        self.data["service"].update(unavailable.get("service", {}))
        self.data.update({key: value for key, value in unavailable.items() if key != "service"})
        return False

    def _read_power(self):
        return self._optional_read("Optical power readout", c.query_power(), (0x72,), {"power_w": None})

    def initialize(self):
        # Mirrors the original blank-field service read; firmware semantics are
        # inferred from original startup, explicitly recorded in PROTOCOL.md.
        for packet, expected in ((c.query_firmware(), (0x62,)),
                                 (c.query_status(), (0x11, 0x12)),
                                 (c.query_qswitch(), (0x75,)),
                                 (c.service_read(), (0x70,))):
            if self.interrupt_poll():
                raise ActionCancelled("Connection initialization cancelled by STOP, disconnect or exit")
            self._query(packet, expected)
        self.poll()
        if self.interrupt_poll():
            raise ActionCancelled("Connection initialization cancelled by STOP, disconnect or exit")

    def poll(self):
        for packet, expected in ((c.query_status(), (0x11, 0x12)),
                                 (c.query_qswitch(), (0x75,)),
                                 (c.query_lbo(), (0x1A,))):
            if self.interrupt_poll():
                return
            self._query(packet, expected)
        if self.interrupt_poll():
            return
        self._read_power()
        if self.clock() - self.last_lbo_sample >= 1.0:
            self.last_lbo_sample = self.clock()
            if self.lbo_enabled:
                self.lbo_samples.append(self.data["service"]["lbo_temp_c"])
                # Do not seed synthetic zero temperatures as the legacy GUI
                # did; collect a complete measured baseline before comparing.
                if len(self.lbo_samples) == 180:
                    values = list(self.lbo_samples)
                    if abs(sum(values) / 180 - sum(values[-10:]) / 10) > 1.0:
                        if not self.lbo_fault:
                            self.lbo_fault = True
                            self.enabled = False
                            self.service_enabled = False
                            self._stop_and_confirm()

    def _fresh(self):
        if (not self.data["comm_ok"] or self.last_status is None
                or self.clock() - self.last_status > 3.0):
            raise ValueError("A fresh device status is required; reconnect or wait for polling")

    def _control(self, stopped=False):
        if not self.enabled:
            raise ValueError("Enable session control first")
        self._fresh()
        if stopped:
            self._query(c.query_status(), (0x11, 0x12))
        if stopped and self.data["state"] != "STOP":
            raise ValueError("Stop the laser and wait for confirmed STOP before this change")

    @staticmethod
    def _number(value, lo, hi, name):
        if isinstance(value, bool):
            raise ValueError(f"{name}: a numeric value is required")
        value = float(value)
        if not math.isfinite(value) or not lo <= value <= hi:
            raise ValueError(f"{name} must be in {lo:g}..{hi:g}")
        return value

    def _before_write(self, *, service=False):
        if self.interrupt_poll() or self.interrupt_write(service):
            raise ActionCancelled("Write cancelled by STOP, disconnect, exit or withdrawn authorization")

    def _stop_and_confirm(self):
        self.data["power_w"] = None
        self.transport.send(c.set_run(False))
        self._query(c.query_status(), (0x11, 0x12))
        if self.data["state"] not in ("STOP", "FAULT"):
            raise ProtocolError("STOP sent but stopped state is unconfirmed; use physical controls")

    def _operating(self, current_word=None, frequency_word=None, width_word=None, require_stop=False):
        # Refresh all combined-packet fields immediately before preserving them.
        self._query(c.query_status(), (0x11, 0x12))
        if current_word is not None and (
                self.data["state"] not in ("STOP", "RUN", "COUNTDOWN")
                or self.data.get("faults") or self.data.get("unknown_status_bits")
                or self.lbo_fault):
            raise ValueError(
                "Current change blocked by device fault or unconfirmed state. "
                "Correct the fault first; STOP and status monitoring remain available."
            )
        if require_stop and self.data["state"] != "STOP":
            raise ValueError("STOP is required for service operating changes")
        raw = dict(self.data["_raw_status_fields"])
        desired = {"current_word": current_word, "frequency_word": frequency_word, "width_word": width_word}
        raw.update({key: value for key, value in desired.items() if value is not None})
        self._before_write(service=require_stop)
        if current_word is not None:
            self.data["current_request_a"] = current_word / 10
        self._query(c.set_operating_words(**raw), (0x11, 0x12))
        actual = self.data["_raw_status_fields"]
        different = [key for key, value in raw.items() if actual[key] != value]
        if different:
            # A complete, validated ACK is evidence of communication, not of
            # an applied requested value. FW1.2 has returned12.5A for a14.5A
            # action. The original application did not STOP/close on this.
            # Limit the nonfatal path to current-only differences in a known,
            # fault-free state and within the confirmed device maximum.
            maximum = self.data.get("max_current_a")
            if (current_word is not None and different == ["current_word"]
                    and maximum is not None
                    and 0 <= actual["current_word"] / 10 <= maximum
                    and self.data["state"] in ("STOP", "RUN", "COUNTDOWN")
                    and not self.data.get("faults")
                    and not self.data.get("unknown_status_bits") and not self.lbo_fault):
                message = (
                    f"Last current write unconfirmed: requested {current_word / 10:.1f} A; "
                    f"controller replied {actual['current_word'] / 10:.1f} A. "
                    "Live monitoring continues; no automatic retry."
                )
                self.data["setting_warning"] = message
                raise CurrentReadbackWarning(message)
            detail = "; ".join(f"{key}: requested {raw[key]}, read {actual[key]}" for key in different)
            raise ProtocolError(f"Operating settings readback differs ({detail}); no write was retried")
        if current_word is not None:
            self.data["setting_warning"] = ""

    def action(self, name, value=None):
        if name == "enable_control":
            if value:
                self._fresh()
            self.enabled = bool(value)
            if not self.enabled:
                self.service_enabled = False
            return
        if name == "enable_service":
            if value:
                self._control()
            self.service_enabled = bool(value)
            return
        if name == "stop":
            # STOP is available without session arming and despite faults.
            self._stop_and_confirm()
            return
        if name == "sim_fault" and self.data["simulated"]:
            self.transport.inject_fault(value)
            self.poll()
            return
        if name == "sim_clear" and self.data["simulated"]:
            self.transport.clear_faults()
            self.lbo_fault = False
            self.lbo_samples.clear()
            self.enabled = True
            self.poll()
            return
        if name == "refresh":
            self._query(c.service_read(), (0x70,))
            self.poll()
            return
        self._control()
        if name == "run":
            # Re-read state rather than trusting status from before the hold.
            self._query(c.query_status(), (0x11, 0x12))
            self._query(c.query_qswitch(), (0x75,))
            if self.data.get("firmware_tuple") is None:
                raise ValueError("Known firmware readback is required before RUN")
            if self.data["state"] != "STOP" or self.data["faults"] or self.lbo_fault:
                raise ValueError("RUN requires confirmed STOP and no active fault")
            if self.data.get("unknown_status_bits"):
                raise ValueError("Unknown status bits present; review raw status before RUN")
            if self.data.get("qswitch") not in (2, 3):
                raise ValueError("Select INTERNAL or EXTERNAL Q-switch before RUN")
            if not self.data["service"].get("underfrequency_enabled", False):
                raise ValueError("Enable underfrequency protection before normal RUN")
            if not self.data["service"].get("soft_start_enabled", False):
                raise ValueError("Softstart is unconfirmed or disabled. Use Service > Apply original soft start and require its confirmation before RUN")
            maximum = self.data.get("max_current_a")
            current = self.data.get("current_set_a")
            if maximum is None or current is None or maximum <= 0 or not 0 <= current <= maximum:
                raise ValueError("Valid current setpoint and device maximum readback are required")
            self._before_write()
            self.transport.send(c.set_run(True))
            self._query(c.query_status(), (0x11, 0x12))
            if self.data["state"] not in ("COUNTDOWN", "RUN"):
                raise ProtocolError("RUN not confirmed by instrument status; it was not retried")
        elif name == "set_current":
            self._query(c.service_read(), (0x70,))
            maximum = self.data.get("max_current_a", 0)
            current = self._number(value, 0, maximum, "Current (A)")
            word = round(current * 10)
            if abs(current * 10 - word) > 1e-7:
                raise ValueError("Current resolution is 0.1 A")
            self._operating(current_word=word)
        elif name == "set_qswitch":
            self._control(stopped=True)
            if type(value) is not int or value not in (1, 2, 3):
                raise ValueError("Q-switch source must be 1 HOLD OFF, 2 INTERNAL or 3 EXTERNAL")
            if value == 1 and not self.service_enabled:
                raise ValueError("HOLD OFF is a service-only setting")
            self._before_write(service=value == 1)
            self.transport.send(c.set_qswitch(value))
            self._query(c.query_qswitch(), (0x75,))
            if self.data["qswitch"] != value:
                raise ProtocolError("Q-switch readback mismatch")
            self._query(c.query_status(), (0x11, 0x12))
        elif name == "reset":
            # Original RESET is0x09. It does not configure underfrequency53.
            self._query(c.query_status(), (0x11, 0x12))
            if self.data["state"] not in ("STOP", "FAULT"):
                raise ValueError("Confirmed STOP or FAULT is required before resetting faults")
            self._before_write()
            self._query(c.reset_faults(), (0x18,))
            self._query(c.query_status(), (0x11, 0x12))
            if self.data["state"] not in ("STOP", "FAULT"):
                raise ProtocolError("RESET verification did not confirm a stopped state")
            self.lbo_fault = False
            self.lbo_samples.clear()
        elif name == "service_set":
            self._service(value)
        else:
            raise ValueError(f"Unknown action: {name}")

    def _service(self, payload):
        self._control(stopped=True)
        if not self.service_enabled:
            raise ValueError("Enable service editing first")
        key, value = payload["key"], payload["value"]
        if key == "lbo_stability_enabled":
            if type(value) is not bool:
                raise ValueError("Expected a boolean")
            self._before_write(service=True)
            self.lbo_enabled = value
            self.lbo_samples.clear()
            self.lbo_fault = False
            return
        if key == "underfrequency_enabled":
            if type(value) is not bool:
                raise ValueError("Expected a boolean")
            self._before_write(service=True)
            self._query(c.set_underfrequency(value), (0x73,))
            self._query(c.query_status(), (0x11, 0x12))
            if self.data["service"][key] != value:
                raise ProtocolError("Underfrequency setting was not confirmed")
            return
        if key == "soft_start_enabled":
            if value is not True:
                raise ValueError("Only original softstart initialization is exposed")
            self._before_write(service=True)
            self._query(c.configure_softstart(True, 1), (0x69,))
            s = self.data["service"]
            if not s.get("soft_start_enabled") or s.get("soft_start_rate_a_s") != 0.5:
                raise ProtocolError("Original softstart settings were not confirmed")
            return
        if key == "qswitch_frequency_khz":
            if self.data.get("firmware_tuple") is None:
                raise ValueError("Known firmware is required for frequency scaling")
            nominal = self._number(payload.get("nominal_frequency_khz"), 0.5, 10, "Factory nominal (kHz)")
            freq = self._number(value, max(0.5, nominal * .8), min(10.0, nominal * 1.2), "Q-switch frequency (kHz)")
            scale = 10 if self.data.get("firmware_tuple") == (0, 1) else 100
            raw = round(freq * scale)
            if abs(freq * scale - raw) > 1e-7:
                raise ValueError(f"Frequency resolution for this firmware is {1/scale:g} kHz")
            self._operating(frequency_word=raw, require_stop=True)
            return
        if key == "qswitch_pulse_width_ns":
            width = self._number(value, 125, 10000, "Pulse width (ns)")
            if width % 125:
                raise ValueError("Pulse width must be a multiple of 125 ns")
            self._operating(width_word=int(width / 125), require_stop=True)
            return
        bounds = {
            "max_current_a": ("max_current", 10, 0, 40),
            "max_power_mw": ("max_power", 100, 0, 500),
            "power_slope_mw_v": ("power_slope", 100, 0, 100),
            "power_intercept_mw": ("power_intercept", 100, 0, 5),
            "lbo_high_c": ("lbo_high", 10, 5, 200),
            "lbo_low_c": ("lbo_low", 10, 5, 200),
        }
        if key not in bounds:
            raise ValueError("Unknown service field")
        field, scale, low, high = bounds[key]
        value = self._number(value, low, high, key)
        # Legacy cast-before-multiply loses fractions. Never silently truncate.
        if value != int(value):
            raise ValueError("Original service writes use whole-number values; fractional values would be truncated")
        # The EXE's unlabelled control21 is a string converted with atoi().
        # A mandatory nonzero password was our assumption, not a proven rule.
        code_text = payload.get("access_code", "")
        if not isinstance(code_text, (str, int)) or isinstance(code_text, bool):
            raise ValueError("Service numeric field must be blank or an integer in 0..65535")
        code_text = str(code_text).strip()
        if code_text and (not code_text.isascii() or not code_text.isdigit()):
            raise ValueError("Service numeric field must be blank or an integer in 0..65535")
        code = int(code_text) if code_text else 0
        if not 0 <= code <= 65535:
            raise ValueError("Service numeric field must be blank or an integer in 0..65535")
        self._query(c.service_read(), (0x70,))
        raw = dict(self.data["service"]["_raw_words"])
        raw[field] = int(value) * scale
        if raw["lbo_low"] >= raw["lbo_high"]:
            raise ValueError("LBO lower threshold must remain below upper threshold")
        self._control(stopped=True)
        # Compare against the final fresh status, not the earlier STOP read:
        # another controller can change the setpoint during the service read.
        if raw["max_current"] < self.data.get("current_set_a", 0) * 10:
            raise ValueError("Lower the operating current setpoint before reducing maximum current")
        self._before_write(service=True)
        self._query(c.set_service_words(code, raw), (0x70,))
        acknowledgement = dict(self.data["service"]["_raw_words"])
        # A reply can echo the request. Re-query the known startup read pattern
        # before claiming application, then refresh required instrument state.
        self._query(c.service_read(), (0x70,))
        self._query(c.query_status(), (0x11, 0x12))
        actual = self.data["service"]["_raw_words"]
        if self.data["state"] not in ("STOP", "FAULT"):
            raise ProtocolError("Service verification did not confirm a stopped state")
        changed_other = [k for k in raw if k != field and (
            acknowledgement[k] != raw[k] or actual[k] != raw[k])]
        if changed_other:
            raise ProtocolError("Unexpected service fields changed: " + ", ".join(changed_other))
        if actual[field] != raw[field] or acknowledgement[field] != raw[field]:
            message = (
                f"Service change unconfirmed ({key}): requested {raw[field] / scale:g}; "
                f"reply {acknowledgement[field] / scale:g}; re-read {actual[field] / scale:g}. "
                "Acceptance of the numeric field is unconfirmed. No automatic retry."
            )
            self._service_setting_warnings[key] = message
            self.data["service_setting_warning"] = "\n".join(self._service_setting_warnings.values())
            raise ServiceReadbackWarning(message)
        # Confirmation resolves only this field. Unrelated successful writes
        # must not conceal earlier unconfirmed service changes.
        self._service_setting_warnings.pop(key, None)
        self.data["service_setting_warning"] = "\n".join(self._service_setting_warnings.values())

    def connection_failed(self):
        self.enabled = False
        self.service_enabled = False
        self.data.update(comm_ok=False, state="UNKNOWN", emission=None, power_w=None)
        self.last_status = None
