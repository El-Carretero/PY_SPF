"""Empower operator interface. All device I/O belongs to the controller.

The GUI deliberately displays confirmed controller snapshots and never changes an
emission indication in response to an operator command alone.
"""
from __future__ import annotations

import math
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from PySide6.QtCore import QEvent, Qt, QTimer, Signal, Slot
from PySide6.QtGui import QCloseEvent, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFrame,
    QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton,
    QScrollArea, QSizePolicy, QTabWidget, QVBoxLayout, QWidget,
)


STYLE = """
QMainWindow, QWidget#central { background: #edf1f5; color: #202c3c; }
QWidget { font-family: 'Segoe UI', 'DejaVu Sans', sans-serif; font-size: 10pt; }
QLabel { color: #26364b; }
QFrame#header { background: #152940; border-radius: 7px; }
QLabel#title { color: white; font-size: 24pt; font-weight: 700; }
QLabel#subtitle { color: #bdccdc; font-size: 9pt; }
QLabel#connection_badge { color: #d4e2ed; padding: 6px 12px; background: #2b4057;
                           border-radius: 4px; font-size: 9pt; }
QFrame#card, QFrame#control_panel { background: white; border: 1px solid #d7e0e8;
                                border-radius: 6px; }
QLabel[role='caption'] { color: #66778a; font-size: 9pt; font-weight: 600; }
QLabel[role='metric'] { color: #152940; font-size: 27pt; font-weight: 700; }
QLabel[role='unit'] { color: #66778a; font-size: 10pt; }
QPushButton { background: #ffffff; border: 1px solid #b7c5d4; border-radius: 4px;
              padding: 7px 12px; font-weight: 600; color: #233b53; min-height: 18px; }
QPushButton:hover { background: #e8f0f8; border-color: #6a8daf; }
QPushButton:pressed { background: #d5e4f2; }
QPushButton:disabled { color: #98a3ad; background: #f0f3f6; border-color: #dce3e9; }
QPushButton#connect_button { background: #1e5c91; color: white; border: 0; }
QPushButton#connect_button:hover { background: #2672b1; }
QPushButton#run_button { background: #156d4b; color: white; border: 0;
                        font-size: 13pt; font-weight: 700; min-height: 35px; }
QPushButton#run_button:disabled { background: #dce7e1; color: #718579; }
QPushButton#run_button:pressed { background: #0d5136; }
QPushButton#stop_button { background: #b4232d; color: white; border: 0;
                         font-size: 15pt; font-weight: 700; min-height: 35px; }
QPushButton#stop_button:hover { background: #ce2e38; }
QPushButton#stop_button:disabled { background: #ecd9db; color: #a58b8f; }
QLineEdit, QDoubleSpinBox, QComboBox { background: white; color: #26364b;
    border: 1px solid #bfcbd7; border-radius: 4px; min-height: 25px; padding: 3px 7px; }
QLineEdit:disabled, QDoubleSpinBox:disabled, QComboBox:disabled {
    background: #f0f3f6; color: #8894a0; border-color: #dce3e9; }
QLineEdit:focus, QDoubleSpinBox:focus, QComboBox:focus { border: 1px solid #387cad; }
QTabWidget::pane { border: 1px solid #d7e0e8; border-radius: 4px; background: white; }
QTabBar::tab { background: #e1e7ee; padding: 9px 19px; margin-right: 3px;
               color: #536779; border-top-left-radius: 4px; border-top-right-radius: 4px; }
QTabBar::tab:selected { background: white; color: #194d79; font-weight: 700; }
QGroupBox { font-weight: 600; border: 1px solid #d9e2ea; border-radius: 5px;
            margin-top: 12px; padding: 12px; background: white; }
QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left;
                   left: 10px; padding: 0px 5px; }
QPlainTextEdit, QListWidget { border: 1px solid #d7e0e8; border-radius: 4px;
                           background: #fafbfd; color: #26364b; padding: 5px; }
QPlainTextEdit { font-family: 'Consolas', 'DejaVu Sans Mono', monospace; font-size: 9pt; }
QProgressBar { border: 0; background: #e5eaf0; border-radius: 3px; height: 5px; }
QProgressBar::chunk { background: #218460; border-radius: 3px; }
QCheckBox { spacing: 7px; color: #34485b; }
QStatusBar { color: #5b6c7e; font-size: 9pt; }
QScrollArea { border: 0; background: white; }
"""


def _number(value: Any, digits: int = 2) -> str:
    if isinstance(value, bool):
        return "--"
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "--"
    return f"{number:.{digits}f}" if math.isfinite(number) else "--"


def _known_number(value: Any) -> bool:
    return _number(value) != "--"


class MainWindow(QMainWindow):
    """Signal-based GUI contract for :mod:`empower.app`.

    ``action_requested`` carries ``run/stop/reset`` with None, ``set_current``
    with amperes, ``set_qswitch`` with the protocol enum, and ``service_set``
    with ``{"key": str, "value": number_or_bool}``.
    """

    connect_requested = Signal(str)
    disconnect_requested = Signal()
    action_requested = Signal(str, object)
    closeRequested = Signal()

    SERVICE_FIELDS = (
        ("max_current_a", "Maximum diode current", "A", False),
        ("max_power_mw", "Max power", "mW", False),
        ("power_slope_mw_v", "Power calibration slope", "mW/V", False),
        ("power_intercept_mw", "Power calibration intercept", "mW", False),
        ("lbo_low_c", "LBO lower temperature threshold", "°C", False),
        ("lbo_high_c", "LBO upper temperature threshold", "°C", False),
        ("qswitch_frequency_khz", "Internal Q-switch frequency", "kHz", False),
        ("qswitch_pulse_width_ns", "Q-switch pulse width", "ns", False),
        ("underfrequency_enabled", "Underfrequency fault checking", "", True),
        ("lbo_stability_enabled", "LBO stability fault checking", "", True),
    )

    FAULT_GROUPS = (
        ("Interlocks", ("Keyswitch", "Communication", "Cover", "Water flow")),
        ("Diode driver", ("Driver overtemperature", "Overvoltage", "Overcurrent", "Overpower")),
        ("Q-switch", ("Underfrequency", "Q-switch overtemperature", "VSWR", "Protection")),
        ("Diode / LBO", ("Diode overtemperature", "Diode overpower", "LBO temperature", "LBO stability")),
    )

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("main_window")
        self.setWindowTitle("Empower · Python Control")
        self.resize(1120, 780)
        self.setMinimumSize(920, 700)
        self.setStyleSheet(STYLE)
        self.allow_close = False
        self._snapshot: dict[str, Any] = {}
        self._snapshot_received_at = time.monotonic()
        self._last_snapshot_good = False
        self._connected = False
        self._simulated = True
        self._connecting = False
        self._hold_active = False
        self._hold_started = 0.0
        self._run_pending = False
        self._current_initialized = False
        self._qswitch_initialized = False
        self._service_initialized: set[str] = set()
        self._service_dirty: set[str] = set()
        self._authorization_pending: dict[str, bool | None] = {
            "enable_control": None, "enable_service": None,
        }
        self._log_lines: list[str] = []
        self._fault_signature: tuple[str, ...] | None = None
        self._previous_faults: tuple[str, ...] = ()
        self._close_pending = False
        self._hold_timer = QTimer(self)
        self._hold_timer.setInterval(40)
        self._hold_timer.timeout.connect(self._tick_hold)
        self._pending_timer = QTimer(self)
        self._pending_timer.setSingleShot(True)
        self._pending_timer.setInterval(8000)
        self._pending_timer.timeout.connect(self._release_pending)
        self._build_ui()
        self._freshness_timer = QTimer(self)
        self._freshness_timer.setInterval(250)
        self._freshness_timer.timeout.connect(self._check_snapshot_age)
        self._freshness_timer.start()
        self.installEventFilter(self)
        QApplication.instance().applicationStateChanged.connect(self._application_state_changed)
        self.stop_shortcut = QShortcut(QKeySequence(Qt.Key.Key_Escape), self)
        self.stop_shortcut.setContext(Qt.ShortcutContext.ApplicationShortcut)
        self.stop_shortcut.activated.connect(self._stop)
        self._refresh_ports()
        self._update_controls()

    def _build_ui(self) -> None:
        central = QWidget()
        central.setObjectName("central")
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(18, 14, 18, 10)
        layout.setSpacing(11)

        header = QFrame()
        header.setObjectName("header")
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(18, 12, 16, 12)
        titles = QVBoxLayout()
        titles.setSpacing(0)
        title = QLabel("EMPOWER")
        title.setObjectName("title")
        titles.addWidget(title)
        subtitle = QLabel("DIODE-PUMPED Nd:YLF LASER  /  PYTHON CONTROL")
        subtitle.setObjectName("subtitle")
        titles.addWidget(subtitle)
        header_layout.addLayout(titles)
        header_layout.addStretch()
        self.connection_badge = QLabel("DISCONNECTED")
        self.connection_badge.setObjectName("connection_badge")
        header_layout.addWidget(self.connection_badge)
        layout.addWidget(header)

        connection_row = QHBoxLayout()
        connection_row.addWidget(QLabel("Connection"))
        self.port_combo = QComboBox()
        self.port_combo.setObjectName("port_combo")
        self.port_combo.setEditable(True)
        self.port_combo.setMinimumWidth(190)
        self.port_combo.setToolTip("Select SIMULATOR or enter any serial port, e.g. COM7 or /dev/ttyUSB0.")
        connection_row.addWidget(self.port_combo)
        self.refresh_button = QPushButton("Refresh ports")
        self.refresh_button.setObjectName("refresh_ports_button")
        self.refresh_button.clicked.connect(self._refresh_ports)
        connection_row.addWidget(self.refresh_button)
        self.connect_button = QPushButton("Connect")
        self.connect_button.setObjectName("connect_button")
        self.connect_button.clicked.connect(self._connect_clicked)
        connection_row.addWidget(self.connect_button)
        self.disconnect_button = QPushButton("Disconnect")
        self.disconnect_button.setObjectName("disconnect_button")
        self.disconnect_button.clicked.connect(self._disconnect_clicked)
        connection_row.addWidget(self.disconnect_button)
        connection_row.addStretch()
        self.communication_label = QLabel("COMM  --")
        self.communication_label.setObjectName("communication_label")
        connection_row.addWidget(self.communication_label)
        layout.addLayout(connection_row)

        cards = QHBoxLayout()
        cards.setSpacing(10)
        self.power_label = self._metric(cards, "OUTPUT POWER", "W", "power_label")
        self.current_label = self._metric(cards, "SENSED CURRENT", "A", "current_label")
        self.state_label = self._metric(cards, "CONTROLLER STATE", "Confirmed readback", "state_label")
        self.emission_label = self._metric(cards, "EMISSION", "Controller indication", "emission_label")
        self.state_label.setStyleSheet("font-size: 20pt; font-weight: 700;")
        self.emission_label.setStyleSheet("font-size: 20pt; font-weight: 700;")
        layout.addLayout(cards)

        controls = QFrame()
        controls.setObjectName("control_panel")
        controls_layout = QGridLayout(controls)
        controls_layout.setContentsMargins(13, 10, 13, 10)
        controls_layout.setHorizontalSpacing(14)
        self.run_button = QPushButton("HOLD 5 s TO RUN")
        self.run_button.setObjectName("run_button")
        self.run_button.setMinimumWidth(210)
        self.run_button.setAutoRepeat(False)
        self.run_button.setAutoDefault(False)
        self.run_button.pressed.connect(self._begin_hold)
        self.run_button.released.connect(self._cancel_hold)
        self.run_button.installEventFilter(self)
        controls_layout.addWidget(self.run_button, 0, 0)
        self.stop_button = QPushButton("STOP  ·  Esc")
        self.stop_button.setObjectName("stop_button")
        self.stop_button.setMinimumWidth(200)
        self.stop_button.setAutoDefault(False)
        self.stop_button.clicked.connect(self._stop)
        controls_layout.addWidget(self.stop_button, 0, 1)
        self.arm_checkbox = QCheckBox("Enable hardware control for this connection")
        self.arm_checkbox.setObjectName("hardware_run_checkbox")
        self.arm_checkbox.setChecked(False)
        self.arm_checkbox.toggled.connect(self._arm_changed)
        controls_layout.addWidget(self.arm_checkbox, 0, 2)
        controls_layout.setColumnStretch(2, 1)
        self.hold_progress = QProgressBar()
        self.hold_progress.setObjectName("run_hold_progress")
        self.hold_progress.setRange(0, 5000)
        self.hold_progress.setValue(0)
        self.hold_progress.setTextVisible(False)
        self.hold_progress.setFixedHeight(5)
        controls_layout.addWidget(self.hold_progress, 1, 0)
        self.control_hint = QLabel("Connect to the simulator to explore the controls.")
        self.control_hint.setObjectName("control_hint")
        self.control_hint.setWordWrap(True)
        self.control_hint.setStyleSheet("font-size: 9pt; color: #65768a;")
        controls_layout.addWidget(self.control_hint, 1, 1, 1, 2)
        layout.addWidget(controls)

        self.setting_warning_label = QLabel()
        self.setting_warning_label.setObjectName("setting_warning_label")
        self.setting_warning_label.setTextFormat(Qt.TextFormat.PlainText)
        self.setting_warning_label.setWordWrap(True)
        self.setting_warning_label.setStyleSheet(
            "background: #fff3cd; color: #765100; border: 1px solid #dfbd62; "
            "border-radius: 5px; padding: 9px 12px; font-weight: 600;"
        )
        self.setting_warning_label.hide()
        layout.addWidget(self.setting_warning_label)

        self.tabs = QTabWidget()
        self.tabs.setObjectName("control_tabs")
        self.tabs.addTab(self._setup_tab(), "Setup")
        self.tabs.addTab(self._faults_tab(), "Faults")
        self.tabs.addTab(self._information_tab(), "Information")
        self.tabs.addTab(self._service_tab(), "Service")
        self.tabs.addTab(self._log_tab(), "Communication log")
        layout.addWidget(self.tabs, 1)
        self.statusBar().showMessage("Disconnected · no device commands sent")

    def _metric(self, parent: QHBoxLayout, caption: str, unit: str, name: str) -> QLabel:
        frame = QFrame()
        frame.setObjectName("card")
        box = QVBoxLayout(frame)
        box.setContentsMargins(15, 11, 15, 11)
        box.setSpacing(3)
        title = QLabel(caption)
        title.setProperty("role", "caption")
        box.addWidget(title)
        value = QLabel("--")
        value.setObjectName(name)
        value.setProperty("role", "metric")
        box.addWidget(value)
        suffix = QLabel(unit)
        suffix.setProperty("role", "unit")
        box.addWidget(suffix)
        parent.addWidget(frame, 1)
        return value

    def _setup_tab(self) -> QWidget:
        tab = QWidget()
        outer = QVBoxLayout(tab)
        outer.setContentsMargins(16, 12, 16, 12)
        row = QHBoxLayout()
        current_group = QGroupBox("Diode current")
        grid = QGridLayout(current_group)
        grid.addWidget(QLabel("Confirmed set point"), 0, 0)
        self.current_set_label = QLabel("-- A")
        self.current_set_label.setObjectName("current_set_label")
        grid.addWidget(self.current_set_label, 0, 1)
        grid.addWidget(QLabel("Last requested current"), 1, 0)
        self.current_requested_label = QLabel("-- A")
        self.current_requested_label.setObjectName("current_requested_label")
        grid.addWidget(self.current_requested_label, 1, 1)
        grid.addWidget(QLabel("Factory maximum readback"), 2, 0)
        self.max_current_label = QLabel("-- A")
        self.max_current_label.setObjectName("max_current_label")
        grid.addWidget(self.max_current_label, 2, 1)
        grid.addWidget(QLabel("New set point"), 3, 0)
        self.current_input = QDoubleSpinBox()
        self.current_input.setObjectName("current_input")
        self.current_input.setDecimals(1)
        self.current_input.setRange(0.0, 0.0)
        self.current_input.setSingleStep(0.1)
        self.current_input.setSuffix(" A")
        self.current_input.setKeyboardTracking(False)
        self.current_input.setSpecialValueText("--")
        grid.addWidget(self.current_input, 3, 1)
        self.apply_current_button = QPushButton("Apply current")
        self.apply_current_button.setObjectName("apply_current_button")
        self.apply_current_button.clicked.connect(self._apply_current)
        grid.addWidget(self.apply_current_button, 4, 1)
        current_note = QLabel("The limit comes from the controller. Editing the value sends nothing until Apply.")
        current_note.setWordWrap(True)
        current_note.setStyleSheet("color: #64778a; font-size: 9pt;")
        grid.addWidget(current_note, 5, 0, 1, 2)
        row.addWidget(current_group, 1)
        qsw_group = QGroupBox("Q-switch source")
        qgrid = QGridLayout(qsw_group)
        qgrid.addWidget(QLabel("Confirmed source"), 0, 0)
        self.qswitch_readback = QLabel("--")
        self.qswitch_readback.setObjectName("qswitch_readback")
        qgrid.addWidget(self.qswitch_readback, 0, 1)
        self.qswitch_combo = QComboBox()
        self.qswitch_combo.setObjectName("qswitch_combo")
        self.qswitch_combo.addItem("Select source", None)
        self.qswitch_combo.addItem("External", 3)
        self.qswitch_combo.addItem("Internal", 2)
        self.qswitch_combo.addItem("Hold off · service only", 1)
        qgrid.addWidget(self.qswitch_combo, 1, 0, 1, 2)
        self.apply_qswitch_button = QPushButton("Apply Q-switch source")
        self.apply_qswitch_button.setObjectName("apply_qswitch_button")
        self.apply_qswitch_button.clicked.connect(self._apply_qswitch)
        qgrid.addWidget(self.apply_qswitch_button, 2, 0, 1, 2)
        note = QLabel("Change source with the controller stopped. Hold off is a service setting and requires the Service enable checkbox.")
        note.setWordWrap(True)
        note.setStyleSheet("color: #64778a; font-size: 9pt;")
        qgrid.addWidget(note, 3, 0, 1, 2)
        qgrid.setRowStretch(4, 1)
        row.addWidget(qsw_group, 1)
        outer.addLayout(row)
        outer.addStretch()
        return tab

    def _faults_tab(self) -> QWidget:
        tab = QWidget()
        box = QVBoxLayout(tab)
        box.setContentsMargins(16, 12, 16, 12)
        self.fault_summary = QLabel("Fault status unavailable")
        self.fault_summary.setObjectName("fault_summary")
        self.fault_summary.setStyleSheet("font-size: 12pt; font-weight: 600;")
        box.addWidget(self.fault_summary)
        self.fault_list = QListWidget()
        self.fault_list.setObjectName("fault_list")
        box.addWidget(self.fault_list, 1)
        row = QHBoxLayout()
        note = QLabel("Reset after correcting the underlying fault. Reset does not start the laser.")
        note.setWordWrap(True)
        row.addWidget(note, 1)
        self.reset_button = QPushButton("RESET FAULTS")
        self.reset_button.setObjectName("reset_faults_button")
        self.reset_button.clicked.connect(self._reset)
        row.addWidget(self.reset_button)
        box.addLayout(row)
        self.simulator_group = QGroupBox("Simulator controls")
        simrow = QHBoxLayout(self.simulator_group)
        self.sim_fault_combo = QComboBox()
        self.sim_fault_combo.setObjectName("sim_fault_combo")
        self.sim_fault_combo.addItems(["KEYSWITCH", "WATERFLOW", "COVER", "OVERCURRENT", "LBO_TEMP", "UNDERFREQUENCY", "COMMUNICATION"])
        simrow.addWidget(self.sim_fault_combo, 1)
        inject = QPushButton("Inject fault")
        inject.setObjectName("sim_inject_fault_button")
        inject.clicked.connect(lambda: self.action_requested.emit("sim_fault", self.sim_fault_combo.currentText()))
        simrow.addWidget(inject)
        clear = QPushButton("Clear simulated condition")
        clear.setObjectName("sim_clear_fault_button")
        clear.clicked.connect(lambda: self.action_requested.emit("sim_clear", None))
        simrow.addWidget(clear)
        box.addWidget(self.simulator_group)
        return tab

    def _information_tab(self) -> QWidget:
        tab = QWidget()
        box = QVBoxLayout(tab)
        box.setContentsMargins(16, 14, 16, 12)
        grid = QGridLayout()
        self.info_labels: dict[str, QLabel] = {}
        for row, (key, caption) in enumerate((
            ("firmware", "Power supply firmware"),
            ("hours", "Power supply operation hours"),
            ("product_version", "Python control version"),
            ("raw_status", "Raw controller status"),
            ("timestamp", "Snapshot published (UTC)"),
            ("rx_checksum", "Response validation"),
            ("compatibility", "Firmware compatibility"),
            ("log_path", "Session log file"),
        )):
            grid.addWidget(QLabel(caption), row, 0)
            label = QLabel("--")
            label.setObjectName("info_" + key)
            label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            label.setWordWrap(True)
            if key == "compatibility":
                label.setMinimumHeight(34)
            grid.addWidget(label, row, 1)
            self.info_labels[key] = label
        grid.setColumnStretch(1, 1)
        box.addLayout(grid)
        box.addWidget(QLabel("Status and fault history · raw serial traffic is in Communication log"))
        self.status_log = QPlainTextEdit()
        self.status_log.setObjectName("status_log")
        self.status_log.setReadOnly(True)
        self.status_log.setMaximumBlockCount(2000)
        box.addWidget(self.status_log, 1)
        export = QPushButton("Export displayed history…")
        export.setObjectName("export_history_button")
        export.setToolTip("Export status and fault history. Use Communication log to export displayed TX/RX traffic.")
        export.clicked.connect(lambda: self._export_log(self.status_log.toPlainText(), "Empower_status_history.txt"))
        box.addWidget(export, alignment=Qt.AlignmentFlag.AlignRight)
        return tab

    def _service_tab(self) -> QWidget:
        tab = QWidget()
        outer = QVBoxLayout(tab)
        outer.setContentsMargins(16, 12, 16, 12)
        self.service_checkbox = QCheckBox("Enable service parameter editing for this connection")
        self.service_checkbox.setObjectName("service_enable_checkbox")
        self.service_checkbox.toggled.connect(self._service_toggled)
        outer.addWidget(self.service_checkbox)
        credentials = QHBoxLayout()
        service_numeric_label = QLabel("Service numeric field (optional)")
        service_numeric_hint = (
            "The original service panel has an unlabelled numeric field. "
            "Blank is transmitted as 0; its authorization meaning and device "
            "acceptance are unconfirmed. This does not bypass firmware checks."
        )
        service_numeric_label.setToolTip(service_numeric_hint)
        credentials.addWidget(service_numeric_label)
        self.service_access_code = QLineEdit()
        self.service_access_code.setObjectName("service_access_code")
        self.service_access_code.setEchoMode(QLineEdit.EchoMode.Password)
        self.service_access_code.setPlaceholderText("Blank sends 0; device acceptance unconfirmed")
        self.service_access_code.setToolTip(service_numeric_hint)
        self.service_access_code.setMinimumWidth(350)
        self.service_access_code.setMaximumWidth(360)
        credentials.addWidget(self.service_access_code)
        credentials.addWidget(QLabel("Factory frequency"))
        self.nominal_frequency_input = QLineEdit()
        self.nominal_frequency_input.setObjectName("nominal_frequency_input")
        self.nominal_frequency_input.setPlaceholderText("kHz · for frequency changes")
        self.nominal_frequency_input.setMinimumWidth(230)
        self.nominal_frequency_input.setMaximumWidth(230)
        credentials.addWidget(self.nominal_frequency_input)
        credentials.addStretch()
        outer.addLayout(credentials)
        note = QLabel("STOP and readback required. mW and mW/V below reproduce original GUI labels; their physical calibration is unverified. Main power is displayed separately in W.")
        note.setWordWrap(True)
        note.setStyleSheet("font-size: 9pt; color: #64778a;")
        outer.addWidget(note)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        grid = QGridLayout(content)
        grid.setContentsMargins(0, 4, 5, 4)
        for column, caption in enumerate(("Parameter", "Readback", "New value", "")):
            label = QLabel(caption)
            label.setStyleSheet("font-weight: 600; color: #617387;")
            grid.addWidget(label, 0, column)
        self.service_widgets: dict[str, tuple[QLabel, QWidget, QPushButton]] = {}
        for row, (key, caption, unit, is_bool) in enumerate(self.SERVICE_FIELDS, 1):
            label = QLabel(caption + (f" ({unit})" if unit else ""))
            grid.addWidget(label, row, 0)
            readback = QLabel("--")
            readback.setObjectName("service_read_" + key)
            grid.addWidget(readback, row, 1)
            if is_bool:
                editor = QComboBox()
                editor.addItem("Read value first", None)
                editor.addItem("Enabled", True)
                editor.addItem("Disabled", False)
                editor.activated.connect(lambda _index, name=key: self._service_dirty.add(name))
            else:
                editor = QLineEdit()
                editor.setPlaceholderText("Read value first")
                editor.textEdited.connect(lambda _text, name=key: self._service_dirty.add(name))
            editor.setObjectName("service_edit_" + key)
            editor.setMaximumWidth(195)
            if key == "max_power_mw":
                max_power_hint = (
                    "The original GUI labels this field mW. Its firmware function "
                    "and physical units are unconfirmed; this is not a confirmed "
                    "optical power cutoff."
                )
                readback.setToolTip(max_power_hint)
                editor.setToolTip(max_power_hint)
            grid.addWidget(editor, row, 2)
            button = QPushButton("Apply")
            button.setObjectName("service_apply_" + key)
            button.clicked.connect(lambda _checked=False, name=key: self._apply_service(name))
            grid.addWidget(button, row, 3)
            self.service_widgets[key] = (readback, editor, button)
        self.lbo_temp_label = QLabel("-- °C")
        self.lbo_temp_label.setObjectName("lbo_temperature_label")
        grid.addWidget(QLabel("LBO temperature (read only)"), 11, 0)
        grid.addWidget(self.lbo_temp_label, 11, 1)
        self.soft_start_label = QLabel("--")
        self.soft_start_label.setObjectName("soft_start_label")
        grid.addWidget(QLabel("Soft start / communication drops"), 12, 0)
        grid.addWidget(self.soft_start_label, 12, 1, 1, 3)
        self.soft_start_button = QPushButton("Apply original soft start")
        self.soft_start_button.setObjectName("soft_start_button")
        self.soft_start_button.clicked.connect(self._apply_soft_start)
        grid.addWidget(self.soft_start_button, 13, 0)
        self.lbo_monitor_label = QLabel("LBO monitor: --")
        self.lbo_monitor_label.setObjectName("lbo_monitor_label")
        self.lbo_monitor_label.setWordWrap(True)
        grid.addWidget(self.lbo_monitor_label, 13, 1, 1, 3)
        grid.setColumnStretch(0, 2)
        grid.setColumnStretch(2, 1)
        grid.setRowStretch(14, 1)
        scroll.setWidget(content)
        outer.addWidget(scroll, 1)
        return tab

    def _log_tab(self) -> QWidget:
        tab = QWidget()
        box = QVBoxLayout(tab)
        box.setContentsMargins(16, 12, 16, 12)
        self.comm_log = QPlainTextEdit()
        self.comm_log.setObjectName("communication_log")
        self.comm_log.setReadOnly(True)
        self.comm_log.setMaximumBlockCount(10000)
        box.addWidget(self.comm_log, 1)
        row = QHBoxLayout()
        note = QLabel("TX / RX and application events · newest entry at the bottom")
        note.setStyleSheet("color: #64778a; font-size: 9pt;")
        row.addWidget(note, 1)
        clear = QPushButton("Clear display")
        clear.setObjectName("clear_log_button")
        clear.clicked.connect(self.comm_log.clear)
        row.addWidget(clear)
        export = QPushButton("Export displayed log…")
        export.setObjectName("export_log_button")
        export.clicked.connect(lambda: self._export_log(self.comm_log.toPlainText(), "Empower_communication_log.txt"))
        row.addWidget(export)
        box.addLayout(row)
        return tab

    @Slot()
    def _refresh_ports(self) -> None:
        current = self.port_combo.currentText().strip() or "SIMULATOR"
        self.port_combo.clear()
        self.port_combo.addItem("SIMULATOR")
        try:
            from serial.tools import list_ports
            for port in list_ports.comports():
                self.port_combo.addItem(port.device)
                index = self.port_combo.count() - 1
                self.port_combo.setItemData(index, port.description, Qt.ItemDataRole.ToolTipRole)
        except Exception as exc:
            self.append_log(f"Port enumeration unavailable: {exc}")
        self.port_combo.setCurrentText(current)

    @Slot()
    def _connect_clicked(self) -> None:
        port = self.port_combo.currentText().strip()
        if not port:
            self.statusBar().showMessage("Enter a serial port or choose SIMULATOR.")
            return
        if self._connected or self._connecting:
            return
        self._connecting = True
        self._simulated = port.upper() == "SIMULATOR"
        self.arm_checkbox.setChecked(False)
        self.service_checkbox.setChecked(False)
        self._update_controls()
        self.connection_badge.setText("CONNECTING…")
        self.statusBar().showMessage(f"Connecting to {port}…")
        self.connect_requested.emit("SIMULATOR" if self._simulated else port)

    @Slot()
    def _disconnect_clicked(self) -> None:
        self._cancel_hold()
        self.arm_checkbox.setChecked(False)
        self.service_checkbox.setChecked(False)
        self.disconnect_requested.emit()

    @Slot(bool, str)
    def set_connection(self, connected: bool, description: str = "") -> None:
        """Controller calls this after connection success, failure, or close."""
        was_connected = self._connected
        self._connected = bool(connected)
        self._connecting = False
        self._snapshot["connected"] = self._connected
        if not connected:
            self._cancel_hold()
            self._run_pending = False
            self._pending_timer.stop()
            self._clear_authorization()
            self.service_access_code.clear()
            self.nominal_frequency_input.clear()
            self._snapshot = {"connected": False, "simulated": self._simulated}
            self._current_initialized = False
            self._qswitch_initialized = False
            self._service_initialized.clear()
            self._service_dirty.clear()
            self._previous_faults = ()
            self._fault_signature = None
            self.current_input.setSpecialValueText("--")
            self.current_input.setValue(0)
            self.qswitch_combo.setCurrentIndex(0)
            for _, editor, _ in self.service_widgets.values():
                if isinstance(editor, QLineEdit):
                    editor.clear()
                else:
                    editor.setCurrentIndex(0)
        elif not was_connected:
            self._clear_authorization()
        if description:
            self.statusBar().showMessage(description)
        self._paint_snapshot()
        self._update_controls()

    @Slot(dict)
    def update_snapshot(self, snapshot: dict[str, Any]) -> None:
        """Replace the authoritative snapshot; missing values remain unknown."""
        self._snapshot = dict(snapshot)
        self._snapshot_received_at = time.monotonic()
        self._connected = bool(snapshot.get("connected", self._connected))
        self._simulated = bool(snapshot.get("simulated", self._simulated))
        if self._connected:
            self._connecting = False
        state = str(snapshot.get("state", "UNKNOWN")).upper()
        if state != "STOP" or not self._snapshot_good() or snapshot.get("faults"):
            self._cancel_hold()
        if state != "STOP":
            self._run_pending = False
            self._pending_timer.stop()
        faults = tuple(map(str, snapshot.get("faults") or []))
        new_faults = bool(faults) and faults != self._previous_faults
        if not self._connected or not snapshot.get("comm_ok"):
            self._clear_authorization()
        elif new_faults:
            # Also cancel any earlier pending enable request when a new fault
            # arrives. Worker snapshots remain the authorization authority.
            self.arm_checkbox.setChecked(False)
            self.service_checkbox.setChecked(False)
        self._sync_authorization()
        self._previous_faults = faults
        self._last_snapshot_good = self._snapshot_good()
        self._paint_snapshot()
        self._update_controls()

    @staticmethod
    def _check_without_signal(widget: QCheckBox, checked: bool) -> None:
        blocked = widget.blockSignals(True)
        try:
            widget.setChecked(checked)
        finally:
            widget.blockSignals(blocked)

    def _clear_authorization(self) -> None:
        self._authorization_pending.update(enable_control=None, enable_service=None)
        self._check_without_signal(self.arm_checkbox, False)
        self._check_without_signal(self.service_checkbox, False)

    def _sync_authorization(self) -> None:
        if not self._connected or not self._snapshot.get("comm_ok"):
            self._clear_authorization()
            return
        for action, key, widget in (
            ("enable_control", "control_enabled", self.arm_checkbox),
            ("enable_service", "service_enabled", self.service_checkbox),
        ):
            actual = self._snapshot.get(key) is True
            pending = self._authorization_pending[action]
            # A snapshot may revoke authorization, never create operator
            # intent. In particular an older True snapshot must not re-check
            # a box the operator has just unchecked. Only action_result ends
            # the pending request; matching an old poll is not an ACK.
            if not actual and pending is not True:
                self._check_without_signal(widget, False)

    @Slot(dict)
    def action_result(self, result: dict[str, Any]) -> None:
        """Settle worker authorization without mistaking an old poll for ACK."""
        action = result.get("name")
        if action == "stop":
            if result.get("ok") is True and self._snapshot_good():
                state = self._snapshot.get("state")
                if state == "STOP":
                    self.statusBar().showMessage("STOP confirmed by controller")
                elif state == "FAULT":
                    self.statusBar().showMessage("STOP confirmed by controller · active fault remains")
            # Failed STOP leaves the worker's unknown/error message intact.
            return
        if action == "run" and result.get("ok") is False:
            self._pending_timer.stop()
            self._release_pending()
            return
        if action not in self._authorization_pending:
            return
        pending = self._authorization_pending[action]
        if pending is not None and result.get("value") == pending:
            self._authorization_pending[action] = None
            self._sync_authorization()
            self._update_controls()

    def _paint_snapshot(self) -> None:
        snapshot = self._snapshot
        good = self._snapshot_good()
        warning = str(snapshot.get("setting_warning") or "").strip() if good else ""
        self.setting_warning_label.setText(warning)
        self.setting_warning_label.setVisible(bool(warning))
        self.power_label.setText(_number(snapshot.get("power_w")) if good else "--")
        self.current_label.setText(_number(snapshot.get("current_a"), 1) if good else "--")
        state = str(snapshot.get("state", "UNKNOWN")).upper() if good else "UNKNOWN"
        self.state_label.setText(state if state != "UNKNOWN" else "--")
        state_color = {"RUN": "#167148", "COUNTDOWN": "#b2720b", "FAULT": "#b4232d", "STOP": "#344d69"}.get(state, "#78899a")
        self.state_label.setStyleSheet(f"font-size: 20pt; font-weight: 700; color: {state_color};")
        emission = snapshot.get("emission") if good else None
        self.emission_label.setText("ON" if emission is True else "OFF" if emission is False else "--")
        self.emission_label.setStyleSheet("font-size: 20pt; font-weight: 700; color: " + ("#b4232d" if emission is True else "#61758a") + ";")
        self.connection_badge.setText(("SIMULATOR" if self._simulated else self.port_combo.currentText()) + " CONNECTED" if self._connected else "DISCONNECTED")
        self.communication_label.setText("COMM  OK" if good else "COMM  STALE" if self._connected and snapshot.get("comm_ok") else "COMM  LOST" if self._connected else "COMM  --")
        self.communication_label.setStyleSheet("font-weight: 600; color: " + ("#167148" if good else "#b4232d" if self._connected else "#78899a") + ";")
        current_set = snapshot.get("current_set_a") if good else None
        current_request = snapshot.get("current_request_a") if good else None
        maximum = snapshot.get("max_current_a") if good else None
        self.current_set_label.setText(_number(current_set, 1) + " A")
        self.current_requested_label.setText(_number(current_request, 1) + " A")
        self.max_current_label.setText(_number(maximum, 1) + " A")
        if _known_number(maximum) and float(maximum) >= 0:
            # Even setMaximum(the same value) replaces uncommitted spinbox text.
            if self.current_input.maximum() != float(maximum):
                self.current_input.setMaximum(float(maximum))
            if self.current_input.specialValueText():
                self.current_input.setSpecialValueText("")
            if not self._current_initialized and _known_number(current_set):
                self.current_input.setValue(float(current_set))
                self._current_initialized = True
        qswitch = snapshot.get("qswitch") if good else None
        qname = {3: "External", 2: "Internal", 1: "Hold off", 0: "CW RF OFF · factory"}.get(qswitch, "--")
        self.qswitch_readback.setText(qname)
        if qswitch in (0, 1, 2, 3) and not self._qswitch_initialized:
            self.qswitch_combo.setCurrentIndex(self.qswitch_combo.findData(qswitch) if qswitch else 0)
            self._qswitch_initialized = True
        for key, label in self.info_labels.items():
            value = snapshot.get(key)
            if key in ("hours", "raw_status") and not good:
                value = None
            if key == "compatibility":
                label.setToolTip(str(snapshot.get("compatibility_details", "")))
            if key == "hours":
                value = _number(value, 1)
            label.setText(str(value) if value is not None and value != "" else "--")
        faults = snapshot.get("faults")
        if not good or faults is None:
            self.fault_summary.setText("Fault status unavailable")
            self.fault_summary.setStyleSheet("font-size: 12pt; font-weight: 600; color: #78899a;")
            self.fault_list.clear()
            self.fault_list.addItem("Awaiting confirmed fault readback.")
        else:
            faults = list(map(str, faults))
            self.fault_summary.setText(f"{len(faults)} active fault(s)" if faults else "No active faults reported")
            self.fault_summary.setStyleSheet("font-size: 12pt; font-weight: 600; color: " + ("#b4232d" if faults else "#167148") + ";")
            signature = tuple(faults)
            self.fault_list.clear()
            self.fault_list.addItems(faults or ["All reported fault bits clear."])
            if signature != self._fault_signature:
                stamp = snapshot.get("timestamp") or datetime.now().isoformat(timespec="seconds")
                self.status_log.appendPlainText(f"{stamp}  " + ("FAULT: " + "; ".join(faults) if faults else "Faults clear"))
                self._fault_signature = signature
        self.tabs.setTabText(1, f"Faults ({len(faults)})" if good and faults else "Faults")
        service = snapshot.get("service") or {}
        for key, _caption, _unit, is_bool in self.SERVICE_FIELDS:
            readback, editor, _button = self.service_widgets[key]
            value = service.get(key) if good else None
            if key == "max_current_a" and value is None and good:
                value = maximum
            known = isinstance(value, bool) if is_bool else _known_number(value)
            readback.setText(("Enabled" if value else "Disabled") if is_bool and known else _number(value, 3) if known else "--")
            if known and key not in self._service_dirty:
                if isinstance(editor, QComboBox):
                    editor.setCurrentIndex(editor.findData(value))
                else:
                    text = f"{float(value):g}"
                    if editor.text() != text:
                        editor.setText(text)
                self._service_initialized.add(key)
        self.lbo_temp_label.setText(_number(service.get("lbo_temp_c") if good else None, 3) + " °C")
        soft_start = service.get("soft_start", service.get("soft_start_enabled"))
        drops = service.get("communication_drops")
        self.soft_start_label.setText((str(soft_start) if soft_start is not None and good else "--") + " / " + (str(drops) if drops is not None and good else "--"))
        self.lbo_monitor_label.setText("LBO monitor: " + (str(service.get("lbo_monitor", snapshot.get("lbo_monitor", "--"))) if good else "--"))

    def _snapshot_good(self) -> bool:
        if not self._connected or not self._snapshot.get("comm_ok"):
            return False
        if self._snapshot.get("status_fresh") is False:
            return False
        if "status_age_s" in self._snapshot:
            age = self._snapshot.get("status_age_s")
            if not _known_number(age):
                return False
            elapsed = max(0.0, time.monotonic() - self._snapshot_received_at)
            return float(age) + elapsed <= 3.0
        return True

    @Slot()
    def _check_snapshot_age(self) -> None:
        good = self._snapshot_good()
        if good != self._last_snapshot_good:
            self._last_snapshot_good = good
            if not good:
                self._cancel_hold()
            self._paint_snapshot()
            self._update_controls()

    def _write_ready(self) -> bool:
        return (self._snapshot_good()
                and self._snapshot.get("control_enabled") is True
                and (self._simulated or self.arm_checkbox.isChecked()))

    def _run_ready(self) -> bool:
        return self._run_block_reason() is None

    def _run_block_reason(self) -> str | None:
        snapshot = self._snapshot
        if not self._connected:
            return "Connect to the simulator to explore the controls."
        if not snapshot.get("comm_ok"):
            return "Communication unconfirmed. STOP remains available; device state is unknown."
        if not self._snapshot_good():
            return "Controller status is stale. STOP remains available; wait for fresh readback."
        if snapshot.get("faults"):
            return "RUN and current changes blocked by active faults. Review the Faults tab."
        if snapshot.get("faults") != []:
            return "RUN blocked: confirmed fault status is unavailable."
        if snapshot.get("unknown_status_bits"):
            return "RUN and current changes blocked by unknown status bits. Review raw controller status in Information."
        state = snapshot.get("state")
        if state != "STOP":
            if state in ("RUN", "COUNTDOWN"):
                return f"Controller {state}; STOP remains available."
            return "RUN and current changes blocked until a recognized operating state is confirmed. STOP remains available."
        if not self._write_ready():
            if self._authorization_pending["enable_control"] is True:
                return "Waiting for the worker to enable session control. STOP remains available."
            return "Hardware writes are locked. Enable control explicitly for this connection; STOP remains available."
        if self._run_pending:
            return "RUN requested; waiting for controller confirmation. STOP remains available."
        if snapshot.get("firmware_tuple") is None:
            return "RUN blocked: a known firmware readback is required."
        if snapshot.get("qswitch") not in (2, 3):
            return "RUN blocked: confirm Internal or External Q-switch source in Setup."
        service = snapshot.get("service") or {}
        if service.get("underfrequency_enabled") is not True:
            return "RUN blocked: enable underfrequency fault checking in Service and confirm its readback."
        if service.get("soft_start_enabled") is not True:
            return "RUN blocked: use Service > Apply original soft start and wait for confirmed readback."
        maximum, current = snapshot.get("max_current_a"), snapshot.get("current_set_a")
        if not (_known_number(maximum) and _known_number(current)
                and float(maximum) > 0 and 0 <= float(current) <= float(maximum)):
            return "RUN blocked: valid current setpoint and factory maximum readbacks are required."
        return None

    def _service_ready(self) -> bool:
        return (self._write_ready() and self._snapshot.get("state") == "STOP"
                and self._snapshot.get("service_enabled") is True and self.service_checkbox.isChecked())

    def _update_controls(self) -> None:
        connected = self._connected
        write_ready = self._write_ready()
        stopped = self._snapshot.get("state") == "STOP"
        self.port_combo.setEnabled(not connected and not self._connecting)
        self.refresh_button.setEnabled(not connected and not self._connecting)
        self.connect_button.setEnabled(not connected and not self._connecting)
        self.disconnect_button.setEnabled(connected)
        self.stop_button.setEnabled(connected)
        self.arm_checkbox.setEnabled(connected and not self._simulated and bool(self._snapshot.get("comm_ok")))
        self.run_button.setEnabled(self._run_ready())
        if not self._hold_active:
            self.run_button.setText("RUN REQUEST SENT" if self._run_pending else "HOLD 5 s TO RUN")
        current_ready = (
            write_ready
            and self._snapshot.get("state") in ("STOP", "RUN", "COUNTDOWN")
            and not self._snapshot.get("faults")
            and not self._snapshot.get("unknown_status_bits")
            and _known_number(self._snapshot.get("max_current_a"))
        )
        self.current_input.setEnabled(current_ready)
        self.apply_current_button.setEnabled(self.current_input.isEnabled() and self._current_initialized)
        self.qswitch_combo.setEnabled(write_ready and stopped)
        self.apply_qswitch_button.setEnabled(write_ready and stopped and self._qswitch_initialized)
        self.reset_button.setEnabled(write_ready and self._snapshot.get("state") not in ("RUN", "COUNTDOWN"))
        self.service_checkbox.setEnabled(write_ready and stopped)
        self.service_access_code.setEnabled(self._service_ready())
        self.nominal_frequency_input.setEnabled(self._service_ready())
        self.soft_start_button.setEnabled(self._service_ready())
        self.simulator_group.setVisible(self._simulated)
        self.simulator_group.setEnabled(connected and self._simulated)
        for key, (readback, editor, button) in self.service_widgets.items():
            enabled = self._service_ready() and readback.text() != "--" and key in self._service_initialized
            editor.setEnabled(enabled)
            button.setEnabled(enabled)
        hint = self._run_block_reason()
        if hint is None and self._simulated:
            hint = "SIMULATOR · no physical laser connected. Hold RUN for five seconds; release to cancel."
        elif hint is None:
            hint = "Hold RUN for five seconds; release to cancel. STOP is available at any time."
        self.control_hint.setText(hint)

    @Slot()
    def _begin_hold(self) -> None:
        if not self._run_ready() or self._hold_active:
            return
        self._hold_active = True
        self._hold_started = time.monotonic()
        self.hold_progress.setValue(0)
        self._hold_timer.start()
        self.run_button.setText("KEEP HOLDING · 5.0 s")

    @Slot()
    def _tick_hold(self) -> None:
        if not self._hold_active:
            return
        if not self._run_ready() or not self.run_button.isDown():
            self._cancel_hold()
            return
        elapsed = (time.monotonic() - self._hold_started) * 1000
        self.hold_progress.setValue(min(int(elapsed), 5000))
        if elapsed < 5000:
            self.run_button.setText(f"KEEP HOLDING · {(5000 - elapsed) / 1000:.1f} s")
            return
        self._hold_active = False
        self._hold_timer.stop()
        self._run_pending = True
        self._pending_timer.start()
        self._update_controls()
        self.action_requested.emit("run", None)

    @Slot()
    def _cancel_hold(self) -> None:
        self._hold_active = False
        self._hold_timer.stop()
        self.hold_progress.setValue(0)
        if hasattr(self, "run_button"):
            self.run_button.setText("RUN REQUEST SENT" if self._run_pending else "HOLD 5 s TO RUN")

    @Slot()
    def _release_pending(self) -> None:
        self._run_pending = False
        self._update_controls()

    @Slot()
    def _stop(self) -> None:
        self._cancel_hold()
        self._run_pending = False
        self._pending_timer.stop()
        # STOP may discard an enable that has not yet run in the worker. Revoke
        # that pending intent explicitly; retain already-confirmed authority.
        if self._authorization_pending["enable_control"] is True:
            self.arm_checkbox.setChecked(False)
        if self._authorization_pending["enable_service"] is True:
            self.service_checkbox.setChecked(False)
        if self._connected:
            self.action_requested.emit("stop", None)
            self.statusBar().showMessage("STOP requested · awaiting controller confirmation")
        self._update_controls()

    @Slot(bool)
    def _arm_changed(self, enabled: bool) -> None:
        self._authorization_pending["enable_control"] = bool(enabled)
        if not enabled:
            self._cancel_hold()
            if hasattr(self, "service_checkbox"):
                self.service_checkbox.setChecked(False)
        self.action_requested.emit("enable_control", bool(enabled))
        self._update_controls()

    @Slot(bool)
    def _service_toggled(self, enabled: bool) -> None:
        self._authorization_pending["enable_service"] = bool(enabled)
        self.action_requested.emit("enable_service", bool(enabled))
        self._update_controls()

    @Slot()
    def _apply_current(self) -> None:
        if not self.apply_current_button.isEnabled():
            return
        self.action_requested.emit("set_current", self.current_input.value())

    @Slot()
    def _apply_qswitch(self) -> None:
        if not self.apply_qswitch_button.isEnabled():
            return
        value = self.qswitch_combo.currentData()
        if value is None:
            return
        if value == 1 and not self._service_ready():
            QMessageBox.information(self, "Service setting", "Enable service parameter editing in the Service tab before selecting Hold off.")
            return
        self.action_requested.emit("set_qswitch", int(value))

    @Slot()
    def _reset(self) -> None:
        if self.reset_button.isEnabled():
            self.action_requested.emit("reset", None)

    @Slot()
    def _apply_soft_start(self) -> None:
        if not self._service_ready():
            return
        answer = QMessageBox.question(
            self, "Apply original soft start",
            "Send the original soft-start setting to the stopped controller?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel,
        )
        if answer == QMessageBox.StandardButton.Yes and self._service_ready():
            self.action_requested.emit("service_set", {"key": "soft_start_enabled", "value": True})

    def _apply_service(self, key: str) -> None:
        if not self._service_ready() or key not in self._service_initialized:
            return
        readback, editor, button = self.service_widgets[key]
        if not button.isEnabled():
            return
        if isinstance(editor, QComboBox):
            value = editor.currentData()
            if not isinstance(value, bool):
                return
            value_text = "Enabled" if value else "Disabled"
        else:
            try:
                value = float(editor.text().strip())
                if not math.isfinite(value):
                    raise ValueError
            except ValueError:
                QMessageBox.information(self, "Invalid value", "Enter a finite numeric value.")
                return
            value_text = f"{value:g}"
        _, caption, unit, _ = next(field for field in self.SERVICE_FIELDS if field[0] == key)
        payload = {"key": key, "value": value, "access_code": self.service_access_code.text()}
        numeric_field_mode = "blank → 0" if not self.service_access_code.text().strip() else "provided; hidden"
        if key == "qswitch_frequency_khz":
            try:
                nominal = float(self.nominal_frequency_input.text().strip())
                if not math.isfinite(nominal) or nominal <= 0:
                    raise ValueError
            except ValueError:
                QMessageBox.information(self, "Factory frequency required", "Enter the factory nominal frequency in kHz before changing the internal Q-switch frequency.")
                return
            payload["nominal_frequency_khz"] = nominal
        answer = QMessageBox.question(
            self, "Confirm service parameter change",
            f"{caption}\n\nConfirmed readback: {readback.text()} {unit}\nRequested value: {value_text} {unit}\n"
            f"Service numeric field: {numeric_field_mode}\n\n"
            "Only controller readback confirms application.\n\nWrite this one parameter to the controller?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel,
        )
        if answer == QMessageBox.StandardButton.Yes and self._service_ready():
            self.action_requested.emit("service_set", payload)
            # The editor represents operator intent; only the Readback column
            # follows the device. Older queued polls must not erase a request.
            self._service_dirty.add(key)

    @Slot(str)
    def append_log(self, line: str) -> None:
        line = str(line)
        self.comm_log.appendPlainText(line)
        if not any(token in line.upper() for token in (" TX ", " RX ", " RX_BYTES ", "TX:", "RX:", "RX_BYTES:")):
            self.status_log.appendPlainText(line)

    def _export_log(self, text: str, default_name: str) -> None:
        self._cancel_hold()
        path, _ = QFileDialog.getSaveFileName(self, "Export displayed log", default_name, "Text files (*.txt);;All files (*)")
        if path:
            try:
                Path(path).write_text(text + "\n", encoding="utf-8")
            except OSError as exc:
                QMessageBox.warning(self, "Export failed", str(exc))
            else:
                self.statusBar().showMessage(f"Log exported to {path}")

    @Slot(Qt.ApplicationState)
    def _application_state_changed(self, state: Qt.ApplicationState) -> None:
        if state != Qt.ApplicationState.ApplicationActive:
            self._cancel_hold()

    def eventFilter(self, watched: Any, event: QEvent) -> bool:
        if watched is self.run_button:
            if event.type() in (QEvent.Type.Leave, QEvent.Type.FocusOut, QEvent.Type.Hide, QEvent.Type.WindowDeactivate):
                self._cancel_hold()
            if event.type() in (QEvent.Type.KeyPress, QEvent.Type.KeyRelease) and event.isAutoRepeat():
                return True
        if watched is self and event.type() in (QEvent.Type.WindowDeactivate, QEvent.Type.Hide):
            self._cancel_hold()
        return super().eventFilter(watched, event)

    def closeEvent(self, event: QCloseEvent) -> None:
        self._cancel_hold()
        if self.allow_close:
            event.accept()
            return
        event.ignore()
        if not self._close_pending:
            self._close_pending = True
            self.closeRequested.emit()
