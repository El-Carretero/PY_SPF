"""Per-session, append-only wire/event/measurement logs."""
import csv
import json
import os
from datetime import datetime, timezone
from pathlib import Path


def timestamp():
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def wire_text(data):
    # Service access code is deliberately neither persisted nor displayed.
    parts = data.hex(" ").split()
    if len(data) == 23 and data[5] == 0x50 and any(data[7:9]):
        parts[7:9] = ["**", "**"]
        parts[-1] = "**"
    return " ".join(parts)


class SessionLog:
    def __init__(self, directory=None):
        root = Path(directory) if directory else Path(os.environ.get("LOCALAPPDATA", Path.home())) / "EmpowerPython" / "logs"
        root.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        self.path = root / (stamp + "_session.jsonl")
        self.csv_path = root / (stamp + "_readings.csv")
        self.events = self.path.open("a", encoding="utf-8", buffering=1)
        try:
            self.readings = self.csv_path.open("a", encoding="utf-8", newline="", buffering=1)
            try:
                self.writer = csv.writer(self.readings)
                self.writer.writerow(["time_utc", "simulated", "state", "comm_ok", "power_w", "current_a", "current_set_a", "faults"])
            except BaseException:
                self.readings.close()
                raise
        except BaseException:
            self.events.close()
            raise

    def event(self, kind, **data):
        self.events.write(json.dumps({"time": timestamp(), "kind": kind, **data}, ensure_ascii=False) + "\n")

    def trace(self, direction, data):
        self.event("wire", direction=direction, hex=wire_text(data))

    def snapshot(self, s):
        self.writer.writerow([timestamp(), s.get("simulated"), s.get("state"), s.get("comm_ok"), s.get("power_w"), s.get("current_a"), s.get("current_set_a"), "; ".join(s.get("faults", []))])

    def close(self):
        try:
            self.events.close()
        finally:
            self.readings.close()
