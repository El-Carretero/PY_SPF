"""Deterministic protocol emulator, not a physical laser model or XP oracle.

Simulated response layouts follow static EXE evidence, not the later captured
firmware variant. It exercises the same framing/parser/driver as serial mode.
"""
import time
from collections import deque
from .framing import decode, ProtocolError


def response(opcode, length):
    data = bytearray(length)
    data[:7] = b"\x10\x02\x00\x00" + bytes((length, opcode, 2))
    return data


def put16(data, offset, value):
    data[offset:offset + 2] = int(value).to_bytes(2, "big")


class SimulatedTransport:
    def __init__(self, trace=None, clock=time.monotonic):
        self.trace = trace or (lambda direction, data: None)
        self.clock = clock
        self.pending = deque()
        self.closed = False
        self.state = 1  # STOP
        self.started = None
        self.current_word = 0
        self.frequency_word = 100
        self.pulse_word = 1
        self.qswitch = 2
        self.fault_bytes = bytearray(3)
        self.lbo_c = 150.0
        self.underfrequency = True
        self.softstart = True
        self.service_words = [250, 100, 0, 3000, 1600, 1400]
        self.drop_responses = False

    def _tick(self):
        if any(self.fault_bytes):
            self.state = 2
            self.started = None
        elif self.state == 3 and self.clock() - self.started >= 3.0:
            self.state = 0

    def _reply(self, raw):
        if self.drop_responses:
            return
        self.trace("RX_BYTES", bytes(raw))
        self.pending.append(decode(bytes(raw), verify_checksum=False))

    def send(self, raw):
        if self.closed:
            raise OSError("Simulator is closed")
        frame = decode(raw)  # TX checksum is independently enforced.
        self.trace("TX", raw)
        self._tick()
        op = frame.opcode
        if op == 0x42:
            r = response(0x62, 11)
            r[9:11] = b"\x01\x01"
        elif op == 0x02 or op == 0x01:
            if op == 0x01:
                if len(raw) != 17:
                    raise ProtocolError("Bad operating packet")
                value = int.from_bytes(raw[14:16], "big")
                if value > self.service_words[0]:
                    self.fault_bytes[1] |= 4
                else:
                    self.current_word = value
                    self.frequency_word = int.from_bytes(raw[8:10], "big")
                    self.pulse_word = int.from_bytes(raw[10:12], "big")
                self._tick()
            r = response(0x11 if op == 0x01 else 0x12, 29)
            r[7:10] = self.fault_bytes
            if self.underfrequency:
                r[9] |= 0x80
            put16(r, 10, self.frequency_word)
            put16(r, 12, self.pulse_word)
            put16(r, 20, self.current_word)
            put16(r, 22, self.current_word if self.state == 0 else 0)
            r[24:28] = (123 * 3600).to_bytes(4, "big")
            r[28] = self.state
        elif op == 0x08:
            if raw[7] == 1:
                self.state = 2 if any(self.fault_bytes) else 1
                self.started = None
            elif raw[7] == 0 and not any(self.fault_bytes) and self.qswitch in (2, 3):
                self.state = 3
                self.started = self.clock()
            return
        elif op in (0x55, 0x51):
            if op == 0x51:
                if raw[7] not in (1, 2, 3):
                    raise ProtocolError("Invalid Q-switch source")
                self.qswitch = raw[7]
                self.state = 2 if any(self.fault_bytes) else 1
                self.started = None
            r = response(0x75, 8)
            r[7] = self.qswitch
        elif op == 0x52:
            r = response(0x72, 9)
            # Illustrative synthetic signal, NOT the instrument calibration.
            power = max(0.0, self.current_word / 10 - 8.0) * 1.1 if self.state == 0 else 0.0
            put16(r, 7, round(power * 100))
        elif op == 0x0B:
            r = response(0x1A, 13)
            put16(r, 11, self.lbo_c * 10)
        elif op == 0x50:
            if len(raw) != 23:
                raise ProtocolError("Bad service packet")
            # Synthetic policy: zero ignores edits, any nonzero value accepts.
            # This is NOT evidence of device authorization or a valid code.
            if int.from_bytes(raw[7:9], "big"):
                self.service_words = [int.from_bytes(raw[i:i + 2], "big") for i in (9, 12, 14, 16, 18, 20)]
            r = response(0x70, 20)
            for i, word in zip((7, 10, 12, 14, 16, 18), self.service_words):
                put16(r, i, word)
        elif op == 0x09:
            # Fault RESET is not a softstart query. The captured FW1.2
            # controller replies with opaque ACK18; fresh status determines
            # whether a fault remains. Continuing synthetic faults persist.
            if not any(self.fault_bytes):
                self.state = 1
                self.started = None
            r = response(0x18, 8)
        elif op == 0x49:
            if len(raw) != 11:
                raise ProtocolError("Bad softstart packet")
            self.softstart = bool(raw[7])
            r = response(0x69, 10)
            r[7] = int(self.softstart)
            r[9] = int.from_bytes(raw[8:10], "big") & 0xff
        elif op == 0x53:
            self.underfrequency = bool(raw[7])
            r = response(0x73, 10)
            r[9] = 0x80 if self.underfrequency else 0
        else:
            raise ProtocolError(f"Unsupported simulator opcode {op:#x}")
        self._reply(r)

    def receive(self, expected=None, timeout=None):
        while self.pending:
            frame = self.pending.popleft()
            if expected is None or frame.opcode in expected:
                return frame
        raise TimeoutError("Simulated communication failure")

    def exchange(self, raw, expected):
        self.pending.clear()
        self.send(raw)
        return self.receive(set(expected))

    def inject_fault(self, fault):
        text = str(fault).lower()
        if "comm" in text or "timeout" in text:
            self.drop_responses = True
            return
        if "key" in text:
            self.fault_bytes[1] |= 0x20
        elif "cover" in text:
            self.fault_bytes[1] |= 0x40
        elif "freq" in text:
            self.fault_bytes[1] |= 0x02
        elif "overcurrent" in text:
            self.fault_bytes[1] |= 0x04
        elif "temp" in text or "lbo" in text:
            self.fault_bytes[2] |= 0x02
        else:
            self.fault_bytes[1] |= 0x80
        self._tick()

    def clear_faults(self):
        self.fault_bytes[:] = b"\x00\x00\x00"
        self.drop_responses = False
        self.state = 1
        self.started = None

    def close(self):
        self.closed = True
