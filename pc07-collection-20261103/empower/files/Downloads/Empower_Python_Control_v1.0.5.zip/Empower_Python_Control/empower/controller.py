"""Single serial owner, cancellable writes and unconditional session cleanup."""
from __future__ import annotations
import threading
import time
from collections import deque
from copy import deepcopy
from .device import Device, SettingReadbackWarning, ActionCancelled
from .simulator import SimulatedTransport
from .transport import SerialTransport
from .sessionlog import SessionLog, timestamp, wire_text
from . import commands
from . import __version__


class SessionController:
    CONTROL_ACTIONS = frozenset(("run", "set_current", "set_qswitch", "reset", "service_set"))

    def __init__(self, notify, log_directory=None):
        self.notify = notify
        self.log_directory = log_directory
        self.condition = threading.Condition()
        self.queue = deque()
        self.device = None
        self.log = None
        self.running = True
        self.output_unknown = False
        self.previous_faults = None
        self.previous_compatibility = None
        self._shutdown_requested = False
        self._disconnect_requested = False
        self._control_revoked = False
        self._service_revoked = False
        self.thread = threading.Thread(target=self._work, name="Empower-serial", daemon=False)
        self.thread.start()

    @staticmethod
    def _revocation(item):
        return item[0] in ("enable_control", "enable_service") and not bool(item[1])

    def submit(self, name, value=None):
        with self.condition:
            if not self.running or self._shutdown_requested:
                return
            if name == "shutdown":
                self._shutdown_requested = True
                self.queue.clear()
                self.queue.append((name, value))
            elif self._disconnect_requested:
                return
            elif name == "disconnect":
                self._disconnect_requested = True
                self.queue.clear()
                self.queue.append((name, value))
            elif name == "stop":
                self.queue = deque(item for item in self.queue if self._revocation(item))
                self.queue.appendleft((name, value))
            elif self._revocation((name, value)):
                if name == "enable_control":
                    self._control_revoked = self._service_revoked = True
                    discard = self.CONTROL_ACTIONS | {"enable_control", "enable_service"}
                else:
                    self._service_revoked = True
                    discard = {"service_set", "enable_service"}
                self.queue = deque(item for item in self.queue if item[0] not in discard)
                offset = 1 if self.queue and self.queue[0][0] == "stop" else 0
                self.queue.insert(offset, (name, value))
            else:
                self.queue.append((name, value))
            self.condition.notify()

    def _notify(self, name, value):
        # Frontend delivery must never prevent STOP/port cleanup.
        try:
            self.notify(name, value)
        except Exception:
            pass

    def _close_log(self):
        log, self.log = self.log, None
        if log is not None:
            try:
                log.close()
            except Exception as error:
                self._notify("log", f"{timestamp()}  Capture log could not close: {error}")

    def _record(self, method, *args, **kwargs):
        if self.log is None:
            return
        try:
            getattr(self.log, method)(*args, **kwargs)
        except Exception as error:
            self._close_log()
            message = f"Capture logging disabled: {error}. Device control remains active."
            self._notify("log", f"{timestamp()}  {message}")
            self._notify("warning", message)

    def _message(self, text):
        self._notify("log", f"{timestamp()}  {text}")
        self._record("event", "message", text=text)

    def _trace(self, direction, data):
        self._record("trace", direction, data)
        self._notify("log", f"{timestamp()}  {direction}  {wire_text(data)}")

    def _publish(self):
        if not self.device:
            return
        snapshot = self.device.snapshot()
        with self.condition:
            snapshot["control_enabled"] = bool(self.device.enabled and not self._control_revoked)
            snapshot["service_enabled"] = bool(self.device.enabled and self.device.service_enabled
                                               and not self._control_revoked and not self._service_revoked)
        snapshot["product_version"] = __version__
        snapshot["log_path"] = str(self.log.path) if self.log else ""
        snapshot["service"]["communication_drops"] = None
        compatibility = snapshot.get("compatibility_details") or snapshot.get("compatibility", "")
        if compatibility and compatibility != self.previous_compatibility:
            self._message(compatibility)
            self.previous_compatibility = compatibility
        self._notify("snapshot", snapshot)
        self._record("snapshot", snapshot)
        faults = tuple(snapshot.get("faults", []))
        if self.previous_faults != faults:
            if faults:
                self._message("ACTIVE FAULTS: " + "; ".join(faults))
            elif self.previous_faults:
                self._message("Active faults cleared in device readback")
            self.previous_faults = faults

    def _connect(self, port):
        if self.device:
            raise ValueError("Disconnect the current session first")
        self._close_log()
        try:
            self.log = SessionLog(self.log_directory)
        except Exception as error:
            self._notify("warning", f"Capture log unavailable: {error}. Device control can continue.")
        self.previous_faults = None
        self.previous_compatibility = None
        simulated = port == "SIMULATOR"
        self._message(f"Opening {'simulator' if simulated else port} at 19200 baud, 8N1")
        transport = SimulatedTransport(self._trace) if simulated else SerialTransport(port, self._trace)
        try:
            self.device = Device(transport, simulated)
        except Exception:
            transport.close()
            raise
        self.device.interrupt_poll = self._priority_pending
        self.device.interrupt_write = self._write_cancelled
        self.device.initialize()
        self.device.enabled = simulated
        self.output_unknown = False
        self._notify("connection", (True, "SIMULATOR" if simulated else port))
        self._publish()
        self._message("Connected; " + ("synthetic demo readings" if simulated else
                                       "session control is disabled until explicitly enabled"))

    def _priority_pending(self):
        with self.condition:
            return self._shutdown_requested or self._disconnect_requested or any(
                name == "stop" for name, _ in self.queue)

    def _write_cancelled(self, service=False):
        with self.condition:
            return self._control_revoked or (service and self._service_revoked)

    def _clear_revocation(self, name, value):
        if not self._revocation((name, value)):
            return
        with self.condition:
            if name == "enable_control":
                self._control_revoked = False
                self._service_revoked = False
            else:
                self._service_revoked = False

    def _detach_device(self):
        device = self.device
        if device is None:
            return
        try:
            device.connection_failed()
            device.data["connected"] = False
            self._publish()
        finally:
            try:
                device.transport.close()
            except Exception as error:
                self._notify("error", f"Serial port close failed: {error}")
            finally:
                self.device = None

    def _disconnect(self):
        if self.device:
            try:
                self.device.action("stop")
                self.output_unknown = False
                self._message(f"STOP request completed; controller state: {self.device.data.get('state', 'UNKNOWN')}")
            except Exception as error:
                self.output_unknown = True
                self._message(f"STOP could not be confirmed: {error}. Use the physical keyswitch/interlock")
            finally:
                self._detach_device()
        with self.condition:
            self._disconnect_requested = False
            self._control_revoked = self._service_revoked = False
        self._notify("connection", (False, "Disconnected — output unknown" if self.output_unknown else "Disconnected"))

    def _failure(self, error):
        self.output_unknown = True
        self._message(f"COMMUNICATION LOST: {error}. Output state is UNKNOWN; use physical controls")
        with self.condition:
            self.queue = deque(item for item in self.queue if item[0] in ("disconnect", "shutdown"))
            self._control_revoked = self._service_revoked = False
        if self.device:
            try:
                self.device.transport.send(commands.set_run(False))
            except Exception:
                pass
            finally:
                self._detach_device()
        self._notify("connection", (False, "Communication lost — output unknown"))
        self._notify("error", str(error) + "\nOutput state is unknown. Use the physical keyswitch/interlock.")

    def _result(self, name, value, ok):
        payload = {"name": name, "ok": bool(ok)}
        if name in ("enable_control", "enable_service"):
            payload["value"] = bool(value)
        self._notify("action_result", payload)

    def _work(self):
        next_poll = 0.0
        try:
            while self.running:
                with self.condition:
                    delay = max(0, next_poll - time.monotonic()) if self.device else None
                    if not self.queue:
                        self.condition.wait(delay)
                    task = self.queue.popleft() if self.queue else None
                if task:
                    name, value = task
                    ok = False
                    already_connected = self.device is not None
                    try:
                        if name == "connect":
                            self._connect(str(value))
                        elif name in ("disconnect", "shutdown"):
                            if name == "shutdown":
                                self.running = False
                            self._disconnect()
                        elif self.device:
                            printable = deepcopy(value)
                            if isinstance(printable, dict):
                                printable.pop("access_code", None)
                            self._message(f"Action {name}: {printable}")
                            self.device.action(name, value)
                            self._clear_revocation(name, value)
                            self._publish()
                        elif self._revocation((name, value)):
                            self._clear_revocation(name, value)
                        else:
                            raise ValueError("No active connection")
                        ok = True
                    except ActionCancelled as error:
                        self._message(str(error))
                        if name == "connect":
                            self._disconnect()
                        else:
                            self._publish()
                    except SettingReadbackWarning as warning:
                        with self.condition:
                            self.queue = deque(item for item in self.queue if
                                               item[0] in ("stop", "disconnect", "shutdown",
                                                           "enable_control", "enable_service"))
                        self._message(f"SETTING WARNING: {warning}")
                        self._publish()
                        self._notify("warning", str(warning))
                    except (ValueError, TypeError, KeyError) as error:
                        if name == "connect" and not already_connected:
                            self._failure(error)
                        else:
                            self._message(f"Action rejected: {error}")
                            self._publish()
                            self._notify("error", str(error))
                    except Exception as error:
                        self._failure(error)
                    finally:
                        self._result(name, value, ok)
                    next_poll = time.monotonic() + 1.0
                elif self.device:
                    try:
                        self.device.poll()
                        self._publish()
                    except Exception as error:
                        self._failure(error)
                    next_poll = time.monotonic() + 1.0
        finally:
            self.running = False
            if self.device is not None:
                try:
                    self._disconnect()
                except Exception as error:
                    self.output_unknown = True
                    self._notify("error", f"Session cleanup failed: {error}. Use physical controls.")
                    if self.device is not None:
                        try:
                            self.device.transport.close()
                        except Exception:
                            pass
                        self.device = None
            closed_log = self.log
            self._close_log()
            self.log = closed_log
            self._notify("ended", not self.output_unknown)
