"""One-owner serial transport with bounded timeouts and packet logging."""
import time
from collections import deque
from .framing import FrameBuffer, ProtocolError


class SerialTransport:
    def __init__(self, port, trace=None, timeout=0.7):
        import serial
        self.timeout = timeout
        self.trace = trace or (lambda direction, data: None)
        self.decoder = FrameBuffer()
        self.pending = deque()
        # Same baud/format as original. Do not use serial_for_url: a typo must
        # not silently select a network device or a loopback.
        self.serial = serial.Serial(port=None, baudrate=19200, bytesize=8,
                                    parity="N", stopbits=1, timeout=0.03,
                                    write_timeout=0.5, xonxoff=False,
                                    rtscts=False, dsrdtr=False)
        self.serial.port = port
        self.serial.open()
        self.serial.reset_input_buffer()

    def send(self, raw):
        count = self.serial.write(raw)
        self.trace("TX", raw)
        if count != len(raw):
            raise ProtocolError("Short serial write; command outcome unknown")

    def receive(self, expected=None, timeout=None):
        deadline = time.monotonic() + (self.timeout if timeout is None else timeout)
        observed = []
        while time.monotonic() < deadline:
            if self.pending:
                frame = self.pending.popleft()
                if expected is None or frame.opcode in expected:
                    return frame
                observed.append(frame.opcode)
                # Unmatched packets are logged but not reused as fresh data.
                continue
            data = self.serial.read(max(1, min(4096, self.serial.in_waiting)))
            if data:
                self.trace("RX_BYTES", data)
                self.pending.extend(self.decoder.feed(data))
        # A partial response must never become the next transaction's reply.
        self.decoder.buffer.clear()
        wanted = "/".join(f"0x{x:02X}" for x in sorted(expected or [])) or "any opcode"
        seen = "/".join(f"0x{x:02X}" for x in sorted(set(observed))) or "no complete frame"
        raise TimeoutError(f"Empower response timeout: expected {wanted}; received {seen}")

    def exchange(self, raw, expected):
        # A single owner serializes exchanges. Do not retry mutations here.
        # Do not reuse pre-request packets as current readback. A timed-out
        # exchange closes the session in the controller, preventing late-reply
        # reuse after a failed request. This protocol has no transaction ID.
        self.pending.clear()
        self.decoder.buffer.clear()
        self.serial.reset_input_buffer()
        self.send(raw)
        return self.receive(set(expected))

    def close(self):
        self.serial.close()
