"""Independent Python implementation of the Empower 3.02.00 control interface."""
__version__ = "1.0.5"
