"""Independent v1.0.5 capture review, runnable without the source log files.

CAPTURED_* bytes are literal reassembled uploaded frames. Explicit SYNTHETIC
mutations below test unobserved conditions and do not claim device behavior.
Full logs, personal metadata, and any user-entered codes are not included.
"""
import unittest

from empower import commands
from empower.device import Device
from empower.framing import Frame, decode
from empower.responses import parse_response


# Latest: 01-20260923_225748_481930_session.jsonl.
CAPTURED_FIRMWARE = bytes.fromhex('10 02 00 00 0c 62 00 48 43 01 02 0e')
CAPTURED_COM_FAULT = bytes.fromhex(
    '10 02 00 00 1e 12 00 00 00 90 00 64 00 28 00 00 89 34 00 65 '
    '00 00 00 03 01 47 ca 3b 02 d2')
CAPTURED_KEY_FAULT = bytes.fromhex(
    '10 02 00 00 1e 12 00 00 20 80 00 64 00 28 00 00 89 34 00 65 '
    '00 00 00 02 01 47 ca 3b 02 e1')
CAPTURED_LAST_STOP = bytes.fromhex(
    '10 02 00 00 1e 12 00 00 00 80 00 64 00 28 00 00 89 34 00 63 '
    '00 00 00 02 01 47 ca 3b 01 be')
# Real LBO replies have sixteen bytes, including additional uninterpreted data.
CAPTURED_LBO_MIN = bytes.fromhex('10 02 00 00 10 1a 00 89 34 00 63 04 ff 00 00 5f')
CAPTURED_LBO_MAX = bytes.fromhex('10 02 00 00 10 1a 00 89 34 00 64 05 0c 00 00 6e')
CAPTURED_POWER_ZERO = bytes.fromhex('10 02 00 00 0a 72 00 00 00 8e')
CAPTURED_SERVICE125 = bytes.fromhex(
    '10 02 00 00 15 70 00 00 fa 00 02 58 00 00 30 d4 05 46 04 9c da')
CAPTURED_POWER150_TX = bytes.fromhex(
    '10 02 00 00 17 50 02 00 00 00 fa 00 02 58 00 00 3a 98 05 46 04 9c 8c')
CAPTURED_POWER120_TX = bytes.fromhex(
    '10 02 00 00 17 50 02 00 00 00 fa 00 02 58 00 00 2e e0 05 46 04 9c c8')
# Earlier full session: 01-20260923_214626_334886_session.jsonl.
CAPTURED_SOFTSTART_ACK = bytes.fromhex('10 02 00 00 0b 69 00 01 00 01 88')
CAPTURED_UNDERFREQUENCY_ACK = bytes.fromhex(
    '10 02 00 00 1e 73 00 00 00 80 00 64 00 28 00 00 89 34 00 62 '
    '00 00 00 03 01 47 c9 64 01 47')


def parsed(raw):
    return parse_response(decode(raw, verify_checksum=True), (1, 2))


def synthetic_change(raw, changes):
    body = bytearray(raw)
    for offset, value in changes.items():
        body[offset] = value
    body[-1] = sum(body[:-1]) & 255
    return bytes(body)


class CaptureReview105(unittest.TestCase):
    def test_literal_fixtures_validate_without_external_uploads(self):
        fixtures = [v for k, v in globals().items() if k.startswith('CAPTURED_')]
        self.assertEqual(len(fixtures), 12)
        for raw in fixtures:
            with self.subTest(raw=raw.hex()):
                self.assertEqual(raw[4], len(raw))
                self.assertEqual(decode(raw, verify_checksum=True).raw, raw)

    def test_real_extended_lbo_and_configuration_reply_layouts(self):
        # Covers lengths absent from the initial short synthetic fixtures.
        self.assertEqual(len(CAPTURED_LBO_MIN), 16)
        self.assertEqual(parsed(CAPTURED_LBO_MIN)['service']['lbo_temp_c'], 127.9)
        self.assertEqual(parsed(CAPTURED_LBO_MAX)['service']['lbo_temp_c'], 129.2)
        self.assertEqual(parsed(CAPTURED_SOFTSTART_ACK)['service']['soft_start_rate_a_s'], .5)
        protection = parsed(CAPTURED_UNDERFREQUENCY_ACK)
        self.assertEqual(protection, {'service': {'underfrequency_enabled': True}})
        self.assertNotIn('state', protection)  # Status-shaped73 is not opcode12.

    def test_latest_fault_clear_sequence_does_not_conflate_configuration_bit(self):
        results = [parsed(raw) for raw in (CAPTURED_COM_FAULT, CAPTURED_KEY_FAULT, CAPTURED_LAST_STOP)]
        self.assertEqual([r['state'] for r in results], ['FAULT', 'FAULT', 'STOP'])
        self.assertEqual([r['faults'] for r in results], [['Communication'], ['Key switch'], []])
        self.assertEqual([r['raw_status'] for r in results], ['00 00 90', '00 20 80', '00 00 80'])
        self.assertTrue(all(r['service']['underfrequency_enabled'] for r in results))
        self.assertTrue(all(r['unknown_status_bits'] == {} for r in results))
        self.assertTrue(all(r['emission'] is False for r in results))

    def test_all_fifteen_fault_bits_independently_of_production_mapping_table(self):
        # SYNTHETIC one-bit mutations, expectations from original indicator IDs.
        cases = [(7, 1, 'Array overtemperature'), (7, 2, 'Driver overtemperature'),
                 (7, 8, 'Driver overpower'), (7, 16, 'Driver protective fault'),
                 (7, 32, 'Q-switch overtemperature'), (7, 64, 'VSWR'),
                 (8, 2, 'Underfrequency'), (8, 4, 'Overcurrent'),
                 (8, 8, 'Overvoltage'), (8, 32, 'Key switch'),
                 (8, 64, 'Cover interlock'), (8, 128, 'Water flow'),
                 (9, 1, 'Array overpower'), (9, 2, 'LBO temperature'),
                 (9, 16, 'Communication')]
        for offset, bit, name in cases:
            with self.subTest(offset=offset, bit=bit):
                changes = {7: 0, 8: 0, 9: 0x80, 28: 2}
                changes[offset] |= bit
                result = parsed(synthetic_change(CAPTURED_LAST_STOP, changes))
                self.assertEqual(result['faults'], [name])
                self.assertEqual(result['unknown_status_bits'], {})
                self.assertTrue(result['service']['underfrequency_enabled'])

    def test_power_readout_cannot_be_replaced_by_service_maximum(self):
        # Actual session reports MaxPower125 while optical response is zero.
        d = Device(object())
        # Establish the operating state before its independent power sample;
        # state changes invalidate earlier samples. A later service response
        # must neither replace power with MaxPower nor erase a fresh sample.
        for raw in (CAPTURED_FIRMWARE, CAPTURED_LAST_STOP, CAPTURED_POWER_ZERO, CAPTURED_SERVICE125):
            d._merge(Frame(raw))
        self.assertEqual(d.data['power_w'], 0)
        self.assertEqual(d.data['service']['max_power_mw'], 125)
        self.assertTrue(d.data['service_units_unverified'])
        self.assertEqual(d.data['service']['_raw_words']['max_power'], 12500)

    def test_two_captured_zero_code_writes_do_not_prove_application(self):
        words = parsed(CAPTURED_SERVICE125)['service']['_raw_words']
        for request, value in ((CAPTURED_POWER150_TX, 150), (CAPTURED_POWER120_TX, 120)):
            with self.subTest(value=value):
                desired = {**words, 'max_power': value * 100}
                self.assertEqual(commands.set_service_words(0, desired), request)
                self.assertEqual(request[7:9], b'\x00\x00')
                # Captured ACK and subsequent service reads still both125.
                self.assertNotEqual(parsed(CAPTURED_SERVICE125)['service']['max_power_mw'], value)
                self.assertEqual(request[9:16], b'\x00\xfa\x00\x02\x58\x00\x00')
                self.assertEqual(request[18:22], b'\x05\x46\x04\x9c')

    def test_synthetic_source_zero_does_not_inherit_previous_external_confirmation(self):
        # No source0 was captured; this regression prevents stale3 masking it.
        d = Device(object())
        d._merge(Frame(CAPTURED_FIRMWARE))
        d._merge(Frame(bytes.fromhex('10 02 00 00 09 75 00 03 93')))
        self.assertEqual(d.data['qswitch'], 3)
        d._merge(Frame(bytes.fromhex('10 02 00 00 09 75 00 00 90')))
        self.assertEqual(d.data['qswitch'], 0)
        self.assertNotIn(d.data['qswitch'], (2, 3))


if __name__ == '__main__':
    unittest.main()
