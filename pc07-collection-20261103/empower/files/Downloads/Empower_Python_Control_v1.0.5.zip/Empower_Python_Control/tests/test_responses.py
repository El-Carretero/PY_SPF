"""Regression fixtures transcribed from static response offset evidence.

These are synthetic packets, not recordings from a physical Empower.
"""
import unittest
from empower.framing import Frame, ProtocolError
from empower.responses import parse_response

# 29-byte response: state is final byte, no inferred checksum appended.
STATUS = bytes.fromhex(
    "10 02 00 00 1d 12 02 00 00 80 03 e8 00 10 00 00 00 00 00 00 "
    "00 fa 00 f9 00 00 0e 10 01"
)
SERVICE = bytes.fromhex(
    "10 02 00 00 14 70 02 00 fa 00 03 e8 00 32 02 58 06 40 04 b0"
)


class ResponseFixtures(unittest.TestCase):
    def test_status_readings_and_source_units(self):
        result = parse_response(Frame(STATUS), (3, 2))
        self.assertEqual(result["state"], "STOP")
        self.assertFalse(result["emission"])
        self.assertEqual(result["current_set_a"], 25)
        self.assertEqual(result["current_a"], 24.9)
        self.assertEqual(result["hours"], 1)
        self.assertEqual(result["service"]["qswitch_frequency_khz"], 10)
        self.assertEqual(result["service"]["qswitch_pulse_width_ns"], 2000)
        self.assertTrue(result["service"]["underfrequency_enabled"])
        self.assertEqual(result["faults"], [])
        self.assertEqual(result["unknown_status_bits"], {})

    def test_final_state_byte_and_emission(self):
        for code, name in enumerate(("RUN", "STOP", "FAULT", "COUNTDOWN")):
            with self.subTest(state=code):
                result = parse_response(Frame(STATUS[:-1] + bytes([code])))
                self.assertEqual(result["state"], name)
                self.assertEqual(result["emission"], code in (0, 3))
        self.assertEqual(parse_response(Frame(STATUS[:-1] + b"\xff"))["state"], "UNKNOWN (255)")

    def test_firmware_scale_does_not_guess(self):
        self.assertEqual(parse_response(Frame(STATUS), (0, 1))["service"]["qswitch_frequency_khz"], 100)
        self.assertIsNone(parse_response(Frame(STATUS))["service"]["qswitch_frequency_khz"])
        with self.assertRaises(ProtocolError):
            parse_response(Frame(STATUS), (True, 1))

    def test_service_values_preserve_original_labels(self):
        result = parse_response(Frame(SERVICE))
        self.assertEqual(result["max_current_a"], 25)
        self.assertTrue(result["service_units_unverified"])
        self.assertEqual(result["service"]["max_power_mw"], 6)
        self.assertEqual(result["service"]["power_slope_mw_v"], 10)
        self.assertEqual(result["service"]["power_intercept_mw"], 0.5)
        self.assertEqual(result["service"]["lbo_high_c"], 160)
        self.assertEqual(result["service"]["lbo_low_c"], 120)
        self.assertEqual(result["service"]["_raw_words"]["max_power"], 600)

    def test_known_faults_and_unknown_bits_remain_separate(self):
        raw = bytearray(STATUS)
        raw[7:10] = b"\x04\x40\x92"
        result = parse_response(Frame(raw))
        self.assertEqual(result["faults"], ["Cover interlock", "Communication", "LBO temperature"])
        self.assertEqual(result["unknown_status_bits"], {7: 4})
        self.assertTrue(result["service"]["underfrequency_enabled"])

    def test_every_truncated_known_response_is_rejected(self):
        minimums = ((0x11, 29), (0x12, 29), (0x62, 11), (0x72, 9),
                    (0x1A, 13), (0x69, 10), (0x70, 20), (0x73, 10), (0x75, 8))
        for opcode, minimum in minimums:
            for length in range(minimum):
                with self.subTest(opcode=opcode, length=length):
                    raw = bytearray(length)
                    if length > 5:
                        raw[5] = opcode
                    with self.assertRaises(ProtocolError):
                        parse_response(Frame(raw))

    def test_short_readouts(self):
        self.assertEqual(parse_response(Frame(bytes.fromhex("10 02 00 00 09 72 02 02 58"))), {"power_w": 6})
        self.assertEqual(parse_response(Frame(bytes.fromhex("10 02 00 00 0b 62 02 00 00 01 03"))),
                         {"firmware": "1.3", "firmware_tuple": (1, 3)})
        self.assertEqual(parse_response(Frame(bytes.fromhex("10 02 00 00 0d 1a 02 00 00 00 00 05 dc")))["service"]["lbo_temp_c"], 150)
        self.assertEqual(parse_response(Frame(bytes.fromhex("10 02 00 00 0a 69 02 01 00 03")))["service"]["soft_start_rate_a_s"], 1.5)
        self.assertEqual(parse_response(Frame(bytes.fromhex("10 02 00 00 08 75 02 00"))), {"qswitch": 0})
        self.assertEqual(parse_response(Frame(bytes.fromhex("10 02 00 00 08 71 02 00"))), {})


if __name__ == "__main__":
    unittest.main()
