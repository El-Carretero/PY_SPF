"""Device integration checks against a deterministic simulated transport.

All packets remain synthetic; these checks do not establish hardware or XP
compatibility. Existing command/response fixture tests supply independent
byte-level checks instead of treating the emulator as a hardware oracle.
"""
import unittest

from empower.device import Device, CurrentReadbackWarning, ActionCancelled
from empower.framing import ProtocolError, Frame
from empower.simulator import SimulatedTransport


class FakeClock:
    def __init__(self):
        self.now = 0.0

    def __call__(self):
        return self.now

    def advance(self, seconds=1):
        self.now += seconds


class RefusingOperatingTransport(SimulatedTransport):
    """Return a valid but different setting readback, without retry semantics."""
    refuse_operating = False

    def _reply(self, raw):
        if self.refuse_operating and raw[5] == 0x11:
            raw = bytearray(raw)
            raw[20:22] = b"\x00\x01"
        super()._reply(raw)


class TruncatedStatusTransport(SimulatedTransport):
    truncate_status = False

    def _reply(self, raw):
        if self.truncate_status and raw[5] in (0x11, 0x12):
            raw = bytearray(raw[:-1])
            raw[4] = len(raw)
        super()._reply(raw)


class UnknownStateTransport(SimulatedTransport):
    def _reply(self, raw):
        if raw[5] in (0x11, 0x12):
            raw = bytearray(raw)
            raw[28] = 255
        super()._reply(raw)


class DeviceIntegration(unittest.TestCase):
    def setUp(self):
        self.clock = FakeClock()
        self.tx = []
        self.transport = SimulatedTransport(trace=self.trace, clock=self.clock)
        self.device = Device(self.transport, simulated=True, clock=self.clock)
        self.device.initialize()

    def trace(self, direction, data):
        if direction == "TX":
            self.tx.append(bytes(data))

    def writes(self, opcode):
        return [raw for raw in self.tx if raw[5] == opcode]

    def arm(self, service=False):
        self.device.action("enable_control", True)
        self.device.action("enable_service", True)
        self.device.action("service_set", {"key": "soft_start_enabled", "value": True})
        self.device.action("enable_service", service)

    def test_initialize_does_not_start_or_arm_laser(self):
        self.assertFalse(self.device.enabled)
        self.assertEqual(self.device.snapshot()["state"], "STOP")
        self.assertFalse(self.writes(0x08))
        self.assertFalse(self.writes(0x01))
        self.assertTrue(all(raw[7:9] == b"\x00\x00" for raw in self.writes(0x50)))
        self.assertTrue(set(raw[5] for raw in self.tx) <= {0x42, 0x02, 0x55, 0x50, 0x52, 0x0B})
        self.assertIsNone(self.device.snapshot()["service"]["soft_start_enabled"])
        self.assertFalse(self.writes(0x09))
        self.assertFalse(self.writes(0x49))
        self.assertFalse(self.writes(0x53))

    def test_unknown_state_is_not_stop_confirmation(self):
        transport = UnknownStateTransport(clock=self.clock)
        device = Device(transport, simulated=True, clock=self.clock)
        device.initialize()
        self.assertIsNone(device.snapshot()["emission"])
        with self.assertRaises(ProtocolError):
            device.action("stop")

    def test_pending_stop_cancels_not_yet_transmitted_run_and_settings(self):
        self.arm()
        self.device.interrupt_poll = lambda: True
        with self.assertRaises(ValueError):
            self.device.action("run")
        with self.assertRaises(ValueError):
            self.device.action("set_current", 10)
        self.assertFalse(self.writes(0x08))
        self.assertFalse(self.writes(0x01))
        self.device.action("stop")
        self.assertEqual(self.writes(0x08)[-1][7], 1)

    def test_run_requires_control_and_explicit_command(self):
        with self.assertRaises(ValueError):
            self.device.action("run")
        self.assertFalse(self.writes(0x08))
        self.arm()
        self.device.action("run")
        self.assertEqual(self.device.snapshot()["state"], "COUNTDOWN")
        self.assertEqual(len([raw for raw in self.writes(0x08) if raw[7] == 0]), 1)
        self.clock.advance(3)
        self.device.poll()
        self.assertEqual(self.device.snapshot()["state"], "RUN")

    def test_current_rejects_bad_values_and_device_limit(self):
        self.arm()
        for value in (-0.1, 25.1, float("nan"), float("inf"), True, 1.05):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.device.action("set_current", value)
        self.assertFalse(self.writes(0x01))
        self.device.action("set_current", 25.0)
        self.assertEqual(self.device.data["current_set_a"], 25)

    def test_current_write_preserves_fresh_frequency_and_width_words(self):
        self.arm()
        self.transport.frequency_word = 137
        self.transport.pulse_word = 19
        self.device.action("set_current", 12.3)
        raw = self.writes(0x01)[-1]
        self.assertEqual(raw[8:12], b"\x00\x89\x00\x13")
        self.assertEqual(raw[14:16], b"\x00\x7b")
        self.assertEqual(self.device.data["_raw_status_fields"],
                         {"current_word": 123, "frequency_word": 137, "width_word": 19})

    def test_operating_current_mismatch_warns_without_retry(self):
        transport = RefusingOperatingTransport(trace=self.trace, clock=self.clock)
        device = Device(transport, simulated=True, clock=self.clock)
        device.initialize()
        device.action("enable_control", True)
        transport.refuse_operating = True
        with self.assertRaises(CurrentReadbackWarning):
            device.action("set_current", 10)
        self.assertEqual(len(self.writes(0x01)), 1)
        self.assertEqual(device.snapshot()["current_request_a"], 10)
        self.assertEqual(device.snapshot()["current_set_a"], 0.1)
        self.assertIn("requested 10.0 A", device.snapshot()["setting_warning"])
        self.assertTrue(device.snapshot()["comm_ok"])
        transport.refuse_operating = False
        device.action("set_current", 8)
        self.assertEqual(device.snapshot()["setting_warning"], "")

    def test_new_hardware_fault_prevents_run(self):
        self.arm()
        self.transport.inject_fault("water flow")
        with self.assertRaises(ValueError):
            self.device.action("run")
        self.assertIn("Water flow", self.device.snapshot()["faults"])
        self.assertFalse([raw for raw in self.writes(0x08) if raw[7] == 0])

    def test_stop_available_unarmed_and_with_stale_status(self):
        self.transport.state = 0
        self.clock.advance(20)
        self.device.action("stop")
        self.assertEqual(self.writes(0x08)[-1][7], 1)
        self.assertEqual(self.device.data["state"], "STOP")
        self.transport.inject_fault("cover")
        self.device.action("stop")
        self.assertEqual(self.device.data["state"], "FAULT")

    def test_stop_invalidates_power_without_waiting_for_optional_power_read(self):
        self.device.data["power_w"] = 4.4
        self.tx.clear()
        self.device.action("stop")
        self.assertIsNone(self.device.snapshot()["power_w"])
        self.assertEqual([raw[5] for raw in self.tx], [8, 2])
        self.device.poll()
        self.assertEqual(self.device.snapshot()["power_w"], 0)

    def test_status_state_change_invalidates_prior_power_sample(self):
        self.device.data["power_w"] = 4.4
        self.transport.state = 0
        from empower import commands
        self.device._query(commands.query_status(), (0x11, 0x12))
        self.assertIsNone(self.device.snapshot()["power_w"])

    def test_reconnect_reads_running_device_without_auto_run_or_arm(self):
        self.arm()
        self.device.action("run")
        self.clock.advance(3)
        run_commands = len(self.writes(0x08))
        replacement = Device(self.transport, simulated=True, clock=self.clock)
        replacement.initialize()
        self.assertFalse(replacement.enabled)
        self.assertFalse(replacement.service_enabled)
        self.assertEqual(replacement.data["state"], "RUN")
        self.assertEqual(len(self.writes(0x08)), run_commands)

    def test_service_validates_numeric_field_and_preserves_untouched_words(self):
        self.arm(service=True)
        self.transport.service_words = [257, 123, 45, 6789, 1601, 1399]
        for code in ("-1", "abc", "65536", True, None):
            with self.subTest(code=code), self.assertRaises(ValueError):
                self.device.action("service_set", {"key": "max_current_a", "value": 28, "access_code": code})
        self.assertFalse([raw for raw in self.writes(0x50) if raw[7:9] != b"\x00\x00"])
        # Fictional nonzero code for the simulator; not an Empower service code.
        self.device.action("service_set", {"key": "max_current_a", "value": 28, "access_code": "1234"})
        self.assertEqual(self.transport.service_words, [280, 123, 45, 6789, 1601, 1399])
        self.assertEqual(self.device.data["max_current_a"], 28)
        self.assertEqual(len([raw for raw in self.writes(0x50) if raw[7:9] != b"\x00\x00"]), 1)
        with self.assertRaises(ValueError):
            self.device.action("service_set", {"key": "max_current_a", "value": 28.5, "access_code": "1234"})

    def test_new_run_state_blocks_service_frequency_write(self):
        self.arm(service=True)
        self.transport.state = 0  # Another controller changed it after our last poll.
        with self.assertRaises(ValueError):
            self.device.action("service_set", {"key": "qswitch_frequency_khz", "value": 1.1,
                                                "nominal_frequency_khz": 1.0})
        self.assertFalse(self.writes(0x01))

    def test_disabled_underfrequency_protection_prevents_normal_run(self):
        self.arm()
        self.transport.underfrequency = False
        with self.assertRaises(ValueError):
            self.device.action("run")
        self.assertFalse([raw for raw in self.writes(0x08) if raw[7] == 0])

    def test_lbo_monitor_collects_baseline_then_stops_on_drift(self):
        self.arm()
        self.assertEqual(len(self.device.lbo_samples), 1)
        for _ in range(178):
            self.clock.advance()
            self.device.poll()
        self.assertFalse(self.device.lbo_fault)
        self.assertIn("Warming up 179/180", self.device.snapshot()["service"]["lbo_monitor"])
        self.clock.advance()
        self.device.poll()
        self.assertIn("Monitoring", self.device.snapshot()["service"]["lbo_monitor"])
        self.device.action("run")
        self.transport.lbo_c = 152.0
        for _ in range(6):
            self.clock.advance()
            self.device.poll()
        self.assertTrue(self.device.lbo_fault)
        self.assertFalse(self.device.enabled)
        self.assertEqual(self.transport.state, 1)
        self.assertEqual(self.device.snapshot()["state"], "FAULT")
        self.assertIn("LBO stability (host monitor)", self.device.snapshot()["faults"])
        self.assertEqual(self.writes(0x08)[-1][7], 1)

    def test_timeout_latches_unavailable_and_stop_is_still_sent(self):
        self.arm()
        self.transport.drop_responses = True
        with self.assertRaises(TimeoutError):
            self.device.poll()
        # Session error handler is responsible for this explicit transition.
        self.device.connection_failed()
        self.assertFalse(self.device.enabled)
        self.assertFalse(self.device.data["comm_ok"])
        self.assertIsNone(self.device.data["emission"])
        with self.assertRaises(ValueError):
            self.device.action("run")
        with self.assertRaises(TimeoutError):
            self.device.action("stop")
        self.assertEqual(self.writes(0x08)[-1][7], 1)

    def test_truncated_status_never_confirms_settings(self):
        transport = TruncatedStatusTransport(trace=self.trace, clock=self.clock)
        device = Device(transport, simulated=True, clock=self.clock)
        device.initialize()
        device.action("enable_control", True)
        transport.truncate_status = True
        with self.assertRaises(ProtocolError):
            device.action("set_current", 10)
        self.assertFalse(self.writes(0x01))
        device.connection_failed()
        self.assertFalse(device.data["comm_ok"])
        self.assertEqual(device.data["state"], "UNKNOWN")

    def test_unsupported_initial_firmware_layout_cannot_bypass_checksum_validation(self):
        device = Device(self.transport)
        raw = bytearray.fromhex("10 02 00 00 0D 62 00 48 43 01 02 00 00")
        raw[-1] = sum(raw[:-1]) & 255
        with self.assertRaisesRegex(ProtocolError, "Unsupported firmware response layout"):
            device._merge(Frame(bytes(raw)))
        self.assertIsNone(device._rx_checksum_mode)
        self.assertNotIn("firmware_tuple", device.data)
        self.assertEqual(device.snapshot()["rx_checksum"], "Response layout unconfirmed")

    def test_run_requires_explicit_softstart_confirmation_and_refresh_is_read_only_for09(self):
        self.device.action("enable_control", True)
        self.device.action("refresh")
        with self.assertRaisesRegex(ValueError, "Softstart is unconfirmed"):
            self.device.action("run")
        self.assertFalse(self.writes(9))
        self.assertFalse(self.writes(0x49))
        self.assertFalse(self.writes(8))
        self.arm()
        self.device.action("run")
        self.assertEqual(len(self.writes(0x49)), 1)
        self.assertEqual(self.writes(8)[-1][7], 0)

    def test_reset_uses09_preserves_protection_and_verifies_stopped_state(self):
        self.device.action("enable_control", True)
        self.transport.underfrequency = False
        self.device.action("reset")
        self.assertEqual(self.writes(9)[-1].hex(), "1002000008090225")
        self.assertFalse(self.writes(0x53))
        self.assertFalse(self.device.data["service"]["underfrequency_enabled"])
        self.assertIsNone(self.device.data["service"]["soft_start_enabled"])

    def test_reset_rejects_unknown_state_before_any_mutation(self):
        self.device.action("enable_control", True)
        self.transport.state = 255
        with self.assertRaisesRegex(ValueError, "Confirmed STOP or FAULT"):
            self.device.action("reset")
        self.assertFalse(self.writes(9))

    def test_underfrequency_action_is_separate_from_reset(self):
        self.arm(service=True)
        self.device.action("service_set", {"key": "underfrequency_enabled", "value": False})
        self.assertEqual(self.writes(0x53)[-1][7], 0)
        self.assertFalse(self.writes(9))

    def test_source_zero_after_external_remains_raw_and_blocks_run(self):
        self.arm()
        self.transport.qswitch = 3
        self.device.poll()
        self.transport.qswitch = 0
        self.device.poll()
        self.assertEqual(self.device.snapshot()["qswitch"], 0)
        with self.assertRaisesRegex(ValueError, "Q-switch"):
            self.device.action("run")
        self.assertFalse(self.writes(8))

    def test_manual_frequency_limits_cover_all_factory_nominal_values(self):
        self.arm(service=True)
        for nominal, limits in ((0.5, (0.5, 0.6)), (5, (4, 6)), (8, (6.4, 9.6)), (10, (8, 10))):
            for value in limits:
                with self.subTest(nominal=nominal, value=value):
                    self.device.action("service_set", {"key": "qswitch_frequency_khz", "value": value,
                                                        "nominal_frequency_khz": nominal})
                    self.assertEqual(self.writes(1)[-1][8:10], round(value * 100).to_bytes(2, "big"))
        for value in (7.99, 10.01):
            with self.assertRaises(ValueError):
                self.device.action("service_set", {"key": "qswitch_frequency_khz", "value": value,
                                                    "nominal_frequency_khz": 10})

    def test_authorization_withdrawal_at_last_write_boundary_blocks_mutations(self):
        self.arm(service=True)
        self.device.interrupt_write = lambda service=False: True
        before = len(self.tx)
        for name, value in (("run", None), ("set_current", 8), ("reset", None),
                            ("service_set", {"key": "soft_start_enabled", "value": True})):
            with self.subTest(name=name), self.assertRaises(ActionCancelled):
                self.device.action(name, value)
        self.assertFalse([raw for raw in self.tx[before:] if raw[5] in (1, 8, 9, 0x49, 0x53)])
        self.device.action("stop")
        self.assertEqual(self.writes(8)[-1][7], 1)

    def test_service_only_revocation_does_not_cancel_normal_current(self):
        self.arm(service=True)
        self.device.interrupt_write = lambda service=False: service
        with self.assertRaises(ActionCancelled):
            self.device.action("service_set", {"key": "qswitch_pulse_width_ns", "value": 5000})
        self.device.action("set_current", 8)
        self.assertEqual(self.writes(1)[-1][14:16], b"\x00\x50")

    def test_lbo_stop_refusal_is_reported_not_hidden_by_fault_overlay(self):
        self.arm()
        self.transport.state = 0
        self.device.lbo_samples.extend([100.0] * 179)
        self.device.last_lbo_sample = -float("inf")
        self.transport.lbo_c = 200
        original_send = self.transport.send
        self.transport.send = lambda raw: None if raw[5] == 8 else original_send(raw)
        with self.assertRaisesRegex(ProtocolError, "STOP sent but stopped state is unconfirmed"):
            self.device.poll()
        self.assertFalse(self.device.enabled)
        self.assertFalse(self.device.service_enabled)
        self.assertEqual(self.device.data["state"], "RUN")

    def test_initialization_can_be_cancelled_between_required_reads(self):
        device = Device(self.transport, clock=self.clock)
        self.tx.clear()
        device.interrupt_poll = lambda: bool(self.tx)
        with self.assertRaises(ActionCancelled):
            device.initialize()
        self.assertEqual([raw[5] for raw in self.tx], [0x42])

    def test_snapshot_exposes_permissions_and_status_age(self):
        self.arm(service=True)
        snapshot = self.device.snapshot()
        self.assertTrue(snapshot["control_enabled"])
        self.assertTrue(snapshot["service_enabled"])
        self.assertTrue(snapshot["status_fresh"])
        self.clock.advance(3.1)
        self.assertAlmostEqual(self.device.snapshot()["status_age_s"], 3.1)
        self.assertFalse(self.device.snapshot()["status_fresh"])


if __name__ == "__main__":
    unittest.main()
