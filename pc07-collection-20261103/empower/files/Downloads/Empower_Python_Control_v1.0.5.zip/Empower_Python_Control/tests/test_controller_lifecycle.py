"""Worker/device boundary regressions using only a synthetic serial peer."""
import tempfile
import threading
import unittest
from unittest.mock import patch

from empower.controller import SessionController
from empower.simulator import SimulatedTransport


class BlockingPeer(SimulatedTransport):
    def __init__(self, trace, block_opcode=None):
        super().__init__(trace)
        self.block_opcode = block_opcode
        self.entered, self.release = threading.Event(), threading.Event()
        self.writes = []

    def send(self, raw):
        self.writes.append(bytes(raw))
        super().send(raw)

    def exchange(self, raw, expected):
        if raw[5] == self.block_opcode:
            self.block_opcode = None
            self.entered.set()
            if not self.release.wait(2):
                raise AssertionError("Synthetic read was not released")
        return super().exchange(raw, expected)


class ControllerDeviceLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.events = []
        self.changed = threading.Condition()
        self.controller = self.peer = None
        self.peer_created = threading.Event()
        self.addCleanup(self.cleanup_worker)

    def cleanup_worker(self):
        if self.peer:
            self.peer.release.set()
        if self.controller:
            self.controller.submit("shutdown")
            self.controller.thread.join(2)
            self.assertFalse(self.controller.thread.is_alive(), "Serial worker leaked")

    def notify(self, kind, value):
        with self.changed:
            self.events.append((kind, value))
            self.changed.notify_all()

    def start(self, block_opcode=None):
        def create(port, trace):
            self.peer = BlockingPeer(trace, block_opcode)
            self.peer_created.set()
            return self.peer
        serial = patch("empower.controller.SerialTransport", side_effect=create)
        serial.start()
        self.addCleanup(serial.stop)
        self.controller = SessionController(self.notify, self.temp.name)
        self.controller.submit("connect", "SYNTHETIC-PEER")
        if block_opcode is None:
            self.assertTrue(self.result("connect")["ok"])
        else:
            self.assertTrue(self.peer_created.wait(1))
            self.assertTrue(self.peer.entered.wait(1))

    def result(self, name, value=None):
        def found():
            return next((result for kind, result in reversed(self.events)
                         if kind == "action_result" and result["name"] == name
                         and (value is None or result.get("value") == value)), None)
        with self.changed:
            self.assertTrue(self.changed.wait_for(found, 1), name)
            return found()

    def arm(self, service=False):
        self.controller.submit("enable_control", True)
        self.assertTrue(self.result("enable_control", True)["ok"])
        if service:
            self.controller.submit("enable_service", True)
            self.assertTrue(self.result("enable_service", True)["ok"])

    def test_disarm_during_prewrite_status_cancels_current_before_wire_mutation(self):
        self.start()
        self.arm()
        self.peer.block_opcode = 2
        self.controller.submit("set_current", 8)
        self.assertTrue(self.peer.entered.wait(1))
        self.controller.submit("enable_control", False)
        self.peer.release.set()
        self.assertFalse(self.result("set_current")["ok"])
        self.assertTrue(self.result("enable_control", False)["ok"])
        self.assertFalse(any(raw[5] == 1 for raw in self.peer.writes))
        self.assertFalse(self.controller.device.enabled)
        self.assertFalse(self.controller.device.service_enabled)
        self.assertFalse(self.peer.closed)
        self.controller.submit("stop")
        self.assertTrue(self.result("stop")["ok"])
        self.assertEqual([raw[7] for raw in self.peer.writes if raw[5] == 8], [1])

    def test_service_revocation_during_read_cancels_softstart_but_preserves_control(self):
        self.start()
        self.arm(service=True)
        self.peer.block_opcode = 2
        self.controller.submit("service_set", {"key": "soft_start_enabled", "value": True})
        self.assertTrue(self.peer.entered.wait(1))
        self.controller.submit("enable_service", False)
        self.peer.release.set()
        self.assertFalse(self.result("service_set")["ok"])
        self.assertTrue(self.result("enable_service", False)["ok"])
        self.assertFalse(any(raw[5] == 0x49 for raw in self.peer.writes))
        self.assertTrue(self.controller.device.enabled)
        self.assertFalse(self.controller.device.service_enabled)
        self.controller.submit("set_current", 8)
        self.assertTrue(self.result("set_current")["ok"])
        self.assertTrue(any(raw[5] == 1 for raw in self.peer.writes))

    def test_shutdown_interrupts_initialization_between_reads_then_confirms_stop(self):
        self.start(block_opcode=0x42)
        self.controller.submit("shutdown")
        self.controller.submit("stop")
        self.peer.release.set()
        self.controller.thread.join(1)
        self.assertFalse(self.controller.thread.is_alive())
        self.assertTrue(self.peer.closed)
        self.assertEqual([raw[5] for raw in self.peer.writes], [0x42, 8, 2])
        self.assertFalse(self.result("connect")["ok"])
        self.assertIn(("ended", True), self.events)
        self.assertFalse(any(kind == "connection" and value[0] for kind, value in self.events))

    def test_log_creation_failure_keeps_device_control_and_confirmed_cleanup(self):
        with patch("empower.controller.SessionLog", side_effect=PermissionError("read-only log folder")):
            self.start()
        self.assertIsNone(self.controller.log)
        self.arm()
        self.controller.submit("shutdown")
        self.controller.thread.join(1)
        self.assertTrue(self.peer.closed)
        self.assertIn(("ended", True), self.events)
        self.assertTrue(any(kind == "warning" and "log unavailable" in value
                            for kind, value in self.events))


if __name__ == "__main__":
    unittest.main()
