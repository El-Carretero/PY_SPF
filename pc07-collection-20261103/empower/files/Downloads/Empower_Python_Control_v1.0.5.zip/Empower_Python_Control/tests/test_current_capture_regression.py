"""Current-setting regression from the user's 2026-09-23 status history.

CAPTURED_SERVICE, CAPTURED_PRE_STATUS, and CAPTURED_CURRENT_ACK are literal
reassembled RX frames surrounding the final Action set_current:14.5. They show
25A limit, pre-action8.0A setting/6.7A sensing, and ACK12.5A setting/7.1A sensing.
The firmware, Q-switch and opaque opcode09-reset reply fixtures reproduce existing capture
regression vectors. Subsequent poll/STOP and failure variations are explicitly
SYNTHETIC; the history ends at the ACK and supplies no later device behavior.

The threaded tests retain the real Device, protocol builders, response parser,
and SessionController. Only the serial peer is replaced. No port is opened.

CAPTURED_FAULT_* additionally preserve the fourth uploaded JSONL session's
12.5A command and10.5A ACK. Its preceding status already contains the
Communication fault and FAULT state. The fixed application must reject the
write before transmitting opcode0x01 when that fresh fault is discovered.
"""
from contextlib import contextmanager
import tempfile
import threading
import unittest
from unittest.mock import patch

from empower.controller import SessionController
from empower.device import CurrentReadbackWarning, Device
from empower.framing import Frame, ProtocolError, decode
from empower.responses import parse_response


CAPTURED_FIRMWARE = bytes.fromhex("10 02 00 00 0C 62 00 48 43 01 02 0E")
CAPTURED_QSWITCH = bytes.fromhex("10 02 00 00 09 75 00 02 92")
CAPTURED_OPAQUE_RESET = bytes.fromhex("10 02 00 00 0C 18 00 00 20 00 02 58")
CAPTURED_SERVICE = bytes.fromhex(
    "10 02 00 00 15 70 00 00 FA 00 02 58 00 00 30 D4 05 46 04 9C DA"
)
CAPTURED_PRE_STATUS = bytes.fromhex(
    "10 02 00 00 1E 12 00 00 00 80 00 64 00 28 00 00 "
    "89 34 00 7A 00 50 00 43 01 47 C9 65 00 8E"
)
CAPTURED_CURRENT_ACK = bytes.fromhex(
    "10 02 00 00 1E 11 00 00 00 80 00 64 00 28 00 00 "
    "89 34 00 7A 00 7D 00 47 01 47 C9 65 00 BE"
)
# Independent literal expectation from the documented byte offsets, not an
# encode() or set_operating_words() call using the implementation under test.
EXPECTED_TX_14_5 = bytes.fromhex(
    "10 02 00 00 11 01 02 00 00 64 00 28 00 00 00 91 43"
)
EXPECTED_STOP_TX = bytes.fromhex("10 02 00 00 09 08 02 01 26")

# Literal frames from04-20260923_215228_765727_session.jsonl, last action.
CAPTURED_FAULT_PRE_STATUS = bytes.fromhex(
    "10 02 00 00 1E 12 00 00 00 90 00 64 00 28 00 00 "
    "89 34 00 67 00 7D 00 03 01 47 C9 65 02 7A"
)
CAPTURED_FAULT_TX_12_5 = bytes.fromhex(
    "10 02 00 00 11 01 02 00 00 64 00 28 00 00 00 7D 2F"
)
CAPTURED_FAULT_CURRENT_ACK = bytes.fromhex(
    "10 02 00 00 1E 11 00 00 00 90 00 64 00 28 00 00 "
    "89 34 00 67 00 69 00 02 01 47 C9 65 02 64"
)


def synthetic_checksum(body):
    return bytes(body) + bytes((sum(body) & 255,))


def synthetic_post_ack_status(stopped=False):
    """Hypothetical poll/STOP response; no post-ACK RX exists in this history."""
    body = bytearray(CAPTURED_CURRENT_ACK[:-1])
    body[5] = 0x12
    if stopped:
        body[22:24] = b"\x00\x00"
        body[28] = 1
    return synthetic_checksum(body)


SYNTHETIC_LBO = synthetic_checksum(bytes.fromhex("10 02 00 00 0E 1A 00 00 00 00 00 05 05"))
SYNTHETIC_POWER = synthetic_checksum(bytes.fromhex("10 02 00 00 0A 72 00 00 00"))


class CurrentCapturePeer:
    """Deterministic fake serial peer with captured ACK and synthetic future."""
    def __init__(self, variation="captured"):
        self.variation = variation
        self.trace = lambda direction, data: None
        self.tx = []
        self.status = CAPTURED_PRE_STATUS
        self.write_ack_returned = False
        self.post_ack_polls = 0
        self.service_reads = 0
        self.fault_introduced = False
        self.fault_status_reads = 0
        self.stop_sent = False
        self.closed = threading.Event()

    def send(self, raw):
        if self.closed.is_set():
            raise OSError("Synthetic peer is closed")
        decode(raw, verify_checksum=True)
        self.tx.append(bytes(raw))
        self.trace("TX", raw)
        if raw[5] == 0x08:
            if raw != EXPECTED_STOP_TX:
                raise AssertionError("No test requests RUN")
            self.stop_sent = True
            if self.variation == "fresh_fault":
                # SYNTHETIC continuation: STOP does not clear an ongoing fault.
                self.status = CAPTURED_FAULT_PRE_STATUS
            else:
                self.status = synthetic_post_ack_status(stopped=True)

    def exchange(self, raw, expected):
        self.send(raw)
        opcode = raw[5]
        if opcode == 0x50:
            self.service_reads += 1
            if self.variation == "fresh_fault" and self.service_reads == 2:
                # Initialization looked healthy. Reveal the captured fault on
                # the action's next, freshly requested status frame.
                self.status = CAPTURED_FAULT_PRE_STATUS
                self.fault_introduced = True
        if opcode == 0x02 and self.fault_introduced:
            self.fault_status_reads += 1
        if opcode == 0x01:
            reply = CAPTURED_CURRENT_ACK
            if self.variation == "bad_checksum":
                reply = reply[:-1] + bytes((reply[-1] ^ 1,))
            elif self.variation == "changed_preserved_frequency":
                body = bytearray(reply[:-1])
                body[10:12] = b"\x00\x63"  # SYNTHETIC:99 rather than preserved100.
                reply = synthetic_checksum(body)
            self.write_ack_returned = True
            self.status = synthetic_post_ack_status()
        else:
            if opcode == 0x02 and self.write_ack_returned:
                self.post_ack_polls += 1
            replies = {
                0x42: CAPTURED_FIRMWARE,
                0x02: self.status,
                0x55: CAPTURED_QSWITCH,
                0x50: CAPTURED_SERVICE,
                0x09: CAPTURED_OPAQUE_RESET,
                0x0B: SYNTHETIC_LBO,
                0x52: SYNTHETIC_POWER,
            }
            if opcode not in replies:
                raise AssertionError(f"Unexpected fake-peer request0x{opcode:02X}")
            reply = replies[opcode]
        if reply[5] not in expected:
            raise TimeoutError(f"Fake peer returned0x{reply[5]:02X}, expected{expected}")
        self.trace("RX_BYTES", reply)
        # Real Device validates RX based on the learned firmware response mode.
        # A deliberately corrupt ACK must reach that real validation unchanged.
        return Frame(reply)

    def writes(self, opcode):
        return [raw for raw in self.tx if raw[5] == opcode]

    def close(self):
        self.closed.set()


class CurrentCaptureRegression(unittest.TestCase):
    def test_literal_last_action_frames_and_expected_tx_are_checksummed(self):
        for raw in (CAPTURED_FIRMWARE, CAPTURED_SERVICE, CAPTURED_PRE_STATUS,
                    CAPTURED_CURRENT_ACK, EXPECTED_TX_14_5, EXPECTED_STOP_TX,
                    CAPTURED_FAULT_PRE_STATUS, CAPTURED_FAULT_TX_12_5,
                    CAPTURED_FAULT_CURRENT_ACK):
            with self.subTest(opcode=raw[5], frame=raw.hex()):
                self.assertEqual(raw[4], len(raw))
                self.assertEqual(sum(raw[:-1]) & 255, raw[-1])

    def make_device(self, variation="captured"):
        peer = CurrentCapturePeer(variation)
        device = Device(peer, simulated=False)
        device.initialize()
        device.action("enable_control", True)
        return device, peer

    def test_real_device_warns_once_keeps_actual_readback_and_communication(self):
        device, peer = self.make_device()
        self.assertEqual(device.data["current_set_a"], 8.0)
        self.assertEqual(device.data["current_a"], 6.7)
        with self.assertRaisesRegex(CurrentReadbackWarning, r"14\.5 A.*12\.5 A"):
            device.action("set_current", 14.5)
        self.assertEqual(peer.writes(0x01), [EXPECTED_TX_14_5])
        self.assertEqual(peer.tx[-3][5], 0x50)
        self.assertEqual(peer.tx[-2][5], 0x02)
        snapshot = device.snapshot()
        self.assertTrue(snapshot["connected"])
        self.assertTrue(snapshot["comm_ok"])
        self.assertTrue(snapshot["control_enabled"])
        self.assertEqual(snapshot["state"], "RUN")
        self.assertEqual(snapshot["faults"], [])
        self.assertEqual(snapshot["current_request_a"], 14.5)
        self.assertEqual(snapshot["current_set_a"], 12.5)
        self.assertEqual(snapshot["current_a"], 7.1)
        self.assertEqual(snapshot["_raw_status_fields"],
                         {"current_word": 125, "frequency_word": 100, "width_word": 40})
        self.assertIn("no automatic retry", snapshot["setting_warning"].lower())
        device.poll()  # SYNTHETIC continuation, not further captured evidence.
        self.assertTrue(device.data["comm_ok"])
        self.assertEqual(device.data["setting_warning"], snapshot["setting_warning"])
        self.assertEqual(peer.writes(0x01), [EXPECTED_TX_14_5])
        self.assertEqual(peer.writes(0x08), [])
        self.assertFalse(peer.closed.is_set())

    def test_bad_checksum_or_changed_preserved_field_is_not_a_current_warning(self):
        for variation in ("bad_checksum", "changed_preserved_frequency"):
            with self.subTest(variation=variation):
                device, peer = self.make_device(variation)
                with self.assertRaises(ProtocolError):
                    device.action("set_current", 14.5)
                self.assertFalse(device.data.get("setting_warning"))
                self.assertEqual(peer.writes(0x01), [EXPECTED_TX_14_5])

    def test_fourth_session_documents12_5_request10_5_ack_and_preexisting_fault(self):
        request = decode(CAPTURED_FAULT_TX_12_5, verify_checksum=True)
        before = parse_response(decode(CAPTURED_FAULT_PRE_STATUS), (1, 2))
        ack = parse_response(decode(CAPTURED_FAULT_CURRENT_ACK), (1, 2))
        self.assertEqual(int.from_bytes(request.raw[14:16], "big") / 10, 12.5)
        self.assertEqual(before["current_set_a"], 12.5)
        self.assertEqual(before["current_a"], 0.3)
        self.assertEqual(ack["current_set_a"], 10.5)
        self.assertEqual(ack["current_a"], 0.2)
        for result in (before, ack):
            self.assertEqual(result["state"], "FAULT")
            self.assertEqual(result["faults"], ["Communication"])
            self.assertEqual(result["unknown_status_bits"], {})
            self.assertEqual(result["_raw_status_fields"]["frequency_word"], 100)
            self.assertEqual(result["_raw_status_fields"]["width_word"], 40)

    def test_fresh_fault_blocks_current_before_write_without_disconnect_or_stop(self):
        device, peer = self.make_device("fresh_fault")
        self.assertEqual(device.data["state"], "RUN")
        self.assertEqual(device.data["faults"], [])
        with self.assertRaisesRegex(ValueError, r"Current change blocked"):
            device.action("set_current", 12.5)
        self.assertEqual(peer.fault_status_reads, 1)
        self.assertEqual(peer.writes(0x01), [])
        self.assertEqual(peer.writes(0x08), [])
        self.assertFalse(peer.closed.is_set())
        snapshot = device.snapshot()
        self.assertEqual(snapshot["state"], "FAULT")
        self.assertEqual(snapshot["faults"], ["Communication"])
        self.assertTrue(snapshot["connected"])
        self.assertTrue(snapshot["comm_ok"])
        self.assertNotIn("current_request_a", snapshot, "No write request was transmitted")
        device.poll()  # Synthetic continued polling repeats the captured fault.
        self.assertGreater(peer.fault_status_reads, 1)
        self.assertTrue(device.data["comm_ok"])
        self.assertEqual(peer.writes(0x01), [])

    @contextmanager
    def worker_session(self, variation="captured"):
        peer = CurrentCapturePeer(variation)
        events = {name: threading.Event() for name in
                  ("connected", "armed", "warning", "error", "polled", "stopped", "ended",
                   "fresh_fault", "fault_polled", "fault_stopped")}
        notifications = []

        def notify(kind, value):
            notifications.append((kind, value))
            if kind == "connection" and value[0]:
                events["connected"].set()
            elif kind in ("warning", "error", "ended"):
                events[kind].set()
            elif kind == "snapshot":
                if value.get("control_enabled"):
                    events["armed"].set()
                if peer.post_ack_polls and value.get("setting_warning"):
                    events["polled"].set()
                if peer.write_ack_returned and value.get("state") == "STOP":
                    events["stopped"].set()
                if peer.fault_introduced and value.get("state") == "FAULT":
                    events["fresh_fault"].set()
                    if peer.fault_status_reads >= 2:
                        events["fault_polled"].set()
                    if peer.stop_sent:
                        events["fault_stopped"].set()

        def make_transport(port, trace):
            self.assertEqual(port, "CAPTURE-PEER")
            peer.trace = trace
            return peer

        with tempfile.TemporaryDirectory() as directory, patch(
                "empower.controller.SerialTransport", side_effect=make_transport):
            controller = SessionController(notify, directory)
            try:
                controller.submit("connect", "CAPTURE-PEER")
                self.assertTrue(events["connected"].wait(2), "Real Device initialization did not finish")
                self.assertIsInstance(controller.device, Device)
                controller.submit("enable_control", True)
                self.assertTrue(events["armed"].wait(2), "Session did not enable control")
                yield controller, peer, events, notifications
            finally:
                if controller.thread.is_alive():
                    controller.submit("shutdown")
                    self.assertTrue(events["ended"].wait(2), "Session did not shut down")
                    controller.thread.join(2)
                self.assertFalse(controller.thread.is_alive(), "Worker thread leaked")

    def test_worker_warning_keeps_polling_and_explicit_stop_without_retry_or_close(self):
        with self.worker_session() as (controller, peer, events, notifications):
            controller.submit("set_current", 14.5)
            self.assertTrue(events["warning"].wait(2), "Nonfatal current warning was not published")
            self.assertFalse(events["error"].is_set())
            self.assertFalse(controller.output_unknown)
            self.assertFalse(peer.closed.is_set())
            self.assertEqual(peer.writes(0x08), [], "Warning must not automatically STOP")
            self.assertEqual(peer.writes(0x01), [EXPECTED_TX_14_5])
            self.assertTrue(events["polled"].wait(2), "Worker did not continue its next scheduled poll")
            self.assertTrue(controller.device.snapshot()["comm_ok"])
            self.assertEqual(controller.device.snapshot()["current_request_a"], 14.5)
            self.assertEqual(controller.device.snapshot()["current_set_a"], 12.5)
            self.assertEqual(peer.writes(0x01), [EXPECTED_TX_14_5], "Polling must not retry the setting")
            self.assertEqual(peer.writes(0x08), [])
            self.assertFalse(peer.closed.is_set())
            controller.submit("stop")
            self.assertTrue(events["stopped"].wait(2), "Explicit STOP was not confirmed")
            self.assertEqual(peer.writes(0x08), [EXPECTED_STOP_TX])
            self.assertFalse(peer.closed.is_set())
            self.assertEqual(peer.writes(0x01), [EXPECTED_TX_14_5])
            self.assertTrue(any(kind == "warning" for kind, _ in notifications))

    def test_worker_publishes_fresh_fault_rejection_keeps_polling_and_stop_available(self):
        with self.worker_session("fresh_fault") as session:
            controller, peer, events, notifications = session
            controller.submit("set_current", 12.5)
            self.assertTrue(events["error"].wait(2), "Validation rejection was not reported")
            self.assertTrue(events["fresh_fault"].wait(2), "Fresh FAULT was not published")
            self.assertFalse(events["warning"].is_set())
            self.assertFalse(controller.output_unknown)
            self.assertIsInstance(controller.device, Device)
            self.assertFalse(peer.closed.is_set())
            self.assertEqual(peer.writes(0x01), [])
            self.assertEqual(peer.writes(0x08), [])
            snapshots = [value for kind, value in notifications if kind == "snapshot"]
            self.assertEqual(snapshots[-1]["state"], "FAULT")
            self.assertEqual(snapshots[-1]["faults"], ["Communication"])
            self.assertTrue(snapshots[-1]["comm_ok"])
            self.assertTrue(snapshots[-1]["connected"])
            self.assertTrue(events["fault_polled"].wait(2), "Scheduled polling did not continue")
            self.assertEqual(peer.writes(0x01), [])
            self.assertEqual(peer.writes(0x08), [])
            controller.submit("stop")
            self.assertTrue(events["fault_stopped"].wait(2), "Explicit STOP unavailable in FAULT")
            self.assertEqual(peer.writes(0x08), [EXPECTED_STOP_TX])
            self.assertFalse(peer.closed.is_set())
            self.assertTrue(controller.device.snapshot()["comm_ok"])
            self.assertEqual(controller.device.snapshot()["state"], "FAULT")

    def test_worker_keeps_strict_failure_path_for_corrupt_or_preserved_field_mismatch(self):
        for variation in ("bad_checksum", "changed_preserved_frequency"):
            with self.subTest(variation=variation), self.worker_session(variation) as session:
                controller, peer, events, notifications = session
                controller.submit("set_current", 14.5)
                self.assertTrue(events["error"].wait(2), "Protocol error did not reach failure handler")
                self.assertTrue(peer.closed.wait(2), "Protocol failure did not close the peer")
                self.assertFalse(events["warning"].is_set())
                self.assertTrue(controller.output_unknown)
                self.assertIsNone(controller.device)
                self.assertEqual(peer.writes(0x01), [EXPECTED_TX_14_5])
                self.assertEqual(peer.writes(0x08), [EXPECTED_STOP_TX])
                snapshots = [value for kind, value in notifications if kind == "snapshot"]
                self.assertFalse(snapshots[-1]["connected"])
                self.assertFalse(snapshots[-1]["comm_ok"])
                self.assertIsNone(snapshots[-1]["emission"])


if __name__ == "__main__":
    unittest.main()
