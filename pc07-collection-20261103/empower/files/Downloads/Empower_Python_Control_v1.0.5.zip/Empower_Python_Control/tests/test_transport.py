"""Exercise pyserial against an OS pseudo-terminal; no physical laser."""
import importlib.util
import os
import select
import threading
import unittest
from empower import commands
from empower.transport import SerialTransport


def status_response(state=1):
    raw = bytearray(b"\x10\x02\x00\x00\x1d\x12\x02" + b"\x00" * 22)
    raw[28] = state  # Last byte is state, not an additive checksum.
    return bytes(raw)


@unittest.skipUnless(os.name == "posix" and importlib.util.find_spec("serial"),
                     "Requires POSIX PTYs and pyserial")
class PosixSerialTransportTests(unittest.TestCase):
    def setUp(self):
        self.master, slave = os.openpty()
        self.trace = []
        self.first_fragment_seen = threading.Event()
        def trace(direction, raw):
            self.trace.append((direction, raw))
            if direction == "RX_BYTES":
                self.first_fragment_seen.set()
        self.transport = SerialTransport(os.ttyname(slave), trace, timeout=0.5)
        os.close(slave)
        self.addCleanup(os.close, self.master)
        self.addCleanup(self.transport.close)
        self.peer_errors = []

    def peer(self, responder):
        def run():
            try:
                ready, _, _ = select.select([self.master], [], [], 1.0)
                if not ready:
                    raise AssertionError("Host did not send its query")
                request = bytearray()
                while len(request) < 8:
                    request.extend(os.read(self.master, 64))
                self.assertEqual(bytes(request), commands.query_status())
                responder()
            except BaseException as error:
                self.peer_errors.append(error)
        worker = threading.Thread(target=run, daemon=True)
        worker.start()
        return worker

    def finish_peer(self, worker):
        worker.join(1.0)
        self.assertFalse(worker.is_alive(), "Fake serial peer did not finish")
        if self.peer_errors:
            raise self.peer_errors[0]

    def test_fragmented_real_serial_response_has_no_rx_checksum(self):
        raw = status_response(1)
        self.assertNotEqual(sum(raw[:-1]) & 255, raw[-1])
        def respond():
            os.write(self.master, raw[:3])
            if not self.first_fragment_seen.wait(0.5):
                raise AssertionError("Reader never consumed header fragment")
            os.write(self.master, raw[3:])
        worker = self.peer(respond)
        frame = self.transport.exchange(commands.query_status(), (0x11, 0x12))
        self.finish_peer(worker)
        self.assertEqual(frame.raw, raw)
        self.assertGreaterEqual(sum(d == "RX_BYTES" for d, _ in self.trace), 2)

    def test_unsolicited_ack_is_not_accepted_as_status(self):
        ack = bytes.fromhex("10 02 00 00 08 18 02 00")
        raw = status_response(3)
        worker = self.peer(lambda: os.write(self.master, ack + raw))
        frame = self.transport.exchange(commands.query_status(), (0x11, 0x12))
        self.finish_peer(worker)
        self.assertEqual(frame.opcode, 0x12)
        self.assertEqual(frame.raw[28], 3)
        self.assertEqual(b"".join(data for d, data in self.trace if d == "RX_BYTES"), ack + raw)

    def test_timeout_discards_partial_frame_before_next_reply(self):
        old_reply, fresh_reply = status_response(0), status_response(1)
        os.write(self.master, old_reply[:10])
        with self.assertRaises(TimeoutError):
            self.transport.receive({0x12}, timeout=0.08)
        self.assertEqual(self.transport.decoder.buffer, bytearray())
        os.write(self.master, old_reply[10:] + fresh_reply)
        self.assertEqual(self.transport.receive({0x12}, timeout=0.5).raw, fresh_reply)


if __name__ == "__main__":
    unittest.main()
