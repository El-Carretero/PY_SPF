"""Independent, assembly-derived vectors; no simulator or generated fixtures.

The literals below are transcribed from EXE constructors/field accesses and
UIR enums. They deliberately exercise the asymmetric TX/RX envelope: status
RX index28 is state, not a TX-style checksum. See analysis reports in docs.
"""
import unittest
from unittest.mock import patch

from empower import commands as cmd
from empower.framing import Frame, FrameBuffer, ProtocolError, decode
from empower.responses import parse_response


# Source42AD4C/42BBA2: bytes7–9 flags;10–11 PRF;12–13 pulse ticks;
#20–21 current set;22–23 sensed;24–27 seconds;28 state.
# Unknown bytes14–19 contain a literal0x10 to catch unwanted wire escaping.
STATUS_RX = bytes.fromhex(
    "10 02 00 00 1D 12 02 43 A4 93 00 64 00 01 "
    "AA BB CC DD EE 10 00 FA 00 F5 00 01 5F 90 03"
)
SERVICE_RX = bytes.fromhex(
    "10 02 00 00 14 70 02 00 FA 00 13 88 00 64 02 58 07 D0 00 32"
)


class AssemblyTransmitVectors(unittest.TestCase):
    def test_queries_and_additive_checksum(self):
        # Constructor428805–428FD3; checksum428780.
        vectors = (
            (cmd.query_status, "10 02 00 00 08 02 02 1E"),
            (cmd.query_firmware, "10 02 00 00 08 42 02 5E"),
            (cmd.query_lbo, "10 02 00 00 08 0B 02 27"),
            (cmd.query_power, "10 02 00 00 08 52 02 6E"),
            (cmd.query_qswitch, "10 02 00 00 08 55 02 71"),
        )
        for builder, literal in vectors:
            with self.subTest(command=builder.__name__):
                self.assertEqual(builder(), bytes.fromhex(literal))

    def test_run_stop_polarity(self):
        # STOP callback42CA39 flag0; serializer429F8D f7=1-flag.
        self.assertEqual(cmd.set_run(False), bytes.fromhex("10 02 00 00 09 08 02 01 26"))
        self.assertEqual(cmd.set_run(True), bytes.fromhex("10 02 00 00 09 08 02 00 25"))

    def test_qswitch_uir_enumeration(self):
        # UIR1364C float labels: EXTERNAL3,INTERNAL2,HOLD OFF1.
        self.assertEqual(cmd.set_qswitch(3), bytes.fromhex("10 02 00 00 09 51 02 03 71"))
        self.assertEqual(cmd.set_qswitch(2), bytes.fromhex("10 02 00 00 09 51 02 02 70"))
        self.assertEqual(cmd.set_qswitch(1), bytes.fromhex("10 02 00 00 09 51 02 01 6F"))

    def test_combined_settings_preserve_field_positions(self):
        # 25A,1kHz,125ns, firmware1.1. Payload f7 and f12–13 reserved0.
        self.assertEqual(
            cmd.set_operating(25.0, 1.0, 125.0, (1, 1)),
            bytes.fromhex("10 02 00 00 11 01 02 00 00 64 00 01 00 00 00 FA 85"),
        )
        # Firmware0.1 special case frequency*10 instead of*100.
        self.assertEqual(
            cmd.set_operating(25.0, 1.0, 125.0, (0, 1)),
            bytes.fromhex("10 02 00 00 11 01 02 00 00 0A 00 01 00 00 00 FA 2B"),
        )

    def test_original_service_read_initial_values(self):
        # UIR defaults high9C,low5C; startup429235 clears the numeric field then
        # wrapper42C721->4281BA invokes common serializer4292E3.
        self.assertEqual(
            cmd.service_read(),
            bytes.fromhex("10 02 00 00 17 50 02 00 00 00 00 00 00 00 00 00 00 00 00 5A 00 32 07"),
        )

    def test_reset_and_underfrequency_are_distinct_commands(self):
        # Original RESET callback42E870->42C6C5 queues09. The checkbox
        # callback42EA1C->42C74F queues53 with its protection-setting byte.
        self.assertEqual(cmd.reset_faults(), bytes.fromhex("10 02 00 00 08 09 02 25"))
        self.assertEqual(cmd.set_underfrequency(True), bytes.fromhex("10 02 00 00 09 53 02 01 71"))
        self.assertEqual(cmd.set_underfrequency(False), bytes.fromhex("10 02 00 00 09 53 02 00 70"))

    def test_unsupported_queries_cannot_build_mutating_packets(self):
        with patch("empower.commands.encode") as encode_packet:
            for query in (cmd.query_softstart, cmd.query_underfrequency):
                with self.subTest(query=query.__name__):
                    with self.assertRaises(NotImplementedError):
                        query()
            encode_packet.assert_not_called()
        self.assertNotIn(0x09, cmd.READ_REQUESTS.values())
        self.assertNotIn(0x53, cmd.READ_REQUESTS.values())

    def test_original_softstart_initialization(self):
        self.assertEqual(
            cmd.configure_softstart(True, 1),
            bytes.fromhex("10 02 00 00 0B 49 02 01 00 01 6A"),
        )

    def test_transmit_checksum_corruption_rejected(self):
        with self.assertRaises(ProtocolError):
            decode(bytes.fromhex("10 02 00 00 09 08 02 01 25"))


class AssemblyReceiveVectors(unittest.TestCase):
    def test_status_rx_final_byte_is_state(self):
        updates = parse_response(Frame(STATUS_RX), (1, 1))
        self.assertEqual(updates["state"], "COUNTDOWN")
        self.assertTrue(updates["emission"])
        self.assertEqual(updates["current_set_a"], 25.0)
        self.assertEqual(updates["current_a"], 24.5)
        self.assertEqual(updates["hours"], 25.0)
        self.assertEqual(updates["service"]["qswitch_frequency_khz"], 1.0)
        self.assertEqual(updates["service"]["qswitch_pulse_width_ns"], 125)
        self.assertTrue(updates["service"]["underfrequency_enabled"])
        self.assertEqual(set(updates["faults"]), {
            "VSWR", "Driver overtemperature", "Array overtemperature", "Water flow", "Key switch",
            "Overcurrent", "Communication", "Array overpower", "LBO temperature",
        })

    def test_all_four_status_enumerations(self):
        for value, name in enumerate(("RUN", "STOP", "FAULT", "COUNTDOWN")):
            raw = STATUS_RX[:-1] + bytes((value,))
            result = parse_response(Frame(raw), (1, 1))
            self.assertEqual(result["state"], name)
            self.assertEqual(result["emission"], value in (0, 3))

    def test_firmware_dependent_frequency_and_unknown_firmware(self):
        self.assertEqual(
            parse_response(Frame(STATUS_RX), (0, 1))["service"]["qswitch_frequency_khz"], 10.0
        )
        self.assertIsNone(parse_response(Frame(STATUS_RX))["service"]["qswitch_frequency_khz"])
        self.assertEqual(parse_response(Frame(STATUS_RX))["_raw_status_fields"], {
            "current_word": 250, "frequency_word": 100, "width_word": 1,
        })

    def test_fragmented_rx_without_checksum(self):
        stream = FrameBuffer()
        self.assertEqual(stream.feed(b"noise\x10"), [])
        self.assertEqual(stream.feed(STATUS_RX[1:13]), [])
        result = stream.feed(STATUS_RX[13:] + bytes.fromhex("10 02 00 00 08 75 02 03"))
        self.assertEqual([frame.raw for frame in result], [STATUS_RX, bytes.fromhex("10 02 00 00 08 75 02 03")])
        self.assertEqual(stream.rejected, 0)
        self.assertEqual(parse_response(result[1])["qswitch"], 3)

    def test_service_raw_words_and_legacy_numeric_scale(self):
        result = parse_response(Frame(SERVICE_RX))
        self.assertEqual(result["max_current_a"], 25.0)
        service = result["service"]
        self.assertEqual(service["power_slope_mw_v"], 50.0)
        self.assertEqual(service["power_intercept_mw"], 1.0)
        self.assertEqual(service["max_power_mw"], 6.0)
        self.assertEqual(service["lbo_high_c"], 200.0)
        self.assertEqual(service["lbo_low_c"], 5.0)
        self.assertTrue(result["service_units_unverified"])
        self.assertEqual(service["_raw_words"], {
            "max_current": 250, "power_slope": 5000, "power_intercept": 100,
            "max_power": 600, "lbo_high": 2000, "lbo_low": 50,
        })

    def test_firmware_power_lbo_softstart_without_tx_checksum(self):
        self.assertEqual(parse_response(Frame(bytes.fromhex("10 02 00 00 0B 62 02 00 00 00 01")))["firmware_tuple"], (0, 1))
        self.assertEqual(parse_response(Frame(bytes.fromhex("10 02 00 00 09 72 02 02 58")))["power_w"], 6.0)
        self.assertEqual(parse_response(Frame(bytes.fromhex("10 02 00 00 0D 1A 02 00 00 00 00 06 A4")))["service"]["lbo_temp_c"], 170.0)
        soft = parse_response(Frame(bytes.fromhex("10 02 00 00 0A 69 02 01 00 04")))["service"]
        self.assertTrue(soft["soft_start_enabled"])
        self.assertEqual(soft["soft_start_rate_a_s"], 2.0)

    def test_truncated_status_fails_instead_of_fabricating_values(self):
        with self.assertRaises(ProtocolError):
            parse_response(Frame(STATUS_RX[:-1]), (1, 1))

    def test_unknown_fault_bits_and_unknown_state_remain_visible(self):
        raw = bytearray(STATUS_RX)
        raw[7:10] = bytes((0x84, 0x11, 0x64))
        raw[28] = 255
        result = parse_response(Frame(bytes(raw)), (1, 1))
        self.assertEqual(result["faults"], [])
        self.assertEqual(result["unknown_status_bits"], {7: 0x84, 8: 0x11, 9: 0x64})
        self.assertEqual(result["state"], "UNKNOWN (255)")
        self.assertIsNone(result["emission"])


if __name__ == "__main__":
    unittest.main()
