"""Worker ordering and lifecycle tests with deterministic synchronization."""
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from empower import commands
from empower.controller import SessionController
from empower.device import CurrentReadbackWarning


class FakeTransport:
    def __init__(self, trace):
        self.trace, self.sent = trace, []
        self.closed = threading.Event()
    def send(self, raw):
        self.sent.append(raw)
        self.trace("TX", raw)
    def close(self):
        self.closed.set()


class FakeDevice:
    def __init__(self, transport, simulated=False):
        self.transport = transport
        self.enabled = self.service_enabled = True
        self.data = {"connected": True, "comm_ok": True, "state": "STOP",
                     "faults": [], "service": {}, "simulated": simulated}
        self.actions = []
        self.entered, self.release = threading.Event(), threading.Event()
        self.stopped, self.service_done = threading.Event(), threading.Event()
        self.fail_block = False
        self.warn_block = False
    def initialize(self):
        pass
    def poll(self):
        pass
    def snapshot(self):
        return {**self.data, "service": dict(self.data["service"]), "control_enabled": self.enabled}
    def action(self, name, value=None):
        self.actions.append((name, value))
        if name == "block":
            self.entered.set()
            if not self.release.wait(2.0):
                raise AssertionError("Controlled action was not released")
            if self.fail_block:
                raise OSError("Controlled disconnected cable")
            if self.warn_block:
                raise CurrentReadbackWarning("Controlled differing readback")
        elif name == "enable_control":
            self.enabled = bool(value)
            if not value:
                self.service_enabled = False
        elif name == "enable_service":
            self.service_enabled = bool(value)
        elif name == "stop":
            self.stopped.set()
        elif name == "service_set":
            words = {key: 0 for key in commands.SERVICE_WORD_KEYS}
            self.transport.send(commands.set_service_words(int(value["access_code"]), words))
            self.service_done.set()
    def connection_failed(self):
        self.enabled = self.service_enabled = False
        self.data.update(comm_ok=False, state="UNKNOWN")


class SessionControllerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.notifications, self.devices, self.transports = [], [], []
        self.notification_condition = threading.Condition()
        self.connected, self.failed, self.ended = threading.Event(), threading.Event(), threading.Event()
        def notify(kind, value):
            with self.notification_condition:
                self.notifications.append((kind, value))
                self.notification_condition.notify_all()
            if kind == "connection" and value[0]:
                self.connected.set()
            if kind == "error":
                self.failed.set()
            if kind == "ended":
                self.ended.set()
        def make_transport(port, trace):
            transport = FakeTransport(trace)
            self.transports.append(transport)
            return transport
        def make_device(transport, simulated):
            device = FakeDevice(transport, simulated)
            self.devices.append(device)
            return device
        p1 = patch("empower.controller.SerialTransport", side_effect=make_transport)
        p2 = patch("empower.controller.Device", side_effect=make_device)
        self.transport_factory = p1.start()
        p2.start()
        self.addCleanup(p1.stop)
        self.addCleanup(p2.stop)
        self.controller = SessionController(notify, self.temp.name)
        self.addCleanup(self.shutdown)
        self.controller.submit("connect", "TEST-COM")
        self.assertTrue(self.connected.wait(1.0), "Worker did not connect")
        self.device = self.devices[0]
        self.wait_result("connect")

    def wait_result(self, name, value=None):
        def found():
            return next((result for kind, result in reversed(self.notifications)
                         if kind == "action_result" and result["name"] == name
                         and (value is None or result.get("value") == value)), None)
        with self.notification_condition:
            self.assertTrue(self.notification_condition.wait_for(found, 1.0), name)
            return found()

    def shutdown(self):
        for device in self.devices:
            device.release.set()
        if self.controller.thread.is_alive():
            self.controller.submit("shutdown")
            self.controller.thread.join(2.0)
        self.assertFalse(self.controller.thread.is_alive(), "Session worker leaked")

    def block_worker(self, fail=False):
        self.device.fail_block = fail
        self.controller.submit("block")
        self.assertTrue(self.device.entered.wait(1.0))

    def test_stop_cancels_queued_run_and_configuration(self):
        self.block_worker()
        self.controller.submit("run")
        self.controller.submit("set_current", 12.0)
        self.controller.submit("stop")
        self.device.release.set()
        self.assertTrue(self.device.stopped.wait(1.0))
        self.assertEqual([n for n, _ in self.device.actions], ["block", "stop"])

    def test_connection_failure_disables_and_drops_actions_without_replay(self):
        self.block_worker(fail=True)
        self.controller.submit("run")
        self.controller.submit("set_current", 12.0)
        self.device.release.set()
        self.assertTrue(self.failed.wait(1.0))
        self.assertIsNone(self.controller.device)
        self.assertFalse(self.device.enabled)
        self.assertFalse(self.device.service_enabled)
        self.assertEqual([n for n, _ in self.device.actions], ["block"])
        self.assertEqual(self.transports[0].sent, [commands.set_run(False)])
        self.assertTrue(self.transports[0].closed.is_set())
        self.assertEqual(self.transport_factory.call_count, 1)
        self.assertTrue(self.controller.output_unknown)

    def test_service_code_is_redacted_in_events_and_wire_trace(self):
        payload = {"key": "max_current_a", "value": 12, "access_code": "54321"}
        self.controller.submit("service_set", payload)
        self.assertTrue(self.device.service_done.wait(1.0))
        self.shutdown()
        persisted = "\n".join(p.read_text(encoding="utf-8") for p in Path(self.temp.name).glob("*.jsonl"))
        displayed = "\n".join(str(v) for k, v in self.notifications if k == "log")
        for text in (persisted, displayed):
            self.assertNotIn("54321", text)
            self.assertNotIn("d4 31", text)
            self.assertIn("** **", text)
        self.assertEqual(payload["access_code"], "54321")

    def test_normal_shutdown_stops_closes_worker_transport_and_logs(self):
        self.controller.submit("shutdown")
        self.assertTrue(self.ended.wait(1.0))
        self.controller.thread.join(1.0)
        self.assertFalse(self.controller.thread.is_alive())
        self.assertTrue(self.device.stopped.is_set())
        self.assertTrue(self.transports[0].closed.is_set())
        self.assertTrue(self.controller.log.events.closed)
        self.assertTrue(self.controller.log.readings.closed)
        self.assertIn(("ended", True), self.notifications)

    def test_shutdown_cannot_be_cancelled_by_later_stop_or_connect(self):
        self.block_worker()
        self.controller.submit("shutdown")
        self.controller.submit("stop")
        self.controller.submit("connect", "OTHER")
        self.controller.submit("run")
        self.device.release.set()
        self.assertTrue(self.ended.wait(1))
        self.assertEqual([n for n, _ in self.device.actions], ["block", "stop"])
        self.assertTrue(self.transports[0].closed.is_set())
        self.assertEqual(self.transport_factory.call_count, 1)

    def test_disconnect_survives_stop_and_shutdown_survives_disconnect(self):
        self.block_worker()
        self.controller.submit("disconnect")
        self.controller.submit("stop")
        self.controller.submit("set_current", 12)
        with self.controller.condition:
            self.assertEqual(list(self.controller.queue), [("disconnect", None)])
        self.controller.submit("shutdown")
        self.controller.submit("disconnect")
        self.device.release.set()
        self.assertTrue(self.ended.wait(1))
        self.assertEqual([n for n, _ in self.device.actions], ["block", "stop"])

    def test_control_revocation_discards_pending_writes_and_keeps_stop(self):
        self.block_worker()
        for name, value in (("run", None), ("reset", None), ("set_current", 12),
                            ("service_set", {}), ("enable_service", True)):
            self.controller.submit(name, value)
        self.controller.submit("enable_control", False)
        self.controller.submit("stop")
        self.device.release.set()
        self.assertTrue(self.wait_result("enable_control", False)["ok"])
        self.assertEqual([n for n, _ in self.device.actions], ["block", "stop", "enable_control"])
        self.assertFalse(self.device.enabled)
        self.assertFalse(self.device.service_enabled)
        snapshots = [value for kind, value in self.notifications if kind == "snapshot"]
        self.assertFalse(snapshots[-1]["control_enabled"])
        self.assertFalse(snapshots[-1]["service_enabled"])

    def test_service_revocation_discards_service_writes_but_keeps_current(self):
        self.block_worker()
        self.controller.submit("service_set", {})
        self.controller.submit("set_current", 12)
        self.controller.submit("enable_service", False)
        self.device.release.set()
        self.assertTrue(self.wait_result("set_current")["ok"])
        self.assertEqual([n for n, _ in self.device.actions], ["block", "enable_service", "set_current"])
        self.assertFalse(self.device.service_enabled)

    def test_readback_warning_preserves_pending_disarm(self):
        self.device.warn_block = True
        self.block_worker()
        self.controller.submit("run")
        self.controller.submit("enable_control", False)
        self.device.release.set()
        self.assertTrue(self.wait_result("enable_control", False)["ok"])
        self.assertEqual([n for n, _ in self.device.actions], ["block", "enable_control"])
        self.assertFalse(self.device.enabled)
        self.assertFalse(self.controller.output_unknown)
        self.assertFalse(self.transports[0].closed.is_set())

    def test_readback_warning_settles_explicit_auth_request_but_drops_hardware_writes(self):
        self.device.warn_block = True
        self.block_worker()
        self.controller.submit("enable_control", True)
        self.controller.submit("set_current", 12)
        self.device.release.set()
        self.assertTrue(self.wait_result("enable_control", True)["ok"])
        self.assertEqual([n for n, _ in self.device.actions], ["block", "enable_control"])
        self.assertFalse(self.controller.output_unknown)

    def test_log_close_failure_does_not_prevent_ended_notification(self):
        log = self.controller.log
        original_close = log.close
        def broken_close():
            original_close()
            raise OSError("close flush failed")
        with patch.object(log, "close", side_effect=broken_close):
            self.controller.submit("shutdown")
            self.assertTrue(self.ended.wait(1))
        self.assertTrue(self.device.stopped.is_set())
        self.assertTrue(self.transports[0].closed.is_set())
        self.assertTrue(log.events.closed)
        self.assertTrue(log.readings.closed)
        self.assertIn(("ended", True), self.notifications)

    def test_duplicate_connect_is_rejected_without_closing_healthy_session(self):
        self.controller.submit("connect", "OTHER")
        self.assertTrue(self.failed.wait(1))
        self.assertIs(self.controller.device, self.device)
        self.assertFalse(self.transports[0].closed.is_set())
        self.assertFalse(self.controller.output_unknown)
        self.assertEqual(self.transport_factory.call_count, 1)

    def test_event_log_failure_does_not_prevent_stop_or_cleanup(self):
        self.block_worker()
        log = self.controller.log
        with patch.object(log, "event", side_effect=OSError("disk full")):
            self.controller.submit("shutdown")
            self.device.release.set()
            self.assertTrue(self.ended.wait(1))
        self.assertTrue(self.device.stopped.is_set())
        self.assertTrue(self.transports[0].closed.is_set())
        self.assertTrue(log.events.closed)
        self.assertTrue(log.readings.closed)
        self.assertIn(("ended", True), self.notifications)
        self.assertTrue(any(k == "warning" and "logging disabled" in v for k, v in self.notifications))

    def test_logging_failure_during_communication_loss_still_reports_unknown(self):
        self.block_worker(fail=True)
        log = self.controller.log
        with patch.object(log, "event", side_effect=OSError("disk full")):
            self.device.release.set()
            self.assertTrue(self.failed.wait(1))
        self.assertTrue(self.controller.output_unknown)
        self.assertEqual(self.transports[0].sent, [commands.set_run(False)])
        self.assertTrue(self.transports[0].closed.is_set())
        self.shutdown()
        self.assertIn(("ended", False), self.notifications)

    def test_snapshot_log_failure_does_not_close_live_connection(self):
        self.block_worker()
        log = self.controller.log
        with patch.object(log, "snapshot", side_effect=OSError("disk full")):
            self.device.release.set()
            self.assertTrue(self.wait_result("block")["ok"])
        self.assertIs(self.controller.device, self.device)
        self.assertFalse(self.transports[0].closed.is_set())
        self.assertIsNone(self.controller.log)

    def test_wire_log_failure_does_not_fail_successful_command(self):
        log = self.controller.log
        with patch.object(log, "trace", side_effect=OSError("disk full")):
            self.controller.submit("service_set", {"key": "max_current_a", "value": 12,
                                                    "access_code": "54321"})
            self.assertTrue(self.wait_result("service_set")["ok"])
        self.assertIs(self.controller.device, self.device)
        self.assertFalse(self.controller.output_unknown)
        self.assertTrue(log.events.closed)
        self.assertTrue(log.readings.closed)

    def test_frontend_callback_failure_cannot_prevent_worker_cleanup(self):
        self.controller.notify = lambda *_: (_ for _ in ()).throw(RuntimeError("UI gone"))
        self.controller.submit("shutdown")
        self.controller.thread.join(1)
        self.assertFalse(self.controller.thread.is_alive())
        self.assertTrue(self.device.stopped.is_set())
        self.assertTrue(self.transports[0].closed.is_set())

    def test_snapshot_precedes_auth_result_and_counter_is_unknown(self):
        self.controller.submit("enable_control", True)
        self.assertTrue(self.wait_result("enable_control", True)["ok"])
        i = next(i for i, (kind, result) in enumerate(self.notifications)
                 if kind == "action_result" and result["name"] == "enable_control")
        kind, snapshot = self.notifications[i - 1]
        self.assertEqual(kind, "snapshot")
        self.assertTrue(snapshot["control_enabled"])
        self.assertIsNone(snapshot["service"]["communication_drops"])


if __name__ == "__main__":
    unittest.main()
