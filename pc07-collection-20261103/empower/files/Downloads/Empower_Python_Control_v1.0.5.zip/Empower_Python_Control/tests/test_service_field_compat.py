"""Compatibility tests for the original GUI's unlabelled numeric field.

Only CAPTURED_* fixtures are real response bytes from the uploaded captures.
All firmware write-acceptance/ignoring behavior, later reads, healthy STOP, and
failure injections are SYNTHETIC. Allowing wire numeric0 does not demonstrate
that a real device authorizes, accepts, or persists a service change.

A full code0 service write is identified by its complete payload, not merely
by its numeric word: the original startup read pattern also sends code0.
"""
from contextlib import contextmanager
import tempfile
import threading
import unittest
from unittest.mock import patch

from empower.controller import SessionController
from empower.device import Device, ServiceReadbackWarning, SettingReadbackWarning
from empower.framing import Frame, ProtocolError, decode


CAPTURED_FIRMWARE = bytes.fromhex("10 02 00 00 0C 62 00 48 43 01 02 0E")
CAPTURED_QSWITCH = bytes.fromhex("10 02 00 00 09 75 00 02 92")
CAPTURED_OPAQUE_RESET = bytes.fromhex("10 02 00 00 0C 18 00 00 20 00 02 58")
# MaxCurrent25A, MaxPower125(original GUI units), unchanged calibration words.
CAPTURED_SERVICE125 = bytes.fromhex(
    "10 02 00 00 15 70 00 00 FA 00 02 58 00 00 30 D4 05 46 04 9C DA"
)
# Literal independent TX expectations; no production command builder used.
SERVICE_READ_TX = bytes.fromhex(
    "10 02 00 00 17 50 02 00 00 00 00 00 00 00 00 00 00 00 00 5A 00 32 07"
)
MAXPOWER120_ZERO_TX = bytes.fromhex(
    "10 02 00 00 17 50 02 00 00 00 FA 00 02 58 00 00 2E E0 05 46 04 9C C8"
)
MAXCURRENT24_ZERO_TX = bytes.fromhex(
    "10 02 00 00 17 50 02 00 00 00 F0 00 02 58 00 00 30 D4 05 46 04 9C B4"
)
MAXPOWER120_CURRENT24_ZERO_TX = bytes.fromhex(
    "10 02 00 00 17 50 02 00 00 00 F0 00 02 58 00 00 2E E0 05 46 04 9C BE"
)
STOP_TX = bytes.fromhex("10 02 00 00 09 08 02 01 26")


def synthetic_checksum(body):
    return bytes(body) + bytes((sum(body) & 255,))


def synthetic_service120(current_word=250, power_word=12000):
    body = bytearray(CAPTURED_SERVICE125[:-1])
    body[7:9] = int(current_word).to_bytes(2, "big")
    body[14:16] = int(power_word).to_bytes(2, "big")
    return synthetic_checksum(body)


def synthetic_status(state=1, current_word=80):
    # Hypothetical healthy STOP/RUN with8A setting; not a hardware observation.
    body = bytes.fromhex(
        "10 02 00 00 1E 12 00 00 00 80 00 64 00 28 00 00 "
        "89 34 00 7A 00 50 00 00 01 47 C9 65"
    ) + bytes((state,))
    body = bytearray(body)
    body[20:22] = int(current_word).to_bytes(2, "big")
    return synthetic_checksum(body)


SYNTHETIC_LBO = synthetic_checksum(bytes.fromhex("10 02 00 00 0E 1A 00 00 00 00 00 05 05"))
SYNTHETIC_POWER = synthetic_checksum(bytes.fromhex("10 02 00 00 0A 72 00 00 00"))


class ServiceNumericPeer:
    """Explicitly hypothetical accepting/ignoring firmware on the real API."""
    def __init__(self, behavior="accept"):
        self.behavior = behavior
        self.tx = []
        self.trace = lambda direction, raw: None
        self.closed = threading.Event()
        self.state = 1
        self.current_word = 80
        self.service = CAPTURED_SERVICE125
        self.service_read_count = 0
        self.write_count = 0
        self.followup_read_count = 0
        self.status_after_write_count = 0
        self.stop_sent = False

    def send(self, raw):
        if self.closed.is_set():
            raise OSError("Synthetic service peer is closed")
        decode(raw, verify_checksum=True)
        self.tx.append(bytes(raw))
        self.trace("TX", raw)
        if raw[5] == 0x08:
            if raw != STOP_TX:
                raise AssertionError("These tests never request RUN")
            self.stop_sent = True
            self.state = 1

    def exchange(self, raw, expected):
        self.send(raw)
        op = raw[5]
        if op == 0x50 and raw != SERVICE_READ_TX:
            self.write_count += 1
            expected_updates = {
                MAXPOWER120_ZERO_TX: (250, 12000),
                MAXCURRENT24_ZERO_TX: (240, 12500),
                MAXPOWER120_CURRENT24_ZERO_TX: (240, 12000),
            }
            if raw not in expected_updates:
                raise AssertionError("Full preserved service payload differs from literal expectation")
            if self.behavior == "write_timeout":
                raise TimeoutError("Synthetic write response timeout")
            accepted = synthetic_service120(*expected_updates[raw])
            if self.behavior == "ignore":
                reply = self.service
            elif self.behavior == "echo_then_ignore":
                reply = accepted
            else:
                self.service = accepted
                reply = accepted
            if self.behavior == "untouched_changed":
                body = bytearray(reply[:-1])
                body[7:9] = b"\x00\xf0"  # SYNTHETIC unexpected24A maximum.
                reply = synthetic_checksum(body)
            if self.behavior == "bad_ack_checksum":
                reply = reply[:-1] + bytes((reply[-1] ^ 1,))
        elif op == 0x50:
            self.service_read_count += 1
            if self.behavior == "run_during_pre_read" and self.service_read_count == 2:
                self.state = 0
            if self.behavior == "current_increases_during_pre_read" and self.service_read_count == 2:
                self.current_word = 220  # SYNTHETIC other-controller change, still STOP.
            reply = self.service
            if self.write_count:
                self.followup_read_count += 1
                if self.behavior == "read_timeout":
                    raise TimeoutError("Synthetic follow-up read timeout")
                if self.behavior == "bad_read_checksum":
                    reply = reply[:-1] + bytes((reply[-1] ^ 1,))
        else:
            if op == 0x02 and self.write_count:
                self.status_after_write_count += 1
                if self.behavior == "status_timeout":
                    raise TimeoutError("Synthetic required status timeout")
            replies = {
                0x42: CAPTURED_FIRMWARE,
                0x02: synthetic_status(self.state, self.current_word),
                0x55: CAPTURED_QSWITCH,
                0x09: CAPTURED_OPAQUE_RESET,
                0x0B: SYNTHETIC_LBO,
                0x52: SYNTHETIC_POWER,
            }
            if op not in replies:
                raise AssertionError(f"Unexpected service-test request0x{op:02X}")
            reply = replies[op]
        if reply[5] not in expected:
            raise TimeoutError(f"Synthetic reply0x{reply[5]:02X} not in{expected}")
        self.trace("RX_BYTES", reply)
        return Frame(reply)

    def full_service_writes(self):
        return [raw for raw in self.tx if raw[5] == 0x50 and raw != SERVICE_READ_TX]

    def stop_commands(self):
        return [raw for raw in self.tx if raw[5] == 0x08]

    def close(self):
        self.closed.set()


class ServiceFieldCompatibility(unittest.TestCase):
    @staticmethod
    def payload(numeric=""):
        return {"key": "max_power_mw", "value": 120, "access_code": numeric}

    def make_device(self, behavior="accept", arm=True):
        peer = ServiceNumericPeer(behavior)
        device = Device(peer, simulated=False)
        device.initialize()
        if arm:
            device.action("enable_control", True)
            device.action("enable_service", True)
        return device, peer

    def test_blank_and_explicit_zero_serialize_identical_preserved_payload_when_synthetic_peer_accepts(self):
        for numeric in ("", "0", 0):
            with self.subTest(numeric=numeric):
                device, peer = self.make_device()
                self.assertEqual(device.data["service"]["max_power_mw"], 125)
                self.assertEqual(device.data["max_current_a"], 25)
                device.action("service_set", self.payload(numeric))
                self.assertEqual(peer.full_service_writes(), [MAXPOWER120_ZERO_TX])
                self.assertEqual(peer.full_service_writes()[0][7:9], b"\x00\x00")
                self.assertEqual(device.data["service"]["_raw_words"], {
                    "max_current": 250, "power_slope": 600, "power_intercept": 0,
                    "max_power": 12000, "lbo_high": 1350, "lbo_low": 1180,
                })
                write_index = peer.tx.index(MAXPOWER120_ZERO_TX)
                self.assertEqual(peer.tx[write_index + 1], SERVICE_READ_TX)
                self.assertEqual(peer.tx[write_index + 2][5], 0x02)
                self.assertEqual(peer.followup_read_count, 1)
                self.assertEqual(peer.status_after_write_count, 1)
                self.assertEqual(device.data["service_setting_warning"], "")
                self.assertEqual(device.snapshot()["setting_warning"], "")
                self.assertTrue(device.data["comm_ok"])
                self.assertFalse(peer.stop_commands())
                self.assertFalse(peer.closed.is_set())

    def test_ignoring_zero_is_warning_not_acceptance_or_retry(self):
        for numeric in ("", "0"):
            with self.subTest(numeric=numeric):
                device, peer = self.make_device("ignore")
                with self.assertRaises(ServiceReadbackWarning) as caught:
                    device.action("service_set", self.payload(numeric))
                self.assertIsInstance(caught.exception, SettingReadbackWarning)
                self.assertIn("requested 120; reply 125; re-read 125", str(caught.exception))
                self.assertEqual(device.data["service"]["max_power_mw"], 125)
                self.assertEqual(peer.full_service_writes(), [MAXPOWER120_ZERO_TX])
                self.assertTrue(device.data["comm_ok"])
                self.assertTrue(device.data["connected"])
                self.assertFalse(peer.stop_commands())
                self.assertFalse(peer.closed.is_set())

    def test_echo_is_not_application_followup_read_can_disagree(self):
        device, peer = self.make_device("echo_then_ignore")
        with self.assertRaisesRegex(ServiceReadbackWarning, "requested 120; reply 120; re-read 125"):
            device.action("service_set", self.payload())
        self.assertEqual(device.data["service"]["max_power_mw"], 125)
        self.assertEqual(peer.followup_read_count, 1)
        self.assertEqual(peer.status_after_write_count, 1)
        self.assertEqual(peer.full_service_writes(), [MAXPOWER120_ZERO_TX])
        self.assertIn("unconfirmed", device.snapshot()["setting_warning"])
        self.assertTrue(device.data["comm_ok"])

    def test_maximum_current_uses_final_fresh_stopped_setpoint(self):
        device, peer = self.make_device("current_increases_during_pre_read")
        self.assertEqual(device.data["state"], "STOP")
        self.assertEqual(device.data["current_set_a"], 8)
        with self.assertRaisesRegex(ValueError, "Lower the operating current setpoint"):
            device.action("service_set", {
                "key": "max_current_a", "value": 20, "access_code": "",
            })
        self.assertEqual(device.data["state"], "STOP")
        self.assertEqual(device.data["current_set_a"], 22)
        self.assertEqual(peer.full_service_writes(), [])
        self.assertEqual(peer.stop_commands(), [])
        self.assertTrue(device.data["comm_ok"])
        self.assertFalse(peer.closed.is_set())

    def test_success_resolves_only_its_own_unconfirmed_service_field(self):
        device, peer = self.make_device("ignore")
        with self.assertRaises(ServiceReadbackWarning):
            device.action("service_set", self.payload())
        power_warning = device.data["service_setting_warning"]
        self.assertIn("max_power_mw", power_warning)
        maximum_payload = {"key": "max_current_a", "value": 24, "access_code": ""}
        with self.assertRaises(ServiceReadbackWarning):
            device.action("service_set", maximum_payload)
        self.assertIn(power_warning, device.snapshot()["setting_warning"])
        self.assertIn("max_current_a", device.snapshot()["setting_warning"])
        peer.behavior = "accept"  # Explicitly hypothetical acceptance on next request.
        device.action("service_set", maximum_payload)
        self.assertEqual(device.data["max_current_a"], 24)
        self.assertEqual(device.data["service_setting_warning"], power_warning)
        self.assertIn(power_warning, device.snapshot()["setting_warning"])
        self.assertNotIn("max_current_a", device.snapshot()["setting_warning"])
        device.action("service_set", self.payload())
        self.assertEqual(device.data["service"]["max_power_mw"], 120)
        self.assertEqual(device.data["service_setting_warning"], "")
        self.assertEqual(device.snapshot()["setting_warning"], "")
        self.assertEqual(peer.full_service_writes(), [
            MAXPOWER120_ZERO_TX, MAXCURRENT24_ZERO_TX,
            MAXCURRENT24_ZERO_TX, MAXPOWER120_CURRENT24_ZERO_TX,
        ])
        self.assertEqual(peer.stop_commands(), [])
        self.assertFalse(peer.closed.is_set())

    def test_checksum_untouched_field_and_timeout_errors_remain_strict(self):
        cases = (
            ("untouched_changed", ProtocolError),
            ("bad_ack_checksum", ProtocolError),
            ("bad_read_checksum", ProtocolError),
            ("write_timeout", TimeoutError),
            ("read_timeout", TimeoutError),
            ("status_timeout", TimeoutError),
        )
        for behavior, expected_error in cases:
            with self.subTest(behavior=behavior):
                device, peer = self.make_device(behavior)
                with self.assertRaises(expected_error):
                    device.action("service_set", self.payload())
                self.assertFalse(device.data.get("service_setting_warning"))
                self.assertEqual(peer.full_service_writes(), [MAXPOWER120_ZERO_TX])

    def test_control_service_and_fresh_stop_gates_still_apply_to_zero(self):
        device, peer = self.make_device(arm=False)
        with self.assertRaises(ValueError):
            device.action("service_set", self.payload())
        device.action("enable_control", True)
        with self.assertRaises(ValueError):
            device.action("service_set", self.payload())
        self.assertFalse(peer.full_service_writes())
        # Another controller begins RUN after the first STOP check but during
        # the pre-write read. The second fresh STOP check must catch it.
        device, peer = self.make_device("run_during_pre_read")
        with self.assertRaisesRegex(ValueError, "Stop the laser"):
            device.action("service_set", self.payload())
        self.assertEqual(device.data["state"], "RUN")
        self.assertFalse(peer.full_service_writes())
        device, peer = self.make_device()
        device.interrupt_poll = lambda: True
        with self.assertRaisesRegex(ValueError, "cancelled"):
            device.action("service_set", self.payload())
        self.assertFalse(peer.full_service_writes())

    @contextmanager
    def worker(self, behavior):
        peer = ServiceNumericPeer(behavior)
        events = {name: threading.Event() for name in
                  ("connected", "armed", "warning", "error", "polled", "stopped", "ended")}
        notifications = []

        def notify(kind, value):
            notifications.append((kind, value))
            if kind == "connection" and value[0]:
                events["connected"].set()
            elif kind in ("warning", "error", "ended"):
                events[kind].set()
            elif kind == "snapshot":
                if value.get("control_enabled"):
                    events["armed"].set()
                if peer.status_after_write_count >= 2 and value.get("setting_warning"):
                    events["polled"].set()
                if peer.stop_sent and value.get("state") == "STOP":
                    events["stopped"].set()

        def transport_factory(port, trace):
            self.assertEqual(port, "SYNTHETIC-SERVICE-PEER")
            peer.trace = trace
            return peer

        with tempfile.TemporaryDirectory() as directory, patch(
                "empower.controller.SerialTransport", side_effect=transport_factory):
            controller = SessionController(notify, directory)
            try:
                controller.submit("connect", "SYNTHETIC-SERVICE-PEER")
                self.assertTrue(events["connected"].wait(2))
                self.assertIsInstance(controller.device, Device)
                controller.submit("enable_control", True)
                self.assertTrue(events["armed"].wait(2))
                controller.submit("enable_service", True)
                yield controller, peer, events, notifications
            finally:
                if controller.thread.is_alive():
                    controller.submit("shutdown")
                    self.assertTrue(events["ended"].wait(2))
                    controller.thread.join(2)
                self.assertFalse(controller.thread.is_alive(), "Service test worker leaked")

    def test_real_worker_service_warning_keeps_polling_and_explicit_stop_without_retry(self):
        with self.worker("echo_then_ignore") as session:
            controller, peer, events, notifications = session
            controller.submit("service_set", self.payload())
            self.assertTrue(events["warning"].wait(2))
            self.assertFalse(events["error"].is_set())
            self.assertFalse(controller.output_unknown)
            self.assertEqual(peer.full_service_writes(), [MAXPOWER120_ZERO_TX])
            self.assertEqual(peer.stop_commands(), [])
            self.assertFalse(peer.closed.is_set())
            self.assertEqual(controller.device.snapshot()["service"]["max_power_mw"], 125)
            self.assertTrue(events["polled"].wait(2), "Status polling did not continue after warning")
            self.assertEqual(peer.full_service_writes(), [MAXPOWER120_ZERO_TX])
            self.assertEqual(peer.stop_commands(), [], "A service warning must not send STOP or RUN")
            controller.submit("stop")
            self.assertTrue(events["stopped"].wait(2))
            self.assertEqual(peer.stop_commands(), [STOP_TX])
            self.assertTrue(controller.device.snapshot()["comm_ok"])
            self.assertFalse(peer.closed.is_set())

    def test_real_worker_does_not_downgrade_unexpected_changes_checksum_or_timeout(self):
        for behavior in ("untouched_changed", "bad_read_checksum", "read_timeout"):
            with self.subTest(behavior=behavior), self.worker(behavior) as session:
                controller, peer, events, notifications = session
                controller.submit("service_set", self.payload())
                self.assertTrue(events["error"].wait(2))
                self.assertFalse(events["warning"].is_set())
                self.assertTrue(peer.closed.wait(2))
                self.assertTrue(controller.output_unknown)
                self.assertIsNone(controller.device)
                self.assertEqual(peer.full_service_writes(), [MAXPOWER120_ZERO_TX])
                self.assertEqual(peer.stop_commands(), [STOP_TX])


if __name__ == "__main__":
    unittest.main()
