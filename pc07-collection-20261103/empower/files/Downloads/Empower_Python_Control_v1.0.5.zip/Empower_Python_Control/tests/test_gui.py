"""Offscreen operator-control tests; no serial hardware or elapsed 5 s waits.

These exercise authorization and command-emission boundaries, not cosmetic
implementation details. Hardware protocol coverage lives in the other tests.
"""
import os
import unittest
from unittest.mock import patch

# Must precede QApplication creation; retain one instance for discovery runs.
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QEvent, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QLineEdit, QMessageBox

from empower.gui import MainWindow


_APP = QApplication.instance() or QApplication([])


def stopped_snapshot(simulated=True, **updates):
    result = {
        "connected": True,
        "simulated": simulated,
        "control_enabled": simulated,
        "service_enabled": False,
        "comm_ok": True,
        "state": "STOP",
        "emission": False,
        "current_set_a": 12.0,
        "current_a": 0.0,
        "max_current_a": 25.0,
        "power_w": 0.0,
        "qswitch": 3,
        "faults": [],
        "firmware": "2.0",
        "firmware_tuple": (2, 0),
        "hours": 483.1,
        "raw_status": "test fixture",
        "timestamp": "2026-09-23T12:00:00",
        "service": {
            "max_current_a": 25.0,
            "max_power_mw": 6.0,
            "underfrequency_enabled": True,
            "soft_start_enabled": True,
            "lbo_stability_enabled": True,
            "lbo_temp_c": 148.4,
            "lbo_monitor": "Warming up 1/180 samples",
        },
    }
    result.update(updates)
    return result


class GuiControls(unittest.TestCase):
    def setUp(self):
        self.window = MainWindow()
        self.actions = []
        self.window.action_requested.connect(
            lambda name, value: self.actions.append((name, value))
        )
        self.window.show()
        self.window.activateWindow()
        _APP.processEvents()

    def tearDown(self):
        self.window.allow_close = True
        self.window.close()
        self.window.deleteLater()
        _APP.processEvents()

    def press_run(self):
        QTest.mousePress(self.window.run_button, Qt.MouseButton.LeftButton)

    def release_run(self):
        QTest.mouseRelease(self.window.run_button, Qt.MouseButton.LeftButton)

    def confirm_authorization(self, name, value=True):
        key = "control_enabled" if name == "enable_control" else "service_enabled"
        self.window.update_snapshot(dict(self.window._snapshot, **{key: value}))
        self.window.action_result({"name": name, "value": value, "ok": True})

    def enable_control(self):
        self.window.arm_checkbox.setChecked(True)
        self.confirm_authorization("enable_control")

    def enable_service(self):
        self.window.service_checkbox.setChecked(True)
        self.confirm_authorization("enable_service")

    def test_initialization_and_readbacks_emit_no_writes(self):
        self.assertEqual(self.window.port_combo.currentText(), "SIMULATOR")
        self.assertFalse(self.window.run_button.isEnabled())
        self.assertFalse(self.window.stop_button.isEnabled())
        self.assertFalse(self.window.arm_checkbox.isChecked())
        self.assertFalse(self.window.service_checkbox.isChecked())
        self.window.update_snapshot(stopped_snapshot())
        self.assertEqual(self.actions, [])
        self.assertEqual(self.window.current_input.maximum(), 25.0)
        self.assertEqual(self.window.current_input.value(), 12.0)
        self.assertEqual(self.window.qswitch_readback.text(), "External")
        self.assertFalse(self.window.service_widgets["max_current_a"][2].isEnabled())

    def test_hardware_write_gates_preserve_stop_and_disarm_service(self):
        self.window.update_snapshot(stopped_snapshot(simulated=False))
        for button in (self.window.run_button, self.window.apply_current_button,
                       self.window.apply_qswitch_button, self.window.reset_button):
            self.assertFalse(button.isEnabled())
        self.assertTrue(self.window.stop_button.isEnabled())
        self.enable_control()
        self.assertIn(("enable_control", True), self.actions)
        self.assertTrue(self.window.run_button.isEnabled())
        self.assertTrue(self.window.apply_current_button.isEnabled())
        self.enable_service()
        self.assertTrue(self.window.service_widgets["max_current_a"][2].isEnabled())
        self.window.arm_checkbox.setChecked(False)
        self.assertFalse(self.window.service_checkbox.isChecked())
        self.assertIn(("enable_service", False), self.actions)
        self.assertTrue(self.window.stop_button.isEnabled())

    def test_new_fault_disarms_but_persistent_fault_can_be_rearmed_for_reset(self):
        self.window.update_snapshot(stopped_snapshot(simulated=False))
        self.enable_control()
        fault = stopped_snapshot(simulated=False, state="FAULT", faults=["Keyswitch"])
        self.window.update_snapshot(fault)
        self.assertFalse(self.window.arm_checkbox.isChecked())
        self.assertTrue(self.window.arm_checkbox.isEnabled())
        self.enable_control()
        self.window.update_snapshot(dict(fault, control_enabled=True))
        self.assertTrue(self.window.arm_checkbox.isChecked())
        self.assertTrue(self.window.reset_button.isEnabled())
        self.assertFalse(self.window.run_button.isEnabled())
        self.assertFalse(self.window.current_input.isEnabled())
        self.assertFalse(self.window.apply_current_button.isEnabled())
        self.assertTrue(self.window.stop_button.isEnabled())
        self.window.reset_button.click()
        self.assertEqual(self.actions[-1], ("reset", None))

    def test_short_hold_and_focus_or_pointer_loss_cancel_run(self):
        self.window.update_snapshot(stopped_snapshot())
        with patch("empower.gui.time.monotonic", return_value=100.0):
            self.press_run()
            self.assertTrue(self.window._hold_active)
            self.release_run()
            self.assertFalse(self.window._hold_active)
            for event_type in (QEvent.Type.FocusOut, QEvent.Type.Leave):
                self.press_run()
                self.assertTrue(self.window._hold_active)
                _APP.sendEvent(self.window.run_button, QEvent(event_type))
                self.assertFalse(self.window._hold_active)
                self.release_run()
        self.assertEqual(self.actions, [])

    def test_five_second_hold_emits_once_without_inventing_emission(self):
        with patch("empower.gui.time.monotonic") as clock:
            clock.return_value = 100.0
            self.window.update_snapshot(stopped_snapshot(status_age_s=0.0, status_fresh=True))
            self.press_run()
            clock.return_value = 104.5
            self.window.update_snapshot(stopped_snapshot(status_age_s=0.0, status_fresh=True))
            clock.return_value = 104.99
            self.window._tick_hold()
            self.assertEqual(self.actions, [])
            clock.return_value = 105.01
            self.window._tick_hold()
            self.assertEqual(self.actions, [("run", None)])
            self.release_run()
            self.window._tick_hold()
        self.assertEqual(self.actions, [("run", None)])
        self.assertEqual(self.window.emission_label.text(), "OFF")
        self.assertEqual(self.window.state_label.text(), "STOP")
        self.assertTrue(self.window._run_pending)
        self.window.action_result({"name": "run", "ok": False})
        self.assertFalse(self.window._run_pending)
        self.assertFalse(self.window._pending_timer.isActive())
        self.assertEqual(self.window.emission_label.text(), "OFF")
        self.assertEqual(self.actions, [("run", None)])

    def test_stop_cancels_hold_and_pending_run_and_stays_available_unarmed(self):
        self.window.update_snapshot(stopped_snapshot())
        with patch("empower.gui.time.monotonic", return_value=100.0):
            self.press_run()
            self.window._stop()
            self.release_run()
        self.assertFalse(self.window._hold_active)
        self.assertEqual(self.actions, [("stop", None)])
        with patch("empower.gui.time.monotonic") as clock:
            clock.return_value = 100.0
            self.press_run()
            clock.return_value = 105.1
            self.window._tick_hold()
        self.assertTrue(self.window._run_pending)
        self.window.stop_button.click()
        self.assertFalse(self.window._run_pending)
        self.assertFalse(self.window._pending_timer.isActive())
        self.assertEqual(self.actions[-2:], [("run", None), ("stop", None)])
        self.window.update_snapshot(stopped_snapshot(simulated=False))
        self.window.stop_button.click()
        self.assertEqual(self.actions[-1], ("stop", None))

    def test_communication_loss_clears_certainty_and_connection_cancels_hold(self):
        running = stopped_snapshot(simulated=False, state="RUN", emission=True, power_w=6.3)
        self.window.update_snapshot(running)
        self.enable_control()
        self.assertEqual(self.window.emission_label.text(), "ON")
        self.window.update_snapshot(dict(running, comm_ok=False))
        self.assertEqual(self.window.emission_label.text(), "--")
        self.assertEqual(self.window.state_label.text(), "--")
        self.assertEqual(self.window.power_label.text(), "--")
        self.assertFalse(self.window.arm_checkbox.isChecked())
        self.assertFalse(self.window.run_button.isEnabled())
        self.assertTrue(self.window.stop_button.isEnabled())
        self.window.update_snapshot(stopped_snapshot())
        with patch("empower.gui.time.monotonic", return_value=100.0):
            self.press_run()
            self.window.set_connection(False, "Disconnected")
            self.release_run()
        self.assertFalse(self.window._hold_active)
        self.assertFalse(self.window.stop_button.isEnabled())
        self.assertNotIn(("run", None), self.actions)

    def test_known_state_views_and_service_fields_do_not_create_default_writes(self):
        self.window.update_snapshot(stopped_snapshot(qswitch=0))
        self.assertIn("CW RF OFF", self.window.qswitch_readback.text())
        self.assertEqual(
            [self.window.qswitch_combo.itemData(i) for i in range(self.window.qswitch_combo.count())],
            [None, 3, 2, 1],
        )
        self.enable_service()
        self.assertTrue(self.window.service_widgets["max_current_a"][2].isEnabled())
        self.assertFalse(self.window.service_widgets["power_slope_mw_v"][2].isEnabled())
        self.assertEqual(self.window.service_access_code.text(), "")
        self.assertIn("Warming up", self.window.lbo_monitor_label.text())
        for state, emission in (("COUNTDOWN", False), ("RUN", True), ("STOP", False)):
            self.window.update_snapshot(stopped_snapshot(state=state, emission=emission))
            self.assertEqual(self.window.state_label.text(), state)
            self.assertEqual(self.window.emission_label.text(), "ON" if emission else "OFF")
        for index in range(self.window.tabs.count()):
            self.window.tabs.setCurrentIndex(index)
            _APP.processEvents()
            self.assertTrue(self.window.stop_button.isVisible())
            self.assertTrue(self.window.power_label.isVisible())
        self.assertFalse([name for name, _ in self.actions if name in ("service_set", "set_current", "set_qswitch", "run")])

    def test_current_readback_mismatch_preserves_independent_values_and_controls(self):
        running = stopped_snapshot(
            simulated=False, state="RUN", emission=True,
            current_set_a=12.5, current_a=7.1,
        )
        self.window.update_snapshot(running)
        self.enable_control()
        running["control_enabled"] = True
        self.window.current_input.setValue(14.5)
        self.actions.clear()
        warning = (
            "Current request 14.5 A was not confirmed: controller set point is "
            "12.5 A. No automatic retry."
        )
        mismatch = dict(running, current_request_a=14.5, setting_warning=warning)
        self.window.update_snapshot(mismatch)
        self.assertEqual(self.window.current_requested_label.text(), "14.5 A")
        self.assertEqual(self.window.current_set_label.text(), "12.5 A")
        self.assertEqual(self.window.current_label.text(), "7.1")
        self.assertEqual(self.window.current_input.value(), 14.5)
        self.assertEqual(self.window.state_label.text(), "RUN")
        self.assertEqual(self.window.emission_label.text(), "ON")
        self.assertTrue(self.window.stop_button.isEnabled())
        self.assertTrue(self.window.current_input.isEnabled())
        self.assertTrue(self.window.apply_current_button.isEnabled())
        self.assertEqual(self.window.setting_warning_label.text(), warning)
        self.assertTrue(self.window.setting_warning_label.wordWrap())
        for index in range(self.window.tabs.count()):
            self.window.tabs.setCurrentIndex(index)
            _APP.processEvents()
            self.assertTrue(self.window.setting_warning_label.isVisible())
            self.assertTrue(self.window.stop_button.isVisible())
        self.window.update_snapshot(mismatch)
        self.assertEqual(self.actions, [])

    def test_setting_warning_clears_and_is_hidden_for_unavailable_connection(self):
        mismatch = stopped_snapshot(
            current_request_a=14.5, current_set_a=12.5,
            setting_warning="Requested current differs from controller readback.",
        )
        self.window.update_snapshot(mismatch)
        self.assertTrue(self.window.setting_warning_label.isVisible())
        self.window.update_snapshot(dict(mismatch, setting_warning=""))
        self.assertFalse(self.window.setting_warning_label.isVisible())
        self.assertEqual(self.window.setting_warning_label.text(), "")
        self.window.update_snapshot(mismatch)
        self.window.update_snapshot(dict(mismatch, comm_ok=False))
        self.assertFalse(self.window.setting_warning_label.isVisible())
        self.assertEqual(self.window.current_requested_label.text(), "-- A")
        self.window.update_snapshot(mismatch)
        self.window.set_connection(False, "Disconnected")
        self.assertFalse(self.window.setting_warning_label.isVisible())
        self.assertEqual(self.window.setting_warning_label.text(), "")
        self.assertEqual(self.window.current_requested_label.text(), "-- A")
        self.window.update_snapshot(stopped_snapshot())
        self.assertFalse(self.window.setting_warning_label.isVisible())
        self.assertEqual(self.window.current_requested_label.text(), "-- A")
        self.assertEqual(self.actions, [])

    def test_status_history_excludes_raw_traffic_while_communication_log_keeps_it(self):
        traffic = [
            "2026-09-23T12:00:00  TX  53 50 00 00",
            "2026-09-23T12:00:00  RX  53 50 00 00",
            "2026-09-23T12:00:00  RX_BYTES  53 50 00 00",
            "RX_BYTES: 53 50 00 00",
        ]
        action = "2026-09-23T12:00:01  Action set_current: 14.5"
        for line in traffic + [action]:
            self.window.append_log(line)
        communication = self.window.comm_log.toPlainText()
        history = self.window.status_log.toPlainText()
        for line in traffic:
            self.assertIn(line, communication)
            self.assertNotIn(line, history)
        self.assertIn(action, communication)
        self.assertIn(action, history)

    def test_current_changes_require_recognized_state_without_faults_or_unknown_bits(self):
        for state in ("STOP", "RUN", "COUNTDOWN"):
            with self.subTest(state=state):
                self.window.update_snapshot(stopped_snapshot(state=state))
                self.assertTrue(self.window.current_input.isEnabled())
                self.assertTrue(self.window.apply_current_button.isEnabled())
        for updates in (
            {"state": "UNKNOWN"},
            {"state": "FAULT"},
            {"state": "UNRECOGNIZED"},
            {"state": "STOP", "faults": ["Communication"]},
            {"state": "RUN", "unknown_status_bits": "byte9:0x20"},
        ):
            with self.subTest(updates=updates):
                self.window.update_snapshot(stopped_snapshot(**updates))
                self.assertFalse(self.window.current_input.isEnabled())
                self.assertFalse(self.window.apply_current_button.isEnabled())
                self.assertTrue(self.window.stop_button.isEnabled())
                self.window._apply_current()
        self.assertNotIn("set_current", [name for name, _ in self.actions])
        self.window.update_snapshot(stopped_snapshot(unknown_status_bits=""))
        self.assertTrue(self.window.apply_current_button.isEnabled())

    def test_service_numeric_field_blank_and_hidden_values_use_one_confirmation_and_write(self):
        self.window.update_snapshot(stopped_snapshot())
        self.enable_service()
        self.assertEqual(self.window.service_access_code.echoMode(), QLineEdit.EchoMode.Password)
        for field_text, expected_mode in (("", "blank → 0"), ("7319", "provided; hidden")):
            with self.subTest(field_text=bool(field_text)):
                self.actions.clear()
                self.window.service_access_code.setText(field_text)
                self.window.service_widgets["max_current_a"][1].setText("24")
                with patch("empower.gui.QMessageBox.question", return_value=QMessageBox.StandardButton.Yes) as question:
                    self.window._apply_service("max_current_a")
                question.assert_called_once()
                confirmation = question.call_args.args[2]
                self.assertIn("Service numeric field: " + expected_mode, confirmation)
                self.assertIn("Only controller readback confirms application.", confirmation)
                if field_text:
                    self.assertNotIn(field_text, confirmation)
                expected = [("service_set", {"key": "max_current_a", "value": 24.0, "access_code": field_text})]
                self.assertEqual(self.actions, expected)
                self.window.update_snapshot(stopped_snapshot(service_enabled=True))
                self.assertEqual(self.actions, expected)

    def test_current_typing_survives_unchanged_poll_until_explicit_apply(self):
        snapshot = stopped_snapshot()
        self.window.update_snapshot(snapshot)
        editor = self.window.current_input
        editor.lineEdit().selectAll()
        QTest.keyClicks(editor.lineEdit(), "14.5")
        self.window.update_snapshot(snapshot)
        self.assertEqual(editor.lineEdit().text(), "14.5 A")
        self.assertEqual(self.actions, [])
        QTest.keyClick(editor, Qt.Key.Key_Return)
        self.assertEqual(self.actions, [])
        self.window.apply_current_button.click()
        self.assertEqual(self.actions, [("set_current", 14.5)])

    def test_service_selection_and_requested_edit_survive_poll_and_apply(self):
        snapshot = stopped_snapshot()
        self.window.update_snapshot(snapshot)
        self.enable_service()
        snapshot["service_enabled"] = True
        self.window.tabs.setCurrentIndex(3)
        readback, editor, button = self.window.service_widgets["max_power_mw"]
        editor.selectAll()
        self.window.update_snapshot(snapshot)
        self.assertEqual(editor.selectedText(), "6")
        QTest.keyClicks(editor, "7")
        self.actions.clear()
        with patch("empower.gui.QMessageBox.question", return_value=QMessageBox.StandardButton.Yes):
            button.click()
        self.assertEqual(len(self.actions), 1)
        self.assertEqual(self.actions[0][1]["value"], 7)
        self.window.update_snapshot(snapshot)  # older queued poll before ACK
        self.assertEqual(editor.text(), "7")
        self.assertEqual(readback.text(), "6.000")
        editor.selectAll()
        QTest.keyClicks(editor, "8")
        confirmed = dict(snapshot, service=dict(snapshot["service"], max_power_mw=7.0))
        self.window.update_snapshot(confirmed)
        self.assertEqual(editor.text(), "8")
        self.assertEqual(readback.text(), "7.000")
        self.assertEqual(len(self.actions), 1)

    def test_authorization_waits_for_worker_and_failed_enable_settles_checkbox(self):
        snapshot = stopped_snapshot(simulated=False)
        self.window.update_snapshot(snapshot)
        self.window.arm_checkbox.setChecked(True)
        self.assertFalse(self.window.run_button.isEnabled())
        self.window.update_snapshot(snapshot)  # pre-command snapshot
        self.assertTrue(self.window.arm_checkbox.isChecked())
        self.assertFalse(self.window.apply_current_button.isEnabled())
        self.window.action_result({"name": "enable_control", "ok": False, "value": True})
        self.assertFalse(self.window.arm_checkbox.isChecked())
        self.enable_control()
        self.assertTrue(self.window.run_button.isEnabled())
        self.window.service_checkbox.setChecked(True)
        self.assertFalse(self.window.service_widgets["max_current_a"][2].isEnabled())
        self.window.action_result({"name": "enable_service", "ok": False, "value": True})
        self.assertFalse(self.window.service_checkbox.isChecked())
        self.enable_service()
        self.assertTrue(self.window.service_widgets["max_current_a"][2].isEnabled())
        self.actions.clear()
        self.window.update_snapshot(dict(self.window._snapshot, control_enabled=False, service_enabled=False))
        self.assertFalse(self.window.arm_checkbox.isChecked())
        self.assertFalse(self.window.service_checkbox.isChecked())
        self.assertFalse(self.window.run_button.isEnabled())
        self.assertTrue(self.window.stop_button.isEnabled())
        self.assertEqual(self.actions, [])

    def test_older_enable_result_does_not_restore_newer_disable_intent(self):
        self.window.update_snapshot(stopped_snapshot(simulated=False))
        self.window.arm_checkbox.setChecked(True)
        self.window.arm_checkbox.setChecked(False)
        self.window.update_snapshot(dict(self.window._snapshot, control_enabled=False))
        self.window.update_snapshot(dict(self.window._snapshot, control_enabled=True))
        self.window.action_result({"name": "enable_control", "ok": True, "value": True})
        self.assertFalse(self.window.arm_checkbox.isChecked())
        self.assertFalse(self.window.run_button.isEnabled())
        self.confirm_authorization("enable_control", False)
        self.assertFalse(self.window.arm_checkbox.isChecked())

    def test_backend_true_snapshot_never_creates_operator_authorization_intent(self):
        snapshot = stopped_snapshot(simulated=False, control_enabled=True, service_enabled=True)
        self.window.update_snapshot(snapshot)
        self.assertFalse(self.window.arm_checkbox.isChecked())
        self.assertFalse(self.window.service_checkbox.isChecked())
        self.assertFalse(self.window.run_button.isEnabled())
        self.assertFalse(self.window.service_widgets["max_current_a"][2].isEnabled())
        self.assertTrue(self.window.stop_button.isEnabled())
        self.assertEqual(self.actions, [])

    def test_run_checks_source_protection_softstart_firmware_and_current_readbacks(self):
        base = stopped_snapshot()
        cases = [
            ({"qswitch": 0}, "Q-switch"),
            ({"qswitch": 1}, "Q-switch"),
            ({"firmware_tuple": None}, "firmware"),
            ({"faults": None}, "fault status"),
            ({"unknown_status_bits": {7: 4}}, "unknown status"),
            ({"max_current_a": 0}, "current"),
            ({"current_set_a": 26}, "current"),
            ({"current_set_a": float("nan")}, "current"),
            ({"service": dict(base["service"], underfrequency_enabled=False)}, "underfrequency"),
            ({"service": dict(base["service"], soft_start_enabled=None)}, "soft start"),
        ]
        for updates, reason in cases:
            with self.subTest(reason=reason, updates=updates):
                self.window.update_snapshot(dict(base, **updates))
                self.assertFalse(self.window.run_button.isEnabled())
                self.assertIn(reason.lower(), self.window.control_hint.text().lower())
                self.window._begin_hold()
                self.assertFalse(self.window._hold_active)
                self.assertTrue(self.window.stop_button.isEnabled())
        self.assertEqual(self.actions, [])
        self.window.update_snapshot(base)
        self.assertTrue(self.window.run_button.isEnabled())

    def test_elapsed_stale_status_hides_live_values_and_cancels_hold_without_waiting(self):
        with patch("empower.gui.time.monotonic") as clock:
            clock.return_value = 100.0
            snapshot = stopped_snapshot(status_age_s=0.0, status_fresh=True)
            self.window.update_snapshot(snapshot)
            self.press_run()
            self.assertTrue(self.window._hold_active)
            clock.return_value = 103.1
            self.window._check_snapshot_age()
            self.assertFalse(self.window._hold_active)
            self.assertFalse(self.window.run_button.isEnabled())
            self.assertFalse(self.window.apply_current_button.isEnabled())
            self.assertTrue(self.window.stop_button.isEnabled())
            self.assertEqual(self.window.communication_label.text(), "COMM  STALE")
            self.assertEqual(self.window.current_label.text(), "--")
            self.assertEqual(self.window.emission_label.text(), "--")
            self.window._tick_hold()
            self.assertEqual(self.actions, [])
            self.window.update_snapshot(snapshot)
            self.assertTrue(self.window.run_button.isEnabled())
            self.assertFalse(self.window._hold_active)
            self.release_run()

    def test_stop_result_confirms_status_text_and_preserves_failure_message(self):
        self.window.update_snapshot(stopped_snapshot())
        self.window.stop_button.click()
        self.assertIn("awaiting controller confirmation", self.window.statusBar().currentMessage())
        self.window.update_snapshot(stopped_snapshot())
        self.window.action_result({"name": "stop", "ok": True})
        self.assertEqual(self.window.statusBar().currentMessage(), "STOP confirmed by controller")
        self.window.update_snapshot(stopped_snapshot(state="FAULT", faults=["Keyswitch"]))
        self.window.action_result({"name": "stop", "ok": True})
        self.assertIn("active fault remains", self.window.statusBar().currentMessage())
        failure = "Output state is unknown. Use the physical keyswitch/interlock."
        self.window.statusBar().showMessage(failure)
        self.window.action_result({"name": "stop", "ok": False})
        self.assertEqual(self.window.statusBar().currentMessage(), failure)
        self.window.update_snapshot(stopped_snapshot(comm_ok=False))
        self.window.action_result({"name": "stop", "ok": True})
        self.assertEqual(self.window.statusBar().currentMessage(), failure)

    def test_stop_revokes_pending_enable_intents_without_disarming_confirmed_control(self):
        self.window.update_snapshot(stopped_snapshot(simulated=False))
        self.window.arm_checkbox.setChecked(True)
        self.window.stop_button.click()
        self.assertFalse(self.window.arm_checkbox.isChecked())
        self.assertEqual(self.actions[-2:], [("enable_control", False), ("stop", None)])
        self.window.update_snapshot(dict(self.window._snapshot, control_enabled=True))
        self.window.action_result({"name": "enable_control", "value": True, "ok": True})
        self.assertFalse(self.window.arm_checkbox.isChecked())
        self.assertFalse(self.window.apply_current_button.isEnabled())
        self.confirm_authorization("enable_control", False)
        self.assertIsNone(self.window._authorization_pending["enable_control"])

        self.enable_control()
        self.window.service_checkbox.setChecked(True)
        self.window.stop_button.click()
        self.assertTrue(self.window.arm_checkbox.isChecked())
        self.assertFalse(self.window.service_checkbox.isChecked())
        self.assertEqual(self.actions[-2:], [("enable_service", False), ("stop", None)])
        self.window.update_snapshot(dict(self.window._snapshot, service_enabled=True))
        self.window.action_result({"name": "enable_service", "value": True, "ok": True})
        self.assertFalse(self.window.service_checkbox.isChecked())
        self.confirm_authorization("enable_service", False)
        self.assertIsNone(self.window._authorization_pending["enable_service"])


if __name__ == "__main__":
    unittest.main()
