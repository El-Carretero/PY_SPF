"""Logging failures must release every file handle and never leak numeric codes."""
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from empower.sessionlog import SessionLog, wire_text


class SessionLogResources(unittest.TestCase):
    def test_failed_second_open_closes_first_handle(self):
        events = io.StringIO()
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(Path, "open", side_effect=[events, OSError("disk full")]):
                with self.assertRaisesRegex(OSError, "disk full"):
                    SessionLog(directory)
        self.assertTrue(events.closed)

    def test_failed_header_write_closes_both_handles(self):
        class FullDisk(io.StringIO):
            def write(self, data):
                raise OSError("disk full")
        events, readings = io.StringIO(), FullDisk()
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(Path, "open", side_effect=[events, readings]):
                with self.assertRaisesRegex(OSError, "disk full"):
                    SessionLog(directory)
        self.assertTrue(events.closed)
        self.assertTrue(readings.closed)

    def test_both_handles_close_even_if_first_flush_raises(self):
        class BadClose(io.StringIO):
            def close(self):
                super().close()
                raise OSError("flush failed")
        log = SessionLog.__new__(SessionLog)
        log.events, log.readings = BadClose(), io.StringIO()
        with self.assertRaisesRegex(OSError, "flush failed"):
            log.close()
        self.assertTrue(log.events.closed)
        self.assertTrue(log.readings.closed)

    def test_nonzero_numeric_field_and_its_checksum_remain_redacted(self):
        raw = bytes.fromhex("10 02 00 00 17 50 02 12 34 00 fa 00 02 58 00 00 30 d4 05 46 04 9c 58")
        redacted = wire_text(raw).split()
        self.assertEqual(redacted[7:9], ["**", "**"])
        self.assertEqual(redacted[-1], "**")
        self.assertEqual(redacted[9:22], raw.hex(" ").split()[9:22])


if __name__ == "__main__":
    unittest.main()
