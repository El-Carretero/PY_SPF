"""Independent literal wire cases: the demo must not teach the old opcode bug."""
import unittest
from empower.simulator import SimulatedTransport


class SimulatorSemantics(unittest.TestCase):
    def test_reset_ack_is_not_softstart_and_does_not_enable_protection(self):
        peer = SimulatedTransport()
        peer.underfrequency = False
        peer.softstart = False
        reply = peer.exchange(bytes.fromhex("10 02 00 00 08 09 02 25"), (0x18,))
        self.assertEqual(reply.opcode, 0x18)
        self.assertFalse(peer.underfrequency)
        self.assertFalse(peer.softstart)

    def test_protection_change_does_not_stop_a_running_demo(self):
        peer = SimulatedTransport()
        peer.state = 0
        reply = peer.exchange(bytes.fromhex("10 02 00 00 09 53 02 00 70"), (0x73,))
        self.assertEqual(reply.raw[9], 0)
        self.assertEqual(peer.state, 0)

    def test_explicit_original_softstart_configuration_returns_69(self):
        peer = SimulatedTransport()
        peer.softstart = False
        reply = peer.exchange(bytes.fromhex("10 02 00 00 0b 49 02 01 00 01 6a"), (0x69,))
        self.assertEqual(reply.raw[7], 1)
        self.assertEqual(reply.raw[9], 1)

    def test_reset_does_not_clear_continuing_physical_fault(self):
        peer = SimulatedTransport()
        peer.inject_fault("key")
        peer.exchange(bytes.fromhex("10 02 00 00 08 09 02 25"), (0x18,))
        reply = peer.exchange(bytes.fromhex("10 02 00 00 08 02 02 1e"), (0x12,))
        self.assertEqual(reply.raw[28], 2)
        self.assertTrue(reply.raw[8] & 0x20)


if __name__ == "__main__":
    unittest.main()
