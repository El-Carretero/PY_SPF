"""Regression vectors from the user's 2026-09-23 serial capture.

The five CAPTURED_* frames below are literal received bytes, independently of
the simulator. No host name, account information, or log metadata is retained.
The initial capture ends after the historical opcode09 request and STOP; LBO, optical power,
softstart-setting acknowledgement and healthy/run states below are SYNTHETIC
test extensions, not evidence that this instrument implements those replies.
"""
import unittest

from empower.device import Device
from empower.framing import Frame, FrameBuffer, ProtocolError


CAPTURED_FIRMWARE = bytes.fromhex("10 02 00 00 0C 62 00 48 43 01 02 0E")
CAPTURED_STATUS = bytes.fromhex(
    "10 02 00 00 1E 12 00 00 20 00 00 64 00 28 00 00 "
    "89 34 00 65 00 00 00 02 01 47 C9 64 02 89"
)
CAPTURED_QSWITCH = bytes.fromhex("10 02 00 00 09 75 00 02 92")
CAPTURED_SERVICE = bytes.fromhex(
    "10 02 00 00 15 70 00 00 FA 00 02 58 00 00 30 D4 05 46 04 9C DA"
)
CAPTURED_RESET_REPLY = bytes.fromhex(
    "10 02 00 00 0C 18 00 00 20 00 02 58"
)


def synthetic_with_checksum(raw):
    """Append an additive checksum to a synthetic response body."""
    return bytes(raw) + bytes((sum(raw) & 255,))


# These two replies were NOT present in the capture.
SYNTHETIC_LBO = synthetic_with_checksum(
    bytes.fromhex("10 02 00 00 0E 1A 00 00 00 00 00 05 14")
)
SYNTHETIC_POWER = synthetic_with_checksum(
    bytes.fromhex("10 02 00 00 0A 72 00 00 00")
)
SYNTHETIC_SOFTSTART_CONFIRMED = synthetic_with_checksum(
    bytes.fromhex("10 02 00 00 0B 69 00 01 00 01")
)


def synthetic_healthy_status(state=1):
    """Clear capture faults and enable protection only within this fake peer."""
    raw = bytearray(CAPTURED_STATUS[:-1])
    raw[7:10] = b"\x00\x00\x80"
    raw[28] = state
    return synthetic_with_checksum(raw)


class CaptureReplayTransport:
    """Stateful fake serial peer; not the project's simulated instrument.

    Only five response types are sourced from the capture. Further polling
    repeats those vectors, with explicitly synthetic replies for unobserved
    transactions. No actual port is opened and no hardware command is sent.
    """
    def __init__(self, power_result="synthetic_success"):
        self.tx = []
        self.rx = []
        self.expected = []
        self.status = CAPTURED_STATUS
        self.power_result = power_result
        self.core_status_timeout = False
        self.reset_reply = CAPTURED_RESET_REPLY

    def send(self, raw):
        self.tx.append(bytes(raw))
        if raw[5] == 0x08:
            # SYNTHETIC response state for tests exercising explicit RUN/STOP.
            self.status = synthetic_healthy_status(3 if raw[7] == 0 else 1)

    def exchange(self, raw, expected):
        self.send(raw)
        op = raw[5]
        self.expected.append((op, set(expected)))
        if op == 0x02 and self.core_status_timeout:
            raise TimeoutError("Synthetic loss of required status response")
        if op == 0x52 and self.power_result == "timeout":
            raise TimeoutError("Synthetic optional power query timeout")
        replies = {
            0x42: CAPTURED_FIRMWARE,
            0x02: self.status,
            0x55: CAPTURED_QSWITCH,
            0x50: CAPTURED_SERVICE,
            0x09: self.reset_reply,
            0x0B: SYNTHETIC_LBO,
            0x52: (CAPTURED_RESET_REPLY
                   if self.power_result == "unrecognized_reply"
                   else SYNTHETIC_POWER),
            0x49: SYNTHETIC_SOFTSTART_CONFIRMED,
        }
        if op not in replies:
            raise AssertionError(f"Unexpected command in capture replay: 0x{op:02X}")
        reply = replies[op]
        self.rx.append(reply)
        # Match the real exchange contract. The optional path must explicitly
        # admit opaque0x18; returning it as an expected0x69 would mask the bug.
        if reply[5] not in expected:
            raise TimeoutError(f"Received0x{reply[5]:02X}, expected {set(expected)}")
        return Frame(reply)

    def writes(self, opcode):
        return [raw for raw in self.tx if raw[5] == opcode]

    def close(self):
        pass


class CapturedFirmwareRegression(unittest.TestCase):
    def initialize(self, power_result="synthetic_success"):
        transport = CaptureReplayTransport(power_result)
        device = Device(transport, simulated=False)
        device.initialize()
        return device, transport

    def test_literal_capture_frames_have_additive_checksum_and_fragment_cleanly(self):
        frames = (CAPTURED_FIRMWARE, CAPTURED_STATUS, CAPTURED_QSWITCH,
                  CAPTURED_SERVICE, CAPTURED_RESET_REPLY)
        for raw in frames:
            with self.subTest(opcode=raw[5]):
                self.assertEqual(len(raw), raw[4])
                self.assertEqual(sum(raw[:-1]) & 255, raw[-1])
        # Match actual status READ segmentation (1 + 10 + 1 + 18 bytes).
        decoder = FrameBuffer()
        self.assertEqual(decoder.feed(CAPTURED_STATUS[:1]), [])
        self.assertEqual(decoder.feed(CAPTURED_STATUS[1:11]), [])
        self.assertEqual(decoder.feed(CAPTURED_STATUS[11:12]), [])
        self.assertEqual(decoder.feed(CAPTURED_STATUS[12:]), [Frame(CAPTURED_STATUS)])

    def test_capture_initialization_does_not_send_reset_or_configuration(self):
        device, transport = self.initialize()
        self.assertEqual([raw[5] for raw in transport.tx[:4]], [0x42, 0x02, 0x55, 0x50])
        self.assertEqual(transport.rx[:4], [CAPTURED_FIRMWARE, CAPTURED_STATUS,
                                         CAPTURED_QSWITCH, CAPTURED_SERVICE])
        self.assertFalse(transport.writes(0x09))
        self.assertFalse(transport.writes(0x53))
        snapshot = device.snapshot()
        self.assertTrue(snapshot["connected"])
        self.assertTrue(snapshot["comm_ok"])
        self.assertFalse(device.enabled)
        self.assertEqual(snapshot["firmware_tuple"], (1, 2))
        self.assertEqual(snapshot["state"], "FAULT")
        self.assertIn("Key switch", snapshot["faults"])
        self.assertEqual(snapshot["max_current_a"], 25)
        self.assertFalse(snapshot["service"].get("soft_start_enabled"))
        self.assertFalse(transport.writes(0x49), "Connection must not configure softstart")
        self.assertFalse(transport.writes(0x08), "Connection must not RUN or STOP a healthy link")
        self.assertTrue(all(raw[7:9] == b"\x00\x00" for raw in transport.writes(0x50)))

    def test_unavailable_optional_probes_are_not_repeated_and_status_continues(self):
        for result in ("unrecognized_reply", "timeout"):
            with self.subTest(power_result=result):
                device, transport = self.initialize(result)
                status_count = len(transport.writes(0x02))
                for _ in range(3):
                    device.poll()
                device.action("refresh")
                self.assertTrue(device.snapshot()["comm_ok"])
                self.assertTrue(device.snapshot()["connected"])
                self.assertIsNone(device.snapshot().get("power_w"))
                self.assertGreater(len(transport.writes(0x02)), status_count)
                self.assertEqual(len(transport.writes(0x09)), 0)
                self.assertEqual(len(transport.writes(0x52)), 1)
                self.assertFalse(transport.writes(0x49))

    def test_optional_power_loss_clears_previously_displayed_value(self):
        device, transport = self.initialize()
        self.assertEqual(device.snapshot()["power_w"], 0.0)
        transport.power_result = "timeout"
        device.poll()
        self.assertTrue(device.snapshot()["comm_ok"])
        self.assertIsNone(device.snapshot().get("power_w"))
        power_queries = len(transport.writes(0x52))
        device.poll()
        self.assertEqual(len(transport.writes(0x52)), power_queries)

    def test_required_status_timeout_still_propagates(self):
        device, transport = self.initialize("timeout")
        transport.core_status_timeout = True
        with self.assertRaises(TimeoutError):
            device.poll()

    def test_unknown_softstart_blocks_run_without_breaking_connection(self):
        device, transport = self.initialize()
        transport.status = synthetic_healthy_status()
        device.poll()
        device.action("enable_control", True)
        with self.assertRaisesRegex(ValueError, r"(?i)soft.?start"):
            device.action("run")
        self.assertTrue(device.snapshot()["connected"])
        self.assertTrue(device.snapshot()["comm_ok"])
        self.assertEqual(len(transport.writes(0x09)), 0)
        self.assertFalse(transport.writes(0x49))
        self.assertFalse([raw for raw in transport.writes(0x08) if raw[7] == 0])

    def test_explicit_confirmed_softstart_allows_run_without_broken_reprobe(self):
        device, transport = self.initialize()
        transport.status = synthetic_healthy_status()
        device.poll()
        device.action("enable_control", True)
        device.action("enable_service", True)
        device.action("service_set", {"key": "soft_start_enabled", "value": True})
        self.assertEqual(len(transport.writes(0x49)), 1)
        self.assertTrue(device.snapshot()["service"]["soft_start_enabled"])
        device.action("run")
        self.assertEqual(device.snapshot()["state"], "COUNTDOWN")
        self.assertEqual(len(transport.writes(0x09)), 0)
        self.assertEqual(len([raw for raw in transport.writes(0x08) if raw[7] == 0]), 1)

    def test_explicit_reset_accepts_opaque18_but_preserves_reported_fault(self):
        device, transport = self.initialize()
        device.action("enable_control", True)
        device.action("reset")
        self.assertEqual(transport.writes(0x09), [bytes.fromhex("10 02 00 00 08 09 02 25")])
        self.assertFalse(transport.writes(0x53))
        self.assertFalse(transport.writes(0x49))
        self.assertTrue(device.snapshot()["comm_ok"])
        self.assertEqual(device.snapshot()["state"], "FAULT")
        self.assertEqual(device.snapshot()["faults"], ["Key switch"])
        self.assertIsNone(device.snapshot()["service"]["soft_start_enabled"])

    def test_corrupt_reset_ack_does_not_get_accepted_as_opaque_success(self):
        device, transport = self.initialize()
        device.action("enable_control", True)
        transport.reset_reply = CAPTURED_RESET_REPLY[:-1] + bytes([CAPTURED_RESET_REPLY[-1] ^ 1])
        with self.assertRaises(ProtocolError):
            device.action("reset")
        self.assertEqual(len(transport.writes(0x09)), 1)
        self.assertFalse(transport.writes(0x53))

    def test_corrupt_status_checksum_rejected_after_captured_firmware_profile(self):
        transport = CaptureReplayTransport()
        corrupt = bytearray(CAPTURED_STATUS)
        corrupt[22] ^= 1  # Header, length and opcode remain plausible.
        transport.status = bytes(corrupt)
        device = Device(transport, simulated=False)
        with self.assertRaises(ProtocolError):
            device.initialize()
        self.assertEqual(transport.rx[0], CAPTURED_FIRMWARE)
        self.assertEqual(transport.rx[1], bytes(corrupt))
        self.assertFalse(device.snapshot()["comm_ok"])
        self.assertFalse(transport.writes(0x08))

    def test_checksum_byte_cannot_substitute_for_missing_status_state(self):
        transport = CaptureReplayTransport()
        # SYNTHETIC malformed packet: remove state but regenerate a valid
        # checksum and header length. It must not look like a legacy29-byte
        # status once this session has learned the checksummed RX profile.
        truncated = bytearray(CAPTURED_STATUS[:-2])
        truncated[4] = len(truncated) + 1
        transport.status = synthetic_with_checksum(truncated)
        self.assertEqual(len(transport.status), 29)
        device = Device(transport, simulated=False)
        with self.assertRaises(ProtocolError):
            device.initialize()
        self.assertFalse(device.snapshot()["comm_ok"])


if __name__ == "__main__":
    unittest.main()
