"""Entry point for Windows PyInstaller builds."""
from empower.app import main

if __name__ == "__main__":
    main()
