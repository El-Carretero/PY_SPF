@echo off
call "%~dp0start_windows.cmd" --demo %*
exit /b %ERRORLEVEL%
