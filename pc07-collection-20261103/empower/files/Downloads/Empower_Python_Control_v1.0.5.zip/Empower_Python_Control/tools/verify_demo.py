"""Exercise the real Qt bridge/worker against SIMULATOR only, with a real hold.

Run from the extracted project root:
    python tools/verify_demo.py --output /path/to/demo-verification
No serial port or physical instrument is opened. Takes about 10 seconds.
"""
import argparse
import json
import os
from pathlib import Path
import sys
import time
from unittest.mock import patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QMessageBox
from empower.app import Bridge
from empower.gui import MainWindow
from empower import __version__


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    existing_logs = set((args.output / "logs").glob("*_session.jsonl"))
    app = QApplication.instance() or QApplication([])
    window = MainWindow()
    bridge = Bridge(window, args.output / "logs")
    events = []
    bridge.event.connect(lambda kind, value: events.append((kind, value)))
    window.show()
    window.activateWindow()

    def wait_for(predicate, timeout=5.0):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            app.processEvents()
            if predicate():
                return
            time.sleep(0.01)
        raise AssertionError("Demo integration condition did not become true")

    started = time.monotonic()
    report = {"version": __version__, "synthetic_only": True, "checks": []}
    try:
        bridge.controller.submit("connect", "SIMULATOR")
        wait_for(lambda: window._snapshot.get("state") == "STOP")
        assert not window.run_button.isEnabled()
        assert window._snapshot["service"]["soft_start_enabled"] is None
        report["checks"].append("Connection performs no automatic RESET or softstart write")

        window.service_checkbox.setChecked(True)
        wait_for(lambda: window.soft_start_button.isEnabled())
        with patch.object(QMessageBox, "question", return_value=QMessageBox.StandardButton.Yes):
            window._apply_soft_start()
        wait_for(lambda: window._snapshot["service"].get("soft_start_enabled") is True)
        report["checks"].append("Explicit softstart configuration confirms 49/69 and enables normal RUN")

        window.current_input.setValue(12.0)
        window._apply_current()
        wait_for(lambda: window._snapshot.get("current_set_a") == 12.0)
        report["checks"].append("Current Apply traverses GUI, worker, protocol and readback")

        window.tabs.setCurrentIndex(0)
        app.processEvents()
        assert window.run_button.isEnabled()
        hold_start = time.monotonic()
        QTest.mousePress(window.run_button, Qt.MouseButton.LeftButton)
        wait_for(lambda: window._snapshot.get("state") == "COUNTDOWN", timeout=7.0)
        held = time.monotonic() - hold_start
        QTest.mouseRelease(window.run_button, Qt.MouseButton.LeftButton)
        assert held >= 5.0, held
        wait_for(lambda: window._snapshot.get("state") == "RUN", timeout=5.0)
        report["real_hold_seconds"] = round(held, 3)
        report["checks"].append("Actual five-second GUI hold, COUNTDOWN and synthetic RUN")
        assert window._snapshot["emission"] is True
        window.grab().save(str(args.output / "main_synthetic_run.png"))

        window.stop_button.click()
        wait_for(lambda: window._snapshot.get("state") == "STOP")
        assert window._snapshot["emission"] is False
        wait_for(lambda: "STOP confirmed" in window.statusBar().currentMessage())
        # The old RUN power must not be presented as a post-STOP measurement.
        assert window._snapshot.get("power_w") in (None, 0.0)
        report["checks"].append("STOP returns confirmed stopped state")
        service_index = next(i for i in range(window.tabs.count())
                             if window.tabs.tabText(i) == "Service")
        window.tabs.setCurrentIndex(service_index)
        app.processEvents()
        window.grab().save(str(args.output / "service_synthetic_stopped.png"))

        bridge.close()
        # Deliberately follow shutdown with STOP: this used to erase shutdown.
        bridge.controller.submit("stop")
        # Thread exit can precede delivery of its queued Qt "ended" signal.
        wait_for(lambda: any(kind == "ended" for kind, _ in events))
        bridge.controller.thread.join(1.0)
        assert not bridge.controller.thread.is_alive()
        assert bridge.controller.device is None
        assert ("ended", True) in events
        report["checks"].append("STOP after shutdown does not cancel worker termination")

        tx = []
        session_logs = set((args.output / "logs").glob("*_session.jsonl")) - existing_logs
        assert len(session_logs) == 1
        for path in session_logs:
            for line in path.read_text().splitlines():
                item = json.loads(line)
                if item.get("kind") == "wire" and item.get("direction") == "TX":
                    tx.append(bytes.fromhex(item["hex"]))
        assert tx
        assert not any(p[5] in (0x09, 0x53) for p in tx)
        assert sum(p[5] == 0x49 for p in tx) == 1
        assert sum(p[5] == 0x08 and p[7] == 0 for p in tx) == 1
        assert sum(p[5] == 0x01 for p in tx) == 1
        errors = [str(value) for kind, value in events if kind in ("error", "warning")]
        assert not errors, errors
        report["tx_count"] = len(tx)
        report["errors"] = errors
        report["elapsed_seconds"] = round(time.monotonic() - started, 3)
        report["passed"] = True
        (args.output / "integration_result.json").write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps(report, indent=2))
    finally:
        if bridge.controller.thread.is_alive():
            bridge.controller.submit("shutdown")
            bridge.controller.thread.join(5.0)
        window.allow_close = True
        window.close()
        app.processEvents()


if __name__ == "__main__":
    main()
