# Original-to-Python feature map — v1.0.5

This document describes the modern **Empower Python Control 1.0.5**, compared
with the supplied Empower GUI 3.02.00. It is an independent implementation,
with modern controls and explicit Apply actions; it does not reproduce the
original screen pixel for pixel. The separate original-GUI reconstruction is
not this application.

| Function | Modern implementation | Intentional difference / limit |
|---|---|---|
| Main interface and Apply | RUN/STOP remain visible; settings use explicit Apply actions and separate requested values from readbacks | Modern tabs and layout; editing a value alone does not send it to the controller |
| Session control / ARM | Physical-device sessions require explicit control enable; service editing has a separate enable checkbox | Reconnecting does not restore write authorization or replay RUN/settings. The simulator can enable demonstration control automatically |
| RUN and emission | Hold RUN for 5 seconds, then recheck state, source and prerequisites before one RUN request; require COUNTDOWN/RUN readback | Five seconds follows the manual; the supplied EXE counts about 3 seconds. The emission indicator follows controller state and is not an optical measurement |
| STOP, disconnect and exit | STOP bypasses the control-enable gate; queued writes are discarded. STOP requests require a subsequent STOP/FAULT state; disconnect/exit attempt the same orderly stop | Serial operations are bounded but STOP cannot interrupt a transaction already in progress. This is not a physical emergency stop; a failed confirmation leaves output unknown |
| Port selection | Enumerated and editable serial ports, 19200 baud, 8N1, no flow control | No COM1–COM9 ceiling or XP/CVI runtime requirement |
| Current setting | 0.1 A increments, bounded by the fresh device maximum; require valid status with no active or unknown fault bits | Combined `0x01` writes preserve fresh raw frequency and pulse-width words; no arbitrary fallback values. A valid, bounded current-only ACK mismatch warns and retains monitoring; it does not claim success or retry |
| Q-switch source | INTERNAL=2, EXTERNAL=3; service HOLD OFF=1; changes require confirmed STOP and source readback | Raw source 0 is retained and never inferred to be EXTERNAL from the previous selection. Source 0 is not offered as a normal control and cannot satisfy normal RUN prerequisites |
| Output power | Main output power is labelled W and decoded as received word /100 | Unavailable power stays unknown. Simulator power is demonstration data, not calibration |
| Information and faults | Firmware, operating hours, raw status, 15 decoded device fault bits, unknown status bits, local LBO fault and log path | Unknown bits are retained without invented meanings; status freshness gates controls |
| Fault RESET | Explicit `0x09`, followed by a fresh status read; stopped or faulted state required | Opaque reply `0x18` alone proves neither fault clearance nor soft-start state. RESET does not configure underfrequency protection and is never used as an automatic query |
| Underfrequency protection | Read from status; explicit stopped-state service setting uses `0x53`, followed by response/status verification | Separate from fault RESET. Normal RUN requires this protection to be confirmed enabled |
| Soft start | Initially unconfirmed; explicit **Apply original soft start** sends `0x49` and requires valid `0x69` confirming enabled and 0.5 A/s | Original startup configures it automatically. Modern connection, refresh and RUN preparation do not. No independent nonmutating query is established; opaque `0x18` is not accepted as soft-start confirmation. Normal RUN remains blocked until confirmed |
| Service values | Maximum current, MaxPower, slope, intercept and LBO thresholds have readbacks and explicit stopped-state writes | Read fresh raw service words, replace the requested field only, preserve the other words, keep reserved transmit byte 11 at zero, then verify both reply and a new service read |
| Service numeric field | The original unlabelled string/`atoi` field is exposed as an optional integer; blank sends zero | Its authorization meaning is unproven. Blank/zero does not guarantee acceptance. A target-only mismatch warns while monitoring continues; changed unrelated fields or invalid responses are failures. No write is retried |
| Frequency / pulse width | Stopped-state service controls, firmware-specific frequency scaling and confirmed readback | Modern validation is stricter than the original UI; see the range table below. Current-only changes preserve existing raw values even when outside the editable range |
| LBO stability | Enabled by default; after 180 measured samples, compare the 180-sample mean with the latest 10-sample mean; absolute difference greater than 1°C requests one STOP and latches a local fault | Samples are at least 1 second apart. Warm-up uses actual measurements instead of the original zero-filled buffers; no claim of 180 continuous seconds. This host monitor does not replace firmware thermal interlocks |
| Frame validation | Additive TX checksum; framed responses and required fields checked. A 12-byte checksummed firmware response selects checksum validation for that session | Supplied FW1.2 captures support this mode. An 11-byte legacy firmware layout is labelled checksum-unconfirmed; one response format is not assumed for every firmware revision |
| Communication failure | State/emission become unknown, session control is disabled, queued changes are discarded, one best-effort STOP is attempted, and the port closes | Manual reconnect only; no automatic write retry or RUN replay. A failed link cannot establish that optical output stopped |
| Recording / simulator | Session JSONL TX/RX/events, readings CSV, GUI text export; simulator uses the same driver/parser | Nonzero optional service numeric fields and their checksums are redacted, and the input is not persisted. The simulator is a software model, not reference firmware or a real-device transcript |

## Ranges and physical units

These editor bounds are not a replacement for the specific laser's factory
performance sheet or authorized service procedure.

| Value | v1.0.5 behavior | Basis / limitation |
|---|---|---|
| Operating current | 0 to the device-reported maximum, in 0.1 A steps | The manual specifies 0.1 A adjustment and the device-specific maximum; it does not establish one universal maximum for all units |
| Internal frequency | Enter factory nominal in 0.5–10 kHz; requested value must be within both nominal ±20% and 0.5–10 kHz. Resolution is 0.1 kHz for firmware `(0,1)`, otherwise 0.01 kHz | Manual Table 3-1 and pages 6-2/6-6 give the 500 Hz–10 kHz and ±20% limits for **external** triggering. Applying that envelope to internal service edits is a modern software policy, not proof of manufacturer approval. The original UI's 5 kHz display range is not a demonstrated hardware ceiling |
| Internal pulse width | 125–10000 ns, multiples of 125 ns | Based on the original service control and serializer. The manual's external TTL pulse-width requirement is a different signal and does not establish this internal parameter's allowed range |
| Service editor bounds | Max current 0–40 A; MaxPower 0–500 mW; slope 0–100 mW/V; intercept 0–5 mW; each LBO threshold 5–200°C | Original UI-derived limits, enforced by the modern implementation. Whole-number input is required because original service serialization casts before scaling. LBO low must be below high; reducing max current below the current setpoint is rejected |
| MaxPower versus output power | Retain original service mW/mW/V labels and main output W label with their respective conversions | The physical meaning, calibration and firmware action of MaxPower remain unverified. It is not established as an optical-output cutoff or a current-related protection threshold, and the host does not invent either behavior |

## Evidence and remaining limits

The supplied EXE/UIR, the manual, independent literal packet vectors, and the
user's real FW1.2 capture files informed this release. The capture review
establishes observed responses, not universal firmware semantics or successful
operation of every control. Some regression cases, including source 3 followed
by raw source 0, are synthetic. See [protocol review](REVIEW_PROTOCOL_1_0_5.md)
and [capture review](REVIEW_CAPTURE_1_0_5.md) for the evidence and its limits.

The original sends a blank-field `0x50` startup packet to obtain service limits.
The modern implementation uses that same pattern, including its initial
9°C/5°C fields. Original host usage and supplied captures support interpreting
it as a read, but no independently proven nonmutating service-query opcode has
been recovered. A different firmware could interpret those fields as a write.
Therefore, a connection with session control disabled is not a proof that
every startup packet is universally read-only. See the exact packet in the
protocol review before equipment acceptance.

This release has **not been run on Windows or connected to physical Empower
hardware** during development. Supplied real-device captures were reviewed and
used for regression validation; that does not constitute a live hardware test
of v1.0.5. The original GUI was not dynamically compared under XP. USB-RS232
behavior, hardware timing, physical emission and power-meter agreement require
equipment acceptance. No vendor firmware source is available.

See [VALIDATION.md](VALIDATION.md) and [TEST_RESULTS.txt](TEST_RESULTS.txt) for
the current automated results and validation scope.

## Code layout

| Module | Responsibility |
|---|---|
| `framing.py`, `commands.py`, `responses.py` | Packet encoding, validation and parsing |
| `transport.py` | Bounded serial I/O and fragmented-response assembly |
| `device.py` | Readbacks, limits, write checks and local LBO monitor |
| `controller.py` | One serial worker, polling, queued actions and lifecycle |
| `gui.py`, `app.py` | Qt GUI, event bridge and launcher |
| `simulator.py` | Software-only protocol emulator |
| `sessionlog.py` | Wire, event and CSV session records |

Serial work uses one Python worker thread and Qt signals; polling does not run
on the GUI thread.
