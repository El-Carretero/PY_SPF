# Empower GUI 3.02.00 protocol — v1.0.5 review

This is the current interpretation. Earlier release reports are historical; the old RESET/softstart assignments were incorrect. See `REVIEW_PROTOCOL_1_0_5.md` for callback evidence and `REVIEW_CAPTURE_1_0_5.md` for live-capture scope.

Source: supplied `EMPOWER.EXE.1.189E4EEE87974F3BA736D3B6513C412A`, PE32 compiled 2010-04-06; the full Windows/CVI program was not run. Selected original x86 serializers and handlers were executed with bounded import stubs during the comparison; this is not firmware or physical-device execution. All addresses below are image virtual addresses (image base 0x400000). Cross-reference UI labels comes from independent inspection of supplied `.UIR`.

## Confirmed serial and framing

- Port setup function `0x4279AD`: baud = 0x4B00 = **19200**, parity 0, eight data bits, one stop bit. Input queue 612, output queue 512 bytes. Calls `SetXMode(port,0)` and `SetCTSMode(port,0)`, therefore neither software nor CTS flow control. `SetComTime(port,1.0)` sets a one-second byte API timeout. Original offers COM1–COM9; this limit need not be preserved in Python.
- Packet constructor `0x428805–0x428FD3`: transmit prefix `[0x10,0x02,0,0,total_length,opcode,0x02]` followed by opcode-specific fields and final checksum.
- Sender `0x428224`: reads byte 4 as byte count and passes the frame unchanged to `ComWrt` at `0x42830A`. No escaping or CR/LF terminator is inserted.
- Checksum `0x428780–0x428803`: final byte is `sum(frame[:-1]) & 0xff`. Additive modulo 256, not complement, CRC, or XOR.
- Header receiver `0x42A132`: scans for `0x10 0x02`, accepts two subsequent header bytes, reads byte4 total length. Body receiver `0x42A380` reads the remaining `length-5` bytes.
- **RX framing is selected from firmware response length.** The original reader accepts 29-byte status with state at28 and does not validate the TX-style checksum. Actual FW1.2 captures use 12-byte firmware and 30-byte status responses with additive checksums. Python supports the established 11-byte firmware/29-byte status legacy shape and captured checksummed shape; checked sessions enforce complete payload length and checksum. Other firmware formats remain unverified.

## Transmit opcode table

`f[i]` means zero-based offset from the first 0x10. All templates have byte6=0x02.

| Opcode | Length | Meaning | Evidence |
|---|---:|---|---|
| 0x02 | 8 | Read status | 0x42FB98 template, startup 0x427B4B, wrapper0x42C60D |
| 0x01 | 17 | Set operating settings (current + Q-switch frequency + width together) | template0x42FBBC, serializer0x429B3B, setup callback0x42C9EB |
| 0x08 | 9 | Diode run/stop; **f7=0 ON, f7=1 OFF** | template0x42FB10; serializer0x429F8D; STOP callback0x42CA39 sets flag0; RUN callback0x42E78F sets flag1; f7=1-flag |
| 0x52 | 8 | Read optical power | template0x42FB30; response0x72 decoder0x42A82E |
| 0x51 | 9 | Set Q-switch source, f7: 0 CW RF OFF (factory UI only), 1 HOLD OFF, 2 INTERNAL, 3 EXTERNAL | template0x42FB54; serializer0x429FC2; callback0x42CA12 |
| 0x55 | 8 | Read Q-switch source | template0x42FB78, wrapper0x42C652, response0x75 |
| 0x50 | 23 | Service settings transaction; blank numeric field becomes0 during startup read | templates0x42FC24/0x42FCB0, serializer0x4292E3; startup0x429235 clears the unlabelled field then sends |
| 0x49 | 11 | Configure softstart, f7=1 f8=0 f9=1 in original | template0x42FC44; serializer0x42A068; startup wrapper0x42C738 |
| 0x53 | 9 | Set underfrequency protection, f7=checkbox value | template0x42FC68; serializer0x42A0A6; UnderFreqSetCallBack0x42EA1C |
| 0x42 | 8 | Read firmware revision | template0x42FC8C, wrapper0x42C766, response0x62 |
| 0x0B | 8 | Read LBO temperatures | template0x42FCD0, wrapper0x42C697; response0x1A |
| 0x09 | 8 | Fault RESET request | template0x42FCF4; faults3 callback0x42E870→wrapper0x42C6C5; captured FW1.2 replies opaque0x18 |

There is **no separately established nonmutating softstart query**. Do not use0x09 as a read. Explicit0x49 configuration receives0x69; underfrequency state is available in status byte9 bit0x80. Command0x53 changes that protection and is not the original RESET button command.

Examples (TX):

- status: `10 02 00 00 08 02 02 1E`
- firmware: `10 02 00 00 08 42 02 5E`
- STOP: `10 02 00 00 09 08 02 01 26`
- RUN: `10 02 00 00 09 08 02 00 25`

## Operating packet 0x01

Serializer `0x429B3B–0x429F8D`, length17. Payload f7..f15:

| Offset | Format | Source/scaling |
|---|---|---|
| 7 | byte | Initialized zero, no subsequent write observed |
| 8..9 | BE uint16 | Q-switch frequency in kHz ×100, truncated; firmware **0.1 uses ×10** |
| 10..11 | BE uint16 | Pulse width in ns /125, truncated |
| 12..13 | bytes | Initialized zero, no subsequent write observed |
| 14..15 | BE uint16 | Current setpoint in A ×10, truncated |
| 16 | byte | Additive checksum |

Firmware major/minor are saved from received0x62 f9/f10 in globals0x43039C/0x43073C at0x42A806. Fixed constants:0x4482D8 float10,0x4482D4 float100,0x4482D0 float125. The original writes the quantized pulse width back into the UI. Current only updates are a **combined settings write**, so acquire frequency/width from current instrument readback before generating a packet; do not substitute arbitrary defaults for missing fields.

## Service packet 0x50

Serializer `0x4292E3–0x429B3B`, length23. Panel runtime handle0x42F5D4; all numeric pairs big endian.

| Offset | UI control | Value |
|---|---:|---|
| 7..8 | 21 | `atoi(unlabelled_field_text)` converted to uint16; meaning unconfirmed |
| 9..10 | 14 | Max current A ×10 |
| 11 | — | Reserved zero |
| 12..13 | 7 | Slope (original UI label mW/V) ×100 |
| 14..15 | 9 | Intercept (original UI label mW) ×100 |
| 16..17 | 12 | Max power (original UI label mW) ×100 |
| 18..19 | 2 | Overtemperature C ×10 |
| 20..21 | 5 | Undertemperature C ×10 |
| 22 | — | Checksum |

**Legacy precision quirk:** this branch performs the float-to-integer conversion before integer multiplication by scale (e.g. `int(max_current)*10`), while normal current settings multiply first. Do not silently claim decimal service writes exactly reproduce the legacy program. A compatibility serializer should use truncation-before-scaling and clearly expose this behavior.

**Read interpretation limit:** startup0x429235 sets the unlabelled string field to empty (`0x448348`), then queues this packet at0x42C721, and decoder0x42BF17 puts response0x70 values into the service panel. UIR startup overtemperature and undertemperature defaults are 9 C and 5 C, respectively, so the exact initial query is `10 02 00 00 17 50 02 00 00 00 00 00 00 00 00 00 00 00 00 5A 00 32 07`. Thus the GUI uses this zero-field payload to fetch settings, but firmware behavior is not supplied. This does not prove that zero-field payloads with changed values are accepted. Python sends a requested service write once, preserves untouched words, and verifies both reply and a subsequent startup-pattern read; it does not guess field values automatically. Do not assume the GUI's displayed max current represents a hardware-safe limit.

## Original connection and runtime behavior

1. Configure serial and wait300 ms.
2. Send status0x02, count returned bytes (29 expected) up to3 seconds; repeats up to three iterations. Early attempts discard data. On successful last attempt runs initialization.
3. Startup initialization0x429235: firmware0x42; softstart-configure0x49 `[1,0,1]`; Q-switch-source0x55; status0x02; Q-switch-source0x55 again; service0x50 with blank numeric field; firmware0x42 again.
4. Idle queue filler0x4292D1 adds LBO0x0B then status0x02. Worker0x42CAA0 region runs a50 ms wait between TX and RX. Manual writes use the higher priority queue.
5. Original retries/reconnects after communication problems; Python should never automatically replay queued RUN or configuration writes on reconnect.

The original initialization performs a configuration write (softstart0x49). The modern connection sequence should report that difference and leave it as an explicit action. Hardware equivalence is not proven by static analysis; raw TX/RX comparison on the user's equipment remains required.


# Empower 3.02.00 binary response decoding

Source: supplied EMPOWER.EXE disassembly, selected bounded x86 handler execution and user captures; the full Windows/CVI GUI and physical instrument were not run. Addresses are PE virtual addresses. All frame offsets below are zero based from leading 0x10 at buffer 0x42FDB0. Numerical words are unsigned big endian.

## Dispatch and response envelope

Dispatcher 0x42A380 (serial read plus dispatch) and 0x42A5FB (dispatch only) route frame[5]:

|Opcode|Parser|Meaning|
|---|---|---|
|0x11, 0x12|0x42AD4C; first frame 0x42BBA2|Status/configuration|
|0x1A|0x42A8FE|LBO temperature|
|0x62|0x42A7AE|Power supply firmware version|
|0x69|0x42ABBC|Soft start|
|0x70|0x42BF17|Service configuration|
|0x71|0x42C531|Empty handler|
|0x72|0x42A82E|Output power|
|0x73|0x42BA82|Underfrequency configuration|
|0x75|0x42C539|Q-switch source|

The original scans leading 0x10, 0x02, accepts two next bytes, then reads byte[4] as total frame length. 0x42A380 reads through declared final byte. It does not validate a response checksum in this path. Startup 0x427B89–0x427C64 expects 29 received bytes for a status response; state is frame[28], suggesting response framing differs from TX checksum framing. The supplied FW1.2 captures establish the additional RX checksum variant described above; static RX code alone did not establish it.

Global 0x430768 selects one-shot initialization parsing, not a firmware response format. 0x42BBA2 clears it after copying settings into editable controls. 0x42AD4C updates ongoing state/current/faults/hours. A clean implementation can decode all known fields in either status response.

## Status 0x11/0x12

|Frame offsets|Decode|UI meaning/evidence|
|---|---|---|
|7,8,9|Three status/fault bytes|Masks below|
|10,11|BE16 /100 normally; /10 firmware0.1|Q-switch PRF in kHz, displayed by initialization 0x42BCE1–0x42BE39|
|12,13|BE16 *125|Q-switch pulse width in ns, 0x42BE41–0x42BEFE|
|14–19|Not interpreted here|Preserve raw, do not assign meaning|
|20,21|BE16 /10|Current setpoint A; initialization0x42BC00–0x42BCBD|
|22,23|BE16 /10|Sensed current A; ongoing0x42AE10–0x42AEDF|
|24–27|BE32 /3600|Power supply operation hours;0x42B11F–0x42B2C4|
|28|Enumeration below|Status indicator0x42B72B–0x42B86F|

Original ongoing parser calculates PRF with a different condition (firmware1.1 /100 else/10) at0x42AF03, but overwrites the result without using it. Initialization parser is the actual displayed/editable PRF value; preserve exact raw word for subsequent setting operations.

State: 0=RUN, 1=STOP, 2=FAULT, 3=COUNTDOWN. Main controls8/14/10/9 respectively. This mapping was independently reconciled with UIR control labels. Emission indicator is set for state0 or3 at0x42B8E0–0x42B97F; this is the original GUI indication, not independent optical emission measurement. Unknown state must remain unknown.

### Fault masks

A set bit activates the corresponding original fault indicator. Evidence0x42B2CC–0x42B4EF, matched against UIR fault panel0x42F5DC.

|Byte|Mask|Fault|UI control|
|---|---|---|---|
|7|0x40|VSWR|13|
|7|0x20|Q-switch overtemperature|7|
|7|0x10|Driver protective fault|11|
|7|0x08|Driver overpower|14|
|7|0x02|Driver overtemperature|15|
|7|0x01|Array overtemperature|18|
|8|0x80|Water flow|5|
|8|0x40|Cover interlock|6|
|8|0x20|Key switch|9|
|8|0x08|Overvoltage|17|
|8|0x04|Overcurrent|8|
|8|0x02|Underfrequency|12|
|9|0x10|Communication|10|
|9|0x01|Array overpower|22|
|9|0x02|LBO temperature|2|

Byte9 bit0x80 is a configuration flag, not fault: underfrequency interlock enabled. Original popup condition tests byte7!=0 OR byte8!=0 OR (byte9&0x13)!=0. Bits beyond the explicit masks should remain visible as raw/unknown bits, not silently mapped to a named fault.

## Other responses

|Opcode|Offsets|Decode|
|---|---|---|
|0x62|9,10|Firmware major.minor; strings at0x4485F4 and format0x448590|
|0x72|7,8|Output power W=BE16/100;0x42A835–0x42A8F2|
|0x1A|11,12|LBO temperature °C=BE16/10;0x42A905–0x42A9C2|
|0x69|7 bit0|Soft start enabled when set|
|0x69|9|Soft start current ramp step=byte/2 A/s;0x42AC25–0x42AC92|
|0x73|9 bit0x80|Underfrequency interlock enabled when set; strings explicitly say ENABLED, faults at500Hz|
|0x75|7|Q-switch source raw selector|

Original source parser substitutes3 for raw0 when GetNumListItems reports exactly three source entries; factory mode adds the fourth entry0. The branch does not depend on the previous selected value. Modern Python preserves raw0, displays CW RF OFF and blocks normal RUN; it never fabricates EXTERNAL from the previous reading.

## Service response0x70

|Offsets|Raw conversion|Original service control|
|---|---|---|
|7,8|BE16/10|max current A, ID16|
|9|Uninterpreted reserved byte|Preserve|
|10,11|BE16/100|Power slope, ID8|
|12,13|BE16/100|Power intercept, ID11|
|14,15|BE16/100|Max power, ID13|
|16,17|BE16/10|LBO overtemperature setting, ID3|
|18,19|BE16/10|LBO undertemperature setting, ID6|

Source0x42BF17–0x42C52F. Initial response also fills editable controls14,7,9,12,2,5 then clears0x430760. Max-current response sets the maximum attribute on both Setup current controls. UIR service power units should be preserved exactly; the executable applies the same /100 numeric conversion regardless of any physical interpretation. Main output power explicitly has W label. Avoid silently converting these service numbers based on expectations about laser wattage.

## Software LBO stability monitor

This is a GUI-side additional interlock, not an independently received device fault. Temperature handler0x42A8FE keeps two double arrays of180 and10 entries, initialized to0.0 by0x42A2D1. A timer callback0x42E841 event15 sets0x430770; on the next LBO temperature response it writes one sample into both circular buffers and calculates each mean (call0x4079E8). The UIR LBO timer interval is1.0s and initially enabled; binary_ui independently recovered the big-endian double timer record at0x1418C. The other timer is3.0s and initially disabled.

0x43077C controls behavior:0 compares abs(mean180-mean10)>1.0°C, queuesSTOP via0x42C6AE and enters1;1 queuesSTOP and sets synthetic LBO stability fault0x430764 and UI ID4;2 clears fault and returns0;3 clears fault and remains3 (disabled). User enable selects2, disable selects3. This original zero-filled warmup and execution-local mean behavior should not be copied blindly as a physical stability guarantee. A replacement should state exact monitoring behavior and availability, with a meaningful warmup before readiness.

## Evidence limitations

User-supplied serial transcripts were decoded and selected original routines compared. The new release has not communicated with a physical controller, run on Windows 10/11, or measured optical output. Max power, slope/intercept physical units, service numeric-field acceptance, and cross-firmware behavior remain unverified. Observed ignored zero-code writes do not establish a universal code0 read-only guarantee.
