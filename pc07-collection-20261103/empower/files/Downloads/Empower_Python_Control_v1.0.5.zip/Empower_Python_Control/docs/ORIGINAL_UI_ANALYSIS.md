# Empower GUI 3.02.00 — independent UI reverse engineering

Source: extracted `EMPOWER.EXE.1.189E4EEE87974F3BA736D3B6513C412A` (PE32, link timestamp 2010-04-06) and `EMPOWER.UIR.2.189E4EEE87974F3BA736D3B6513C412A`. Static inspection only. Addresses below are EXE virtual addresses unless explicitly UIR offsets.

## Panels and controls

UIR control records (`cTRl`) begin at offset 0x704C. A record's stored ordinal is **one less** than the runtime control ID used by GetCtrlVal/SetCtrlVal. Callback names begin at record+43. This mapping was independently checked against numeric setters and run-status code.

| Global panel handle | Purpose | Important control IDs |
|---|---|---|
| 0x42F5CC | Main | 2 Quit; 3 RUN; 4 STOP; 5 Output Power (W); 8 RUN LED; 9 COUNT LED; 10 FAULT LED; 11 comm OK; 12 comm ?; 13 comm BAD; 14 STOP LED; 15 emission LED; 16 EMISSION text; 18 three-second RUN timer; 20 LBO sample timer |
| 0x42F5D0 | Information | 2 log-file chooser; 3 logfile path; 4 status/error messages; 5 Close; 6 operation hours; 7 unused second version message; 8 PSU firmware; 9 GUI version |
| 0x42F5D4 | Secret Service | See table below |
| 0x42F5D8 | Setup | 2 sensed current(A); 3 set current(A); 4 QSW source; 5 Close |
| 0x42F5DC | New fault panel | See fault table |

Service panel:

| Runtime ID | UIR name | Visible label / behavior |
|---|---|---|
| 2 | BOXSETOVERTEMP | Set overtemp(C) |
| 3 | BOXREADOVERTEMP | Read overtemp(C) |
| 4 | SLIDEQSWPRF | QSW FREQ(kHz) |
| 5 | BOXSETUNDERTEMP | Set undertemp(C) |
| 6 | BOXREADUNDERTEMP | Read undertemp(C) |
| 7 | BOXSETSLOPE | Set slope(mW/V) |
| 8 | BOXREADSLOPE | Read slope(mW/V) |
| 9 | BOXSETINT | Set intercept(mW) |
| 10 | SLIDEPULSEWIDTH | PULSEWIDTH(ns) |
| 11 | BOXREADINT | Read intercept(mW) |
| 12 | BOXSETPOW | Set max power(mW) |
| 13 | BOXREADPOW | Read max pow(mW) |
| 14 | BOXSETCURR | Set max curr(A) |
| 15 | BOXREADLBO | LBO temp(C) |
| 16 | BOXREADCURR | Read max curr(A) |
| 17 | COMMANDBUTTON | Close |
| 18 | TEXTMSG_SOFTSTART | Soft-start status |
| 19 | DROPS | Communication drops |
| 20 | TEXTMSG_UNDERFREQ | Underfrequency protection status |
| 21 | STRING | Unlabelled string read by service serializer; converted to a numeric word; purpose unconfirmed |
| 22 | UNDER_FREQ | Underfrequency fault enable |
| 23 | BINARYSWITCH | LBO Stability Fault enable (host-local monitor) |

**Unit caution:** the actual legacy labels say mW and mW/V in this panel, but those labels alone do not establish physical units of firmware calibration quantities. Ordinary main power display is W. Read/write scaling must follow decoded wire values, and service units should be flagged as legacy labels where ambiguous.

New fault panel 0x42F5DC:

| ID | Label |
|---|---|
| 2 | LBO temperature |
| 3 | RESET button |
| 4 | LBO stability |
| 5 | Waterflow interlock |
| 6 | Cover interlock |
| 7 | Q-switch overtemperature |
| 8 | Driver overcurrent |
| 9 | Keyswitch interlock |
| 10 | Communication |
| 11 | Driver protective |
| 12 | Q-switch underfrequency |
| 13 | Q-switch VSWR |
| 14 | Driver overpower |
| 15 | Driver overtemperature |
| 17 | Driver overvoltage |
| 18 | Array overtemperature |
| 22 | Array overpower |

UIR also includes an older unused fault panel with CK SUM, KILLSW and additional legacy names; do not assign those names to new-panel bit positions.

## Q-switch source

UIR `fLSt` at 0x1364C stores big-endian floats 3,2,1, aligned with the `cLSt` labels at 0x136678:

| Label | Value |
|---|---:|
| EXTERNAL | 3 |
| INTERNAL | 2 |
| HOLD OFF | 1 |

Typing a legacy factory access sequence also appends `CW RF OFF` value0 if the ring currently has only3 items (0x42CDA9–0x42CE03). Value0 must not be mistaken for EXTERNAL.

## Main state mapping

0x42B72B onwards compares receive-state byte at 0x42FDCC and updates controls:

| Raw value | Main LED | Meaning |
|---:|---:|---|
| 0 | 8 | RUN |
| 1 | 14 | STOP |
| 2 | 10 | FAULT |
| 3 | 9 | COUNTDOWN |

When communication/local stability fault is active, FAULT display may override normal state LEDs. Treat emission as separately reported/derived state rather than assuming software intent equals physical emission.

## Action callbacks

| Action | Callback evidence | Packet wrapper |
|---|---|---|
| Normal set current, QSW frequency, pulse width | `setupmsg`, 0x42C9EB; EVENT_COMMIT(1) ->0x42CA04 | 0x42C624, opcode01 |
| QSW source | `serqswsrc`, 0x42CA12 ->0x42CA2B | 0x42C63B, opcode51 |
| Service numeric fields | `secretcall`, 0x42C9C4 ->0x42C9DD | 0x42C6F3, opcode50 |
| STOP | `parse_command5`, 0x42CA39 sets global0x430744=0 then calls wrapper | 0x42C6AE, opcode08; serializer uses payload1 for OFF |
| RUN | `cllbck`, 0x42C8D9 starts timer on EVENT_LEFT_CLICK(3), cancels on commit/release; `ThreeSecPassed` 0x42E78F sets0x430744=1, queues packet, then clears flag | 0x42C6AE, opcode08; serializer uses payload0 for ON |
| RESET | faults3 cllbckcmd_reset0x42E870 | 0x42C6C5, opcode09 |
| Underfrequency protection | service22 UnderFreqSetCallBack0x42EA1C | 0x42C74F, opcode53 |
| LBO stability toggle | service23 stabilityfaultonoff0x42E8E3 sets local monitor state2(enable/reset) or3(disable) | No wire command |

Original RUN behavior requires holding for **3 seconds**, with abort on early release. UIR timer records at0x1418C and0x141A0 contain1.0s(enabled) and3.0s(disabled) intervals respectively. These correspond to LBO sampling and RUN hold timers.

## Host-local LBO stability protection

0x42A8FE processes LBO temperature feedback. It fills180-sample and10-sample circular buffers, averages them via0x4079E8, and compares their absolute difference to1.0°C (constantQWORD0x4482E8). A once-per-second timer callback0x42E841 sets the sampling flag0x430770. On threshold violation it queues STOP and latches a local stability fault; fault indicator is new-panel ID4. State variable0x43077C:0 monitoring;1 tripped;2 reset transition;3 disabled. This state is **not a firmware configuration field**.

Startup0x42A2D1 initializes both buffers with0.0 (constantQWORD0x4482C8), not150°C. Literal reproduction of this startup behavior may create artificial warm-up differences. If implementation uses a warm-up guard or measured initial fill, document that deliberate deviation.

## UIR static numeric ranges

These are widget configuration, **not verified hardware operating ratings**. The supplied CVI DLL additionally proves IGNORE range mode for editable frequency and pulse-width controls: their visual bounds are not enforced original write limits. Setup current and generic service numeric editors instead use COERCE. Data comes from UIR `pS15` at0xA148 and0x135E0; each float block stores default,max,min,step.

| Control | Default | Min | Max | Step |
|---|---:|---:|---:|---:|
| Set/sensed current(A) | 0 | 0 | 40 | 1 |
| Service max current(A) | 0 | 0 | 40 | 1 |
| Max power(legacymW label) | 0 | 0 | 500 | 1 |
| Slope(legacymW/V label) | 0 | 0 | 100 | 1 |
| Intercept(legacymW label) | 0 | 0 | 5 | 1 |
| Undertemp(C) | 5 | 5 | 200 | 1 |
| Overtemp(C) | 9 | 5 | 200 | 1 |
| QSW frequency(kHz) | 0 | 0 | 5 | 1 |
| Pulse width(ns) | 125 | 125 | 10000 | 125 |

0x42BF17's service readback handler dynamically replaces setup current/sensed-current maximum (attribute0x2DA) with firmware-reported max current, via0x42BFE3–0x42C024. It also populates editable service fields once on initialization. Do not assume the UIR's40A maximum is the specific laser's permitted operating maximum.

## Service access and unanswered firmware semantics

MainCallBack0x42CBFD recognizes four keyboard sequences contained at0x448248: `user`, `regensvc`, `factory13`, and `serv`. The `factory13` match at index2 reaches0x42CD47 and displays the service panel at0x42CDA9; it may also append the CW RF OFF ring item. It does not assign control21 or transform the text into numeric13. The matched-mode global0x430784 has no other observed references. Python exposes its service page directly and does not implement these keyboard sequences.

The service serializer0x4292E3 reads unlabelled service fieldID21 at0x429319, applies `atoi` at0x429327, and stores the resulting word in TX bytes7..8 at0x42936E. Startup clears this field at0x429290 using the empty string at0x448348 before queueing opcode50. The UIR record at0x70FC..0x713B has no label or callback; its password-mask attribute has not been decoded. No other application assignment or hardcoded numeric credential was found. `user_settings.txt` loads COMPORT and DATA_FILE, not this field. Calling it a password or authorization value in earlier reports was an inference and is corrected in v1.0.4.

The startup transaction and captured settings response support the blank/zero read pattern, but do not prove that a changed-settings payload with zero is accepted. Python now permits blank as0, sends one explicitly requested write, and checks both reply and subsequent readback. This does not establish a device-side authorization bypass. Successful existing original-program captures or manufacturer documentation are needed to establish device write requirements; automatic credential guessing is not implemented.

Legacy logging includes PROGRAM START/STOP, CONNECTION ESTABLISHED/LOST, RECONNECT ATTEMPT, individual faults, ALL FAULTS CLEARED and RESET FAULTS ATTEMPT. Error filename is user-selectable and settings include COMPORT and DATA_FILE. The binary supportsCOM1–COM9 strings, while its initial port chooser offers four buttons.
