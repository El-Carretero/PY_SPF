# Empower manual implementation requirements

Source: supplied `334A Rev. A Empower User's Manual.pdf`, Spectra-Physics part 0000-334A Rev. A, March 2005. Printed pages are cited below; PDF page number equals printed Chapter 6 page plus 54 (6-1 = PDF 55). This is a reference analysis, not a claim about the later CD's implementation.

## Evidence boundaries

- The manual covers Empower-15/Empower-30, Model 2800 power supply.
- Page 6-3 says the software description concerns revision 1.1, but Figure 6-3 visibly shows GUI revision 2.4 / firmware revision 1.1. Neither establishes the behavior of uploaded CD 3.02.00. Preserve this inconsistency in evidence; the executable is the authority for later-version details.
- The manual specifies RS-232 over supplied 9-pin cable, software default COM1 (3-6, 4-4); it does **not** provide baud, parity, framing, message terminators, commands, checksums, register mapping, fault bit positions, or actual upper-current setting. These must come from the original application/protocol.
- No service-window screenshot, service password, calibration procedure, limit-editing controls, or complete protocol appendix is present. Do not invent these from the manual.
- Rendered and visually checked Figures 6-1 through 6-5 on PDF pages 58-61. Render files: `analysis/manual/gui-58.png` through `gui-61.png`.

## Screens and controls explicitly documented

| Screen | Controls | Readbacks / presentation | Reference |
|---|---|---|---|
| Main | Green RUN, red STOP; File and View menu bar; View opens Information, Setup, Active Faults | COMM, FAULT, STOP, COUNT, RUN LED indicators; conspicuous black-on-red EMISSION banner when laser on | 6-4 to 6-5, Figs. 6-1/6-2 |
| Information | Set error log name (file destination selector) | GUI software revision; power-supply firmware revision; power-supply cumulative operating hours; current log pathname; scrollable recent timestamped event/fault messages | 6-5 to 6-6, Fig. 6-3 |
| Setup | QSW SOURCE: EXTERNAL / INTERNAL / HOLD OFF; SET CURRENT (A), directly editable number plus slider/step control | SENSED CURRENT (A), actual current displayed numerically and as gauge | 6-6 to 6-7, Fig. 6-4 |
| Active Faults | RESET button | 16 independent LED flags in 5 categories; show every simultaneous active fault | 6-7 to 6-9, Fig. 6-5 |

Figure 6-4's illustrative current scale is 0 to 25 A and set value 19.5 A. This is **not** proof all devices have a 25 A maximum. Page 6-7 says upper limit is the factory maximum setpoint. Current adjustment resolution: 0.1 A. Only one current setpoint exists at a time.

Main should remain visible while operating (6-5). The manual's page 2-7 calls its black-on-red indicator "Emergency", while the actual figures and page 6-5 label it EMISSION; implement the visible emission warning, not an unsupported separate Emergency status.

Information log behavior: append history, newest at end, user-selectable text-file destination, show recent timestamped faults. Figure 6-3 also visibly includes CONNECTION ESTABLISHED and ALL FAULTS CLEARED events. Operating-hours count is described as accumulated power-supply operation time, not explicitly diode-emission hours.

## RUN, STOP, initialization, and connection behavior

1. Hardware startup (6-1): chiller on; AC power supply on; allow 15 minutes harmonic-crystal warm-up. Start GUI. After communication is established and interlocks are closed, STOP indicator lights, identifying ready-to-start state. Keyswitch must be ON. If crystal temperature still causes fault, keyswitch OFF, wait 5 more minutes, retry. Software must show actual hardware readiness, not infer readiness merely from elapsed time.
2. Set a suitably low diode-current value in Setup before enabling laser (6-2).
3. Daily startup procedure explicitly says to click and **hold ON for 5 seconds** (6-2). Main-window section instead calls the button RUN and describes selecting it (6-4). Original-application reverse engineering should resolve exact later-version press handling; preserving deliberate hold-to-start is supported by the manual.
4. After start, COUNT is on during controlled ramp/countdown; emission indication starts immediately as emission is imminent. Approximately 3 seconds precede laser emission, with audible tone and flashing head lamp. Then COUNT goes off, RUN and emission indicators remain on and EMISSION banner is shown (6-2, 6-4). Do not assume the 5-second user hold and approximately 3-second hardware delay are the same timer; manual presents both.
5. STOP immediately turns diode pumps off and closes cavity shutter, terminating lasing (6-3, 6-5). Shutter is otherwise automatic; no normal separate shutter control is documented.
6. Changing QSW SOURCE while running turns the laser off. Restart requires another RUN action (6-7). Never auto-resume after mode change.
7. COMM is on only while serial link works. On lost link COMM goes off, and original software automatically tries to reset the link (6-5). This is link recovery, not permission to replay RUN or other write commands. Manual does not specify retry count, timeout, or exact shutdown-on-link-loss timing.
8. Active COM interlock indicates interrupted communication; manual recovery involves exiting program, checking cable and supply, AC-cycling supply, restarting software (6-8). Distinguish application connection state from device COM fault.
9. Software RESET clears corrected interlock latches; it cannot fix their causes (6-8). Some faults explicitly require physical keyswitch/AC cycles. No automatic fault-reset loop or automatic RUN restart is documented.
10. Shutdown (6-3): STOP first; keyswitch OFF/remove key; exit GUI. AC supply remains ON normally. Chiller usually remains on during day; cold-start stability takes approximately 15 minutes. GUI close must not be treated as confirmed STOP without successful device feedback.

## Q-switch source and stated limits

- INTERNAL uses factory preset clock; manual says changing internal frequency requires factory service. No normal frequency input widget is documented (6-2, 6-6).
- EXTERNAL selects rear EXT QS TRIG IN. External frequency must remain both within +/-20% of the configured factory rate and within 500 Hz to 10 kHz. Example: 1 kHz unit, 800-1200 Hz. A generic 500-10000 Hz spinner without device-specific nominal-rate restriction is not sufficient (6-2, 6-6).
- External input is TTL-level, capable of driving 50-ohm load (4-4), pulse duration at least 2.5 microseconds, synchronized to rising edge (6-2).
- External trigger below 500 Hz causes fault and laser off (6-6, 6-8).
- HOLD OFF is for service procedures only (6-6); manual does not expose more semantics. Do not implement it as a routine laser-off substitute.
- RF power for Q-switches is supplied by the system in INTERNAL/EXTERNAL; do not confuse Q-switch trigger frequency with approximately 27.11 MHz AOM RF carrier (4-4).

## Fault display, meaning, and recovery

The table order matches UI categories, **not protocol bits**. Wire mapping must be separately established.

| Group | LED | Meaning / stated threshold | Manual recovery / behavior |
|---|---|---|---|
| INTERLOCKS | KEYSWITCH | Keyswitch OFF | Requires actual keyswitch ON; software cannot close this interlock |
| INTERLOCKS | COM | Communication interruption | Exit GUI, check cable/supply, cycle AC, restart GUI |
| INTERLOCKS | COVER | Head cover open **or user interlock open** | Close actual interlock, cycle keyswitch; do not describe exclusively as head-cover fault |
| INTERLOCKS | WATERFLOW | Cooling flow below 2.0 GPM | Verify chiller/pressure/reservoir/hoses, cycle keyswitch |
| QSWITCH | UNDERFREQ | EXTERNAL trigger below 500 Hz | Correct trigger; also obey +/-20% nominal-rate restriction |
| QSWITCH | OVERTEMP | Either AOM above safe temperature (numeric limit absent) | Verify cooling, cycle keyswitch |
| QSWITCH | VSWR | QSW RF cable disconnected or RF mismatch/poor coupling | Correct RF connection; no special software recovery guaranteed |
| DIODE | OVERTEMP | Pump chamber too hot (numeric threshold absent) | Supply OFF; chiller running 10 minutes; verify chiller 18 C; restart at lower current |
| DIODE | OVERPOWER | Pump-diode power above factory limit | Reduce current; AC cycle |
| DIODE | OVERVOLT | Diode drive voltage above factory limit | Check umbilical; AC cycle |
| DIODE | OVERCURR | Requested diode current above factory limit | Lower current; AC cycle |
| DRIVER | PROTECTION | Internal driver FET protection triggered | Do not operate; service required |
| DRIVER | OVERTEMP | Driver FET heatsink too hot, short, or overcurrent | Verify airflow; non-lasing cooling >=10 minutes before restart |
| DRIVER | OVERPOWER | Driver FET above factory power limit | Reduce current; AC cycle |
| LBO TEMP | TEMP | Crystal temperature > +/-1 C away from factory optimum | Diode pumps turn off and cannot restart until cleared; wait within range |
| LBO TEMP | STABILITY | Crystal temperature outside range based on running average (algorithm/threshold absent) | Wait for stabilization; oven expected stable within 10 minutes |

Pages 6-8 to 6-9. Page 6-9 introduction oddly says LBO TEMP LEDs turn on when computer/supply communication is interrupted; following definitions clearly specify temperature and stability causes. Treat this sentence as ambiguous rather than inventing an LBO fault mapping for link loss.

## Range/caution implications for implementation

- Maximum diode current is factory-set to ensure rated performance/lifetime; not a generic user-adjustable target (6-3). Manual examples 15/20/25 A producing 6/15/20 W on one 1 kHz Empower-30 are illustrative, not calibration data or guaranteed conversions. Do not derive laser output power from current or assume 25 A corresponds to 20 W for this user's unit.
- Manual does not define Max Power meaning or units in later service UI, so do not label a discovered later-register value as measured output power solely from the words "power" or the above examples.
- Shutter is fail-safe closed at startup and on interlock fault, opening only when ON is issued (2-6). Presence of internal pump emission cannot be inferred solely from visible green output; head emission lamp means internal emission/capability (2-5).
- User/cover interlock opens pump circuit and restart requires closure plus physical keyswitch cycle (2-5). No application should promise that RESET bypasses physical interlocks.
- Preserve conspicuous emission warning on all panels that affect output (2-7), and easily available STOP while auxiliary panels open (6-5).
- Fault thresholds other than those explicitly listed above are factory values or not published. Do not invent simulator values and then present them as verified hardware specifications.
- RS-232 device communication is the migration-critical dependency; OS compatibility alone does not validate physical operation.

## Suggested acceptance scenarios derived from manual

- Clear distinction between disconnected/unknown, stopped, countdown, running, and fault; stale data never shown as fresh confirmation.
- Holding then releasing RUN before activation cancels intent; hold threshold does not block STOP/UI.
- RUN does not automatically recur following mode change, fault reset, or reconnection.
- STOP command is immediate and state becomes stopped only on successful device confirmation.
- Current validation uses actual device maximum and rejects nonfinite/non-numeric values; manual resolution 0.1 A retained.
- All 16 mapped fault flags can be displayed simultaneously; unknown bits remain visible in raw status if later firmware adds them.
- Log contains fault changes, recovery, connection transitions, and timestamps without erasing previous history.
- The simulator must label approximate fault thresholds and timing that are not supported by original binary or manual.
