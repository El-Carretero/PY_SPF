# v1.0.5 comparison with original executable instructions

**Result: 1,826 cases checked; 1,820 exact byte matches, 6 expected service-preservation differences, and no unexpected mismatch.** This was a direct comparison against bounded execution of the supplied original EXE's transmit routines, not a comparison against the Python simulator or the reconstructed Python codec.

Executed on 2026-09-23 UTC using Python 3.12.14, Unicorn 2.1.4 and pefile 2024.8.26. Every case, input, opcode, original packet, modern packet and comparison result is recorded in [ORIGINAL_COMPARISON_1_0_5.json](ORIGINAL_COMPARISON_1_0_5.json). Random samples use seed `0x10530200`.

## Evidence identity and execution boundary

| Input | SHA-256 |
|---|---|
| Supplied original GUI 3.02.00 EXE | `dcd350a12c96149ec775f3c41a34ab54a62c34d0e6b888ef69cb0c650c8af3a5` |
| Existing `OriginalOracle` analysis tool | `8513e30a9f3dccbfd271a8ed026af5f467ac2a614bdb980bb2a0d1c2e6efbc83` |
| Modern `empower/commands.py` compared here | `c94ff7272fa537803a86fe1a74ecb561c000ea7822439d7694fefd9af3e9d083` |
| Development comparison driver | `7a36764a7a035fd886a87d13980f6b8b573eb92e8907a77c8488b09948859f6f` |

The existing `Empower_Original_Python/tools/original_oracle.py` was used unchanged. It verifies the EXE hash and executes original instructions for the template constructor (`0x428805`), serializer (`0x4292E3`), x87 integer conversion (`0x4028B8`), byte extraction and additive checksum (`0x428780`). Each serializer comparison confirms that the original checksum routine was reached. Recorded serializer calls executed 1,688,605 original instructions in total; that number excludes the constructor and separate checksum-only checks.

The CVI UI calls are bounded stubs supplying float32, int32 and ASCII control values. `atoi` is an independent ABI stub; its DLL implementation is not executed. No source EXE, CVI DLL or oracle was copied into the modern release. The comparison driver is development-only; the JSON retains the complete case evidence.

## Cases and results

| Group | Cases | Result |
|---|---:|---|
| Five read commands and explicit RESET `09` | 6 | Exact |
| RUN / STOP polarity | 2 | Exact |
| Q-switch values 0, 1, 2, 3 | 4 | Exact |
| Original softstart configuration `49 02 01 00 01` | 1 | Exact |
| Explicit underfrequency disabled/enabled `53` | 2 | Exact |
| Original startup service pattern | 1 | Exact |
| Operating inputs at normal resolutions | 1,080 | Exact |
| Adjacent float32 values at conversion boundaries | 108 | Exact |
| Operating raw-word preservation | 180 | Exact |
| Seeded fractional operating converter inputs | 200 | Exact |
| Service whole-number limits and representative values | 9 | Exact |
| Seeded whole-number service inputs | 200 | Exact |
| Service fractional conversion boundaries | 12 | Exact |
| Service raw-word preservation | 6 | Expected differences, explained below |
| Original checksum on payloads containing high bytes | 15 | Exact |

Normal operating vectors combine firmware `(0,1)`, `(0,2)`, `(1,1)` and `(1,2)`; current values from 0 to 40 A including 0.7, 12.5 and 14.5 A; six frequencies at each firmware's resolution; and widths 125, 250, 1,375, 9,875 and 10,000 ns. The separate boundary/converter groups deliberately include values adjacent to integer conversion thresholds. These prove converter behavior, not that a modern GUI accepts every fractional or slightly out-of-range fixture.

For example, firmware `(1,2)`, 14.5 A, frequency `1.2499998807907104` kHz (the float32 neighbor below 1.25), and 250 ns produce the same packet on both sides:

`10 02 00 00 11 01 02 00 00 7C 00 02 00 00 00 91 35`

Thus the frequency word is 124 in this boundary case. Firmware `(0,1)` uses the separately tested factor 10; the other tested revisions use 100. Service conversion tests likewise retain the original cast-before-multiply ordering.

The underfrequency comparisons use the original's post-initialization checkbox path (`g_initufe=0`). The original startup guard can retain an earlier template byte; the modern explicit setter intentionally sends the caller's requested Boolean. Only the proven original softstart configuration was compared, not arbitrary arguments supported by the general packet builder.

## Why six service cases intentionally differ

The original service serializer converts each editor to a whole integer before scaling. Reconstructing unchanged decimal settings through those editors can lose fractional values. The modern `set_service_words` intentionally preserves the six raw words from fresh readback and changes only the requested field.

Each of the six cases changes one whole-number service field while the other five have fractional raw readbacks. The modern packet preserves all five unchanged words; the original editor-based serializer truncates them. The differing fields are exactly those five, and the original checksum routine independently validates each modern packet's checksum.

Example: change maximum power to 150 while retaining these readbacks:

| Field | Raw readback | Modern transmitted word | Original editor-based word |
|---|---:|---:|---:|
| Maximum current | 251 | 251 | 250 |
| Power slope | 601 | 601 | 600 |
| Power intercept | 123 | 123 | 100 |
| Maximum power, requested change | 12501 | 15000 | 15000 |
| High LBO temperature | 1351 | 1351 | 1350 |
| Low LBO temperature | 1182 | 1182 | 1180 |

This is an intentional improvement in field preservation, not an unexplained protocol difference. It does not establish whether the instrument accepts the requested write or its numeric service field.

Numeric service inputs 0, 17 and 65535 are synthetic serialization fixtures, not discovered or verified authorization values.

## Limits

The result validates tested host packet construction and arithmetic. It does not execute Windows/CVI UI rendering, callbacks that select the action, queues, serial transport, or device firmware. It does not demonstrate hardware acceptance, optical output, service authorization, or universal read-only semantics for the startup `0x50` pattern. See [REVIEW_PROTOCOL_1_0_5.md](REVIEW_PROTOCOL_1_0_5.md) for that limitation and the static callback evidence distinguishing RESET `09` from protection setting `53`.

No production code changes were needed as a result of this comparison.
