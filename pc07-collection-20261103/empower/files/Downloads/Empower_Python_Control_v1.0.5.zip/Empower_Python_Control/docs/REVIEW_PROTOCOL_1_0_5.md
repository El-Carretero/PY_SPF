# v1.0.5 protocol review

This review applies the verified findings from the supplied Empower GUI 3.02.00 executable to the modern controller. It does not require duplicating the original UI or removing modern input validation and readback checks.

## RESET and protection are different commands

The original application's named callbacks resolve an earlier interpretation error:

| Action | Original evidence | TX bytes |
|---|---|---|
| Fault RESET | `_cllbckcmd_reset` at `0x42E870` calls wrapper `0x42C6C5`, using template `0x42FCF4` | `10 02 00 00 08 09 02 25` |
| Set underfrequency protection | `_UnderFreqSetCallBack` at `0x42EA1C` calls wrapper `0x42C74F`, using template `0x42FC68` | Enabled: `10 02 00 00 09 53 02 01 71`; disabled: `10 02 00 00 09 53 02 00 70` |
| Original softstart configuration | Constructor/serializer for template `0x42FC44` | `10 02 00 00 0B 49 02 01 00 01 6A` |

Consequently, `0x09` must not be sent as an automatic softstart query during connection, refresh, or RUN preparation. `reset_faults()` now builds only `0x09`; `set_underfrequency(bool)` builds `0x53`. The old `query_softstart()` entry point raises `NotImplementedError` without constructing a packet. The read-command registry excludes both commands.

The supplied FW1.2 capture answers `0x09` with opaque `0x18`. The original RX dispatcher has no `0x18` state handler; this reply does not establish that a fault cleared or that softstart is enabled. Read status after an explicit RESET. Softstart information is decoded only from `0x69`; no independent nonmutating softstart query has been established. Underfrequency protection can be read from status byte 9 bit `0x80`.

## Arithmetic, fields and modern behavior

The review found the established numeric fields consistent with the original serializer and receiver: current uses 0.1 A words, pulse width uses 125 ns ticks, and frequency uses 0.01 kHz words except firmware `(0,1)`, which uses 0.1 kHz. Service numeric serialization truncates before multiplying by its field scale. The original mW/mW/V service labels and main output W label are preserved; they do not independently prove the firmware fields' physical calibration or limiting behavior.

Service writes preserve the six fresh raw service words and replace the requested field only. Transmit byte 11 remains the original constructor's zero. The ignored/reserved byte 9 in a service response has no proven mapping to this transmit byte and must not be copied there merely to preserve an unknown field.

Finite-value/range validation, whole-number service inputs, preserved raw fields, explicit writes and readback verification are intentional modern behavior. The reconstruction's original integer wrap and UI quirks are not reasons to remove them. Checked RX framing for the supplied FW1.2 captures likewise remains appropriate; the original's lack of checksum validation is not a compatibility requirement.

## Service `0x50` read-pattern limitation

The original clears its unlabelled numeric string field and queues `0x50` during startup. With the UIR defaults this produces:

`10 02 00 00 17 50 02 00 00 00 00 00 00 00 00 00 00 00 00 5A 00 32 07`

The modern controller uses that established startup pattern for service reads. Its read-only interpretation remains inferred from the host's usage and supplied captures, rather than proven from the device firmware. Blank/zero does not establish authorization or successful writing. A different firmware that accepted this pattern as a write could change fields during a nominal read; no universal read-only service opcode has been recovered. This review does not invent one or claim firmware-side behavior was tested.

Validation uses independent literal TX vectors, including distinct RESET/protection packets and regression checks that unsupported query functions cannot construct a mutating packet. No physical instrument was used for this review.
