# v1.0.5 software verification

Date: 2026-09-23 UTC. Environment: Linux x86_64, Python 3.12.14, PySide6/Qt 6.11.2, pyserial 3.5. Qt uses the offscreen platform plugin.

**Final result: 144 tests passed, zero failures/errors/skips.** The run is recorded verbatim in `TEST_RESULTS.txt` and summarized in `TEST_SUMMARY_1_0_5.json`. The independent original-code comparison and integrated demo are separate checks, not additional unit-test counts. No test opens a physical serial port: transport cases use Linux pseudo-terminals, and the integrated GUI uses only the built-in simulator.

## What was verified

| Check | Evidence and scope |
|---|---|
| Original x86 packet comparison | 1,826 cases: 1,820 exact matches, 6 intentional service raw-word preservation differences, zero unexpected mismatches. `ORIGINAL_COMPARISON_1_0_5.md` and `.json` retain boundaries, hashes and case data |
| Actual previous serial captures | Independent decoding of six supplied JSONL logs: 2,065 RX frames, zero checksum mismatches. Standalone representative bytes and strict regressions are included; full log files are not required. `REVIEW_CAPTURE_1_0_5.md` records exact scope |
| Commands and response parsing | Literal RESET09/protection53 distinction, no automatic09, explicit49/69, raw source0, current/frequency/width arithmetic, all15 faults, lengths/checksums, unsupported firmware shape rejection |
| Device settings | Fresh state before writes, bounded current-only mismatch warnings, preserved operating/service fields, service target mismatch versus unexpected field change, no automatic write retries |
| Worker lifecycle | STOP and terminal precedence, authorization revocation before writes, initialization cancellation, readback warnings retaining revocation, unconditional transport cleanup and logging-failure isolation |
| GUI | Worker-confirmed authorization, no stale re-arming, uncommitted current text and service edits retained, backend-aligned RUN prerequisites, fresh-status lifetime, five-second hold and release/cancellation |
| LBO and STOP | Measured180-sample warmup, drift trip, device refusal of STOP detected; STOP independent of optional optical readout; old RUN power invalidated until fresh measurement |
| Serial transport | pyserial over actual POSIX pseudo-terminals: fragmented responses, ignored unrelated ACK and partial-frame timeout cleanup |
| Session logs and demo | Partial-open/close errors release resources, numeric-field redaction, simulator RESET/protection semantics independently tested |

## Integrated GUI run

`tools/verify_demo.py` uses the actual Qt window, signal bridge, worker, command encoding, parser and simulator. It performs:

1. Connection with no automatic RESET/protection/softstart writes and RUN blocked while softstart is unknown.
2. User-side service enable, explicit original softstart configuration and readback confirmation.
3. Current Apply12A with confirmed response.
4. An actual five-second button hold, controller COUNTDOWN, then synthetic RUN.
5. Explicit STOP and stopped-state confirmation, with old power invalidated.
6. Shutdown followed immediately by another STOP; shutdown still completes and the worker releases the device.

`INTEGRATION_RESULT_1_0_5.json` records actual elapsed hold time, packet count and result. `main_synthetic_run_1_0_5.png` and `service_synthetic_stopped_1_0_5.png` were visually inspected. All their readings are invented demo data, not measured laser output. Older bundled screenshots and version-specific reports are retained historical material.

## Remaining limits

- Windows10/11, macOS and a Windows-built EXE were not executed. Windows scripts were statically checked, retain CRLF, and include the existing installation/build procedure.
- No physical Empower, power supply, USB-RS232 adapter or optical output was tested with this release.
- The original full Windows/CVI application was not run. Bounded original x86 serializers were executed with import stubs; this does not validate original UI event timing or firmware.
- Max Power's physical role, service mW/mW/V calibration, numeric-field acceptance and universal nonmutating semantics of the startup50 pattern remain unconfirmed.
- Real-capture regression proves interpretation of previously recorded bytes. Simulator success is not evidence of instrument acceptance, fault recovery, current ramp or optical behavior.

Use `HARDWARE_ACCEPTANCE_KO.md` to record the remaining equipment checks.

## Reproduction

From the extracted project root after installing `requirements.txt`:

```text
python -m unittest discover -s tests -v
python -m compileall -q empower launcher.py tools/verify_demo.py
python -m empower --version
python tools/verify_demo.py --output demo-verification
```

`run_tests.cmd` runs the unit suite on Windows; the three POSIX transport tests skip there. The optional demo integration creates screenshots, synthetic session logs and a JSON result in the requested directory. No laser is needed or used. The original-machine-code comparison is a separately recorded development check requiring the owner's EXE and the existing oracle; neither binary nor oracle is a runtime dependency of this release.
