> 과거 버전의 조사 기록입니다. v1.0.5에서 원본 콜백을 재검토하여 RESET=09, 저주파 보호 설정=53으로 정정했습니다. 아래의 “softstart 조회09” 및 “RESET53” 설명과 그 해석은 현재 동작 설명으로 사용하지 마십시오. 최신 근거: `REVIEW_PROTOCOL_1_0_5.md`, 변경점: `RELEASE_1_0_5_KO.md`.

# 첫 전류 변경 오류 분석 및 수정 — v1.0.2

> v1.0.3 follow-up: four complete JSONL sessions now confirm TX14.5 A, RX12.5 A and the automatic STOP. Subsequent sessions report an active hardware Communication fault; four RESET requests did not clear it. Another write of12.5 A during FAULT returned10.5 A. See `FULL_SESSION_FINDINGS_v1.0.3_KO.md` for current evidence; earlier statements about unavailable TX/post-error logs below describe the previous capture. Current writes are now rejected before transmission when fresh status is faulted or unknown.

대상: 사용자가 제공한 `01-Empower_status_history.txt`, 원본 EXE 정적 분석,
첨부 `334A Rev. A Empower User's Manual`. 분석일: 2026-09-23.

## 확인된 직접 원인

v1.0.1의 설정값 검증과 오류 분류가 잘못되었다. 장비가 정상적으로 응답했는데도
요청한 전류 설정값과 반환된 설정값이 다르다는 이유로 `ProtocolError`를 발생시켰다.
이 예외는 통신 손실 처리로 들어가 STOP을 한 번 보내고 직렬 포트를 닫는다.
원본 XP 프로그램에는 이 즉시 비교 후 STOP/연결 종료 동작이 없다.

이번 로그의 마지막 응답은 RUN, 설정값 12.5 A, 측정값 7.1 A이며 알려진 장비
fault가 없다. 따라서 이 응답을 통신 단절이라고 표시한 것은 잘못이다.
실제 STOP 송신과 이후 장비 상태는 이 파일에 없지만, 오류 문구와 배포한 코드의
실행 경로가 STOP/포트 종료를 특정한다. 물리적 출력 종료 자체는 사용자의 관찰이다.

## 시간 순서

아래 시각은 로그에 기록된 UTC이다. 한국 시각은 9시간을 더한다.

| 시각 | 사용자 동작 / 응답 | 해석 |
|---|---|---|
| 12:50:35 / 12:50:38 | Soft-start 설정 후 `0x69` 응답 | Enabled, 0.5 A/s |
| 12:50:45 | RUN 요청 | 이후 RUN 상태 확인 |
| 12:51:05.442 | Current 8.0 A 요청 | 반환 설정값 8.0 A, 측정값 0.2 A |
| 12:51:06.656–18.152 | 정상 상태 조회 | 측정값 0.7 → 6.2 A로 상승 |
| 12:51:19.191 | Current 14.5 A 요청 | 설정 전 조회: 설정값 8.0 A, 측정값 6.7 A |
| 12:51:19.348–19.365 | `0x11` 응답 분할 수신 | 설정값 12.5 A, 측정값 7.1 A, RUN, fault 없음 |
| 12:51:19.365 | `Operating settings readback differs` | 프로그램이 COMMUNICATION LOST 처리 |

8 A 목표에 대한 실제 측정 전류는 약 0.5 A/s로 상승했다. 마지막 측정값도 7.1 A다.
따라서 실제 전류가 14.5 A까지 올라간 후 과전류로 정지했다고 판단할 증거는 없다.
또한 **설정값 12.5 A와 측정값 7.1 A는 다른 필드**다. 설정값 불일치를 단순히
측정 전류의 soft-start 상승 지연이라고 설명해서도 안 된다.

## 마지막 패킷의 근거

```text
10 02 00 00 1e 11 00 00 00 80 00 64 00 28 00 00
89 34 00 7a 00 7d 00 47 01 47 c9 65 00 be
```

| 0부터 시작하는 byte 위치 | 값 | 의미 |
|---|---|---|
| 5 | 11 | 운전 설정 명령 응답 |
| 7–9 | 00 00 80 | 알려진 fault 없음; 0x80은 underfrequency 보호 활성 표시 |
| 10–11 | 00 64 | 주파수 raw 100, 이전과 동일 |
| 12–13 | 00 28 | 펄스 폭 raw 40, 이전과 동일 |
| 20–21 | 00 7D | 장비 반환 설정 전류 125 / 10 = 12.5 A |
| 22–23 | 00 47 | 측정 전류 71 / 10 = 7.1 A |
| 28 | 00 | RUN |
| 29 | BE | 앞선 byte 합의 하위 8비트와 일치 |

독립적으로 재조립한 706개 RX 프레임은 모두 길이와 가산 체크섬이 정상이다.
이 파일에 **TX는 없다**. 따라서 실제 선로에 14.5 A 패킷이 나갔는지는 확인되지
않았다. 액션 기록과 코드에 따르면 예상 전송 패킷은 아래와 같다.

```text
10 02 00 00 11 01 02 00 00 64 00 28 00 00 00 91 43
```

이는 캡처된 TX가 아니라 소스에서 계산한 예상값이다.

## 12.5 A가 반환된 이유는 아직 미확정

서비스 응답 최대 전류는 25.0 A다. 원본 코드도 그 값을 UI 최대값에 그대로 쓰며,
전류 직렬화는 A × 10의 BE16이다. 해당 경로에서 12.5 A 고정 제한 또는 /2 변환은
확인되지 않았다. 마지막 한 번의 응답만으로 장비 내부 제한, 일시적인 설정 처리,
다른 수락 조건 중 무엇인지 구분할 수 없다. 이 수정은 14.5 A 적용 성공을 뜻하지
않으며, 설정 불일치를 숨기거나 최대 전류·보호 조건을 바꾸지 않는다.

## v1.0.2 변경

- 검증된 응답에서 전류 설정값만 다르고, 반환값이 조회된 최대 전류 범위 내이며,
  상태가 STOP/RUN/COUNTDOWN이고 fault/미해석 고장 bit가 없을 때는 별도 경고로
  처리한다. 이 경고 때문에 STOP을 보내거나 포트를 닫지 않는다.
- 마지막 요청 전류, 현재 장비 설정값, 실제 측정 전류를 따로 표시한다.
  마지막 쓰기 불일치 경고는 새 전류 쓰기가 일치 확인될 때까지 남는다.
- 주기적 상태 조회와 사용자의 STOP을 유지한다. 자동 재전송이나 자동 전류 증가는
  하지 않으며, 경고 시 이미 대기 중인 다른 제어 변경은 취소한다.
- 실제 timeout, checksum 오류, 다른 운전 필드 불일치 등의 기존 실패 처리는 유지한다.
  모든 종류의 설정 차이를 허용하도록 검증을 해제한 수정이 아니다.
- 상태 이력에 RX_BYTES가 잘못 누적되는 필터 문제를 수정했다. 전체 송수신은 계속
  Communication log와 세션 JSONL에 기록한다.

## 지속되는 Connection Fault와 복구

현재 파일은 첫 오류에서 끝난다. 이후 Connection Fault가 장비 COM interlock인지,
프로그램 접속 실패인지 판단할 후속 응답은 없다. 프로그램이 포트를 닫은 뒤 장비가
통신 중단을 감지하여 COM fault를 유지했을 가능성은 있지만, 아직 추론이다.

1. 레이저 정지를 확인하고 키스위치를 OFF로 둔다. 프로그램을 종료한다.
2. 수정 ZIP을 새 폴더에 전체 해제하고 `install_windows.cmd`로 설치한다.
3. serial 연결을 확인한다. 장비 COM fault가 남은 경우 매뉴얼 6-8 및 7-3쪽의
   복구 절차는 제어 소프트웨어 종료 → 전원 공급기 AC OFF → 5초 대기 → AC ON →
   소프트웨어 재시작이다. 일반 종료와 달리 COM fault 해제를 위한 전원 재인가다.
   재기동 후에는 매뉴얼의 준비·온도 조건을 다시 확인한다.
4. `start_windows.cmd`로 수정판을 시작하고, 제어 활성화 전 상태·fault·전류값을
   먼저 확인한다. 여기서 RUN 또는 전류 증가를 자동 실행하지 않는다.
5. 재연결 후에도 오류가 남으면 그 세션 JSONL을 확보한다. 현재 자료만으로 지속되는
   Connection Fault까지 해결됐다고 단정할 수 없다.

12.5 A 응답을 해결하려고 factory maximum, 보정값, 보호 설정을 올리거나 해제할
근거는 없다. 추가 전류 변경의 결과를 판단하려면 전체 TX/RX 기록이 필요하다.

## 필요한 후속 로그

새로 고전류 시험을 반복하기 전에, 이미 저장된 **첫 오류 및 이후 재접속 세션**의
파일부터 확인할 수 있다. Windows 탐색기 주소에 다음을 입력한다.

```text
%LOCALAPPDATA%\EmpowerPython\logs
```

해당 시각의 `*_session.jsonl`을 제공하면 실제 전류 패킷 `... 00 91 ...` 송신 여부,
STOP 송신, 포트 종료, 이후 재접속·fault 상태를 구분할 수 있다. GUI의 Status history는
일반 통신 로그와 다르며, 기존 버전에서는 RX_BYTES가 섞이고 TX가 빠져 있었다.

## 검증 범위

실제 수신 패킷을 사용한 회귀 시험, worker의 경고 후 polling 유지·자동 STOP/재전송
없음·명시적 STOP, 손상 응답 실패 처리, GUI의 독립 전류 표시를 확인했다.
전체 시험 결과는 `TEST_RESULTS.txt`, 상세 범위는 `VALIDATION.md`를 참조한다.
수정판의 실제 Empower 및 Windows 10/11 실행은 아직 검증하지 않았다.

자동 시험 총 **71개 통과**. `current_mismatch_ui_v1.0.2.png`는 합성 화면 예시이며 실장비 화면 캡처가 아니다.
