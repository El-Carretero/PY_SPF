@echo off
setlocal
pushd "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Empower Python Control is not installed in this folder.
    echo Run install_windows.cmd first, then run this file again.
    popd
    pause
    exit /b 1
)

".venv\Scripts\python.exe" -m empower %*
set "EMPOWER_EXIT_CODE=%ERRORLEVEL%"
if not "%EMPOWER_EXIT_CODE%"=="0" (
    echo.
    echo Empower Python Control exited with an error. Details are shown above.
    echo If dependencies are missing, run install_windows.cmd again.
    pause
)
popd
exit /b %EMPOWER_EXIT_CODE%
