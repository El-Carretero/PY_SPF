@echo off
setlocal
pushd "%~dp0"
echo Empower Python Control - optional Windows executable build
echo Run this script on 64-bit Windows after install_windows.cmd succeeds.
echo.

if not exist ".venv\Scripts\python.exe" (
    echo Missing Python environment. Run install_windows.cmd first.
    goto failed
)
if not exist "launcher.py" (
    echo Missing launcher.py. Extract the complete distribution first.
    goto failed
)
".venv\Scripts\python.exe" -c "import sys,struct; assert sys.platform == 'win32', 'Build on Windows'; assert struct.calcsize('P') == 8, '64-bit Python required'"
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install "pyinstaller>=6,<7"
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --windowed --onedir --name EmpowerPython launcher.py
if errorlevel 1 goto failed

echo.
echo Built: dist\EmpowerPython\EmpowerPython.exe
echo Copy the ENTIRE dist\EmpowerPython folder, including _internal.
echo This is a local build, not a signed or hardware-validated release.
popd
pause
exit /b 0

:failed
echo.
echo Build failed. Read the error above before closing this window.
popd
pause
exit /b 1
