@echo off
setlocal
pushd "%~dp0"
echo Empower Python Control 1.0.5 - Windows installation
echo A 64-bit Python 3.10 or later and an Internet connection are required.
echo.

where py >nul 2>nul
if errorlevel 1 (
    set "EMPOWER_PY_CMD=python"
) else (
    set "EMPOWER_PY_CMD=py -3"
)

%EMPOWER_PY_CMD% -c "import sys, struct; print('Python:', sys.version); assert sys.version_info >= (3,10), 'Python 3.10+ required'; assert struct.calcsize('P') == 8, '64-bit Python required'"
if errorlevel 1 goto python_failed

if not exist ".venv\Scripts\python.exe" (
    %EMPOWER_PY_CMD% -m venv .venv
    if errorlevel 1 goto failed
)

".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -c "import sys, struct, PySide6, serial; assert sys.version_info >= (3,10); assert struct.calcsize('P') == 8; print('Installed: Python', sys.version.split()[0], 'PySide6', PySide6.__version__, 'pyserial', serial.__version__)"
if errorlevel 1 goto failed

echo.
echo Installation complete. Run start_demo.cmd first, or start_windows.cmd.
popd
pause
exit /b 0

:python_failed
echo.
echo Python was not found or is unsupported.
echo Install 64-bit Python 3.10 or later, including the Python launcher.
echo Then run this installer again. See README_KO.md.
goto failed

:failed
echo.
echo Installation failed. Read the error above before closing this window.
popd
pause
exit /b 1
