@echo off
setlocal
pushd "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Run install_windows.cmd first.
 popd
 pause
 exit /b 1
)
set "QT_QPA_PLATFORM=offscreen"
".venv\Scripts\python.exe" -m unittest discover -s tests -v
set "EMPOWER_TEST_EXIT=%ERRORLEVEL%"
popd
pause
exit /b %EMPOWER_TEST_EXIT%
