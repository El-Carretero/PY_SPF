# Third-party notices

This package contains newly written Python code and analysis of user-supplied
files. It does not include the original Empower executable, CVI runtime, logos,
installer, manufacturer manual or firmware.

Empower and Spectra-Physics product names identify the equipment being
interfaced; this is an independent implementation and does not imply vendor
approval or support.

Dependencies are installed separately. Their own licenses and notices apply:

- PySide6 / Qt for Python: https://doc.qt.io/qtforpython-6/licenses.html
- pySerial: https://github.com/pyserial/pyserial
- Optional PyInstaller: https://pyinstaller.org/

If distributing a locally built executable, retain all dependency licenses,
notices and runtime components required by those dependencies. This source
package includes no prebuilt Windows executable.
