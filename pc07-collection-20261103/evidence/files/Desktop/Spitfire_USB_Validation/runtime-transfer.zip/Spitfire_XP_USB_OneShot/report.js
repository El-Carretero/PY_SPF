/* JScript 5.6 local report renderer loaded by RUN.hta. */
function html(s){return (''+s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function utf8(p,s){var a=new ActiveXObject('ADODB.Stream');a.Type=2;a.Charset='utf-8';a.Open();a.WriteText(s);a.SaveToFile(p,2);a.Close();}
function makeReport(r){
 var s=r.capture||{},h='<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><title>Spitfire 시험 결과</title><style>body{font-family:Arial,sans-serif;margin:30px;max-width:1100px;color:#172536}table{border-collapse:collapse;width:100%;margin:12px 0}td,th{border:1px solid #ccd5de;padding:7px;text-align:left}th{background:#e8eff6}code{word-break:break-all}</style></head><body><h1>Spitfire 1회 자동시험 결과</h1>';
 h+='<p><b>'+html(r.outcome)+'</b> '+html(r.reason||'허용한 화면 탐색과 양방향 패킷 기록을 완료했습니다.')+'</p>';
 h+='<p>종료 시각: '+html(r.completed_utc)+' (XP 시계 기준 UTC). 이 보고서는 통신 상대가 실물인지 시뮬레이터인지 자동으로 판정하지 않습니다. 연결된 상대의 응답을 그대로 기록합니다.</p>';
 h+='<h2>캡처</h2><p>원본 송신 '+html(s.command_packets||0)+' / 상대 응답 '+html(s.response_packets||0)+' 패킷. 관찰한 상대 쌍 '+html(s.observed_pairs||0)+'. PCAP 구조 검사: '+html(s.pcap_validation_ok===true?'통과':'미확인 또는 실패')+'.</p>';
 h+='<p>IP: '+html(s.command_src_ip||'?')+' → '+html(s.controller_ip||'?')+'. 상태 변경 명령 감지 '+html(s.any_write_commands||0)+'. 드라이버 보고 드롭 '+html(s.capture_drops||0)+'.</p>';
 h+='<p><a href="capture/summary.json">상세 캡처 요약</a> · <a href="capture/packets.jsonl">원본 페이로드 기록</a> · <a href="timeline.jsonl">동작 타임라인</a> · <a href="result.json">전체 결과 JSON</a></p><ul>';
 var ad=s.adapters||[],i,t;for(i=0;i<ad.length;i++)if(ad[i].opened)h+='<li><a href="capture/adapter-'+pad(ad[i].interface_id)+'.pcap">adapter-'+pad(ad[i].interface_id)+'.pcap</a>: '+html(ad[i].frames)+' 프레임</li>';h+='</ul>';
 h+='<h2>화면 시험</h2><table><tr><th>동작</th><th>시작 / 종료 (UTC)</th><th>결과</th><th>증거</th></tr>';
 for(i=0;i<r.actions.length;i++){var a=r.actions[i],d='actions/'+pad(i+1)+'-'+a.mode;h+='<tr><td>'+html(a.mode)+'</td><td>'+html(a.start)+'<br>'+html(a.end)+'</td><td>'+html(a.exit_code===0&&a.result&&a.result.exit_code===0&&a.result.emp_optout===1&&a.result.original_pid===r.preflight.original_pid&&a.result.original_left_running===true?'완료':('중지/미완료 '+a.exit_code))+'</td><td><a href="'+d+'/timeline.jsonl">동작 기록</a> · <a href="'+d+'/desktop-before.bmp">시작 화면</a> · <a href="'+d+'/desktop-after.bmp">종료 화면</a></td></tr>';}h+='</table>';
 h+='<h2>조회와 주기 통신</h2><p>각 UDP 패킷의 첫 번째 프로토콜 메시지를 기준으로 집계했습니다. 아래 주기는 해당 실행 구간에서 관찰한 값이며 실물 컨트롤러의 보장 사양을 뜻하지 않습니다.</p><table><tr><th>태그</th><th>방향</th><th>수</th><th>평균 / 최소 / 최대 간격 (ms)</th></tr>';
 t=s.tag_statistics||[];for(i=0;i<t.length;i++){var z=t[i];h+='<tr><td>'+html(z.tag)+'</td><td>'+html(z.kind)+'</td><td>'+html(z.count)+'</td><td>'+(z.periods_valid===false?'시계 역행으로 주기 미확인':html(z.mean_interval_us/1000)+' / '+html(z.min_interval_us/1000)+' / '+html(z.max_interval_us/1000))+'</td></tr>';}h+='</table>';
 h+='<h2>시험 범위와 제외 항목</h2><p>현재 화면, Temperature Control, Timing and High Voltage, Active Faults, Empower Setup, Help/About와 검증된 regensvc 서비스 표시를 확인합니다. 설정 입력이나 장비 명령 버튼은 누르지 않습니다. 원본 프로그램 시작·종료·재시작·재접속, Laser RUN/ON/OFF, HV, 온도와 파라미터 편집, Opt-out 변경, fault reset, interlock 우회, 출처가 불명확한 버튼은 제외했습니다.</p>';
 h+='<p>시작 시 Opt-out이 OFF이면 자동으로 켜지 않고 화면 시험을 건너뜁니다. 버전·창·통신 검증이 실패하면 이후 입력을 중지합니다. 상태 변경 패킷 감지는 이미 전송된 명령을 차단하지 않으며, 중지 버튼도 레이저를 정지시키지 않습니다. 원본 프로그램은 계속 실행됩니다.</p>';
 h+='<p>서비스 표시 중 중단되면 사용자 표시 복원이 생략될 수 있습니다. 위 동작 목록의 user 결과와 actions 폴더의 원본 상태 기록으로 확인하세요.</p>';
 h+='<p><a href="app/docs/CONTROLS.csv">컨트롤별 허용·제외 목록</a> · <a href="app/docs/README-KO.txt">실행 안내</a> · <a href="app/docs/capture-dependency-provenance.json">캡처 도구 출처·버전·무결성</a></p></body></html>';
 utf8(root+'\\REPORT.html',h);
}
