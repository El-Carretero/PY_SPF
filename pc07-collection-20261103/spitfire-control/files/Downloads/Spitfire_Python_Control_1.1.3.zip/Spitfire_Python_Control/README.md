# Spitfire Python Control 1.1.3

Spectra-Physics Spitfire/Empower 구형 GUI 1.6.0을 분석해 Python으로 다시
구현한 독립 실행형 제어·진단 프로그램입니다. 원본 NI LabWindows/CVI
runtime이나 COM/ActiveX 구성요소가 필요하지 않습니다.

가장 중요한 사실은 원본 화면의 `COM1 / 19200` 흔적과 달리 실제 장비
통신이 **UDP**였다는 점입니다. 원본은 로컬 UDP 1024 포트를 열고
`10.19.70.13:1024`로 ECLIPSE 명령을 전송합니다. 이 구현은 그 주소를
기본값으로 보존하되 모두 설정 가능하게 했습니다.


1.1.3은 Automatic polling과 독립된 연결 확인, 온도·습도 조회 주기 2배,
DISARM ↔ ARM 토글 버튼을 추가합니다. 문구 입력 없이 버튼으로 ARM을 전환합니다.
변경 사항은 [docs/CHANGELOG_1_1_3.md](docs/CHANGELOG_1_1_3.md)를 참고하십시오.

1.1.2는 Windows/시뮬레이터 자동 점검과 조회 전용 장비 검증을 추가합니다.
사용 방법은 [docs/AUTOMATED_VALIDATION.md](docs/AUTOMATED_VALIDATION.md),
변경 내역은 [docs/CHANGELOG_1_1_2.md](docs/CHANGELOG_1_1_2.md)를 참고하십시오.

1.1.1에서 원본 대조 검토로 확인된 통신·상태·GUI 결함을 수정했습니다.
변경 이유와 원본 주소 근거는 [docs/CHANGELOG_1_1_1.md](docs/CHANGELOG_1_1_1.md)에 있습니다.

- Q-switch 주파수: 일반 GUI는 Hz, Programmer console은 raw wire 단위입니다.
  일반 GUI 1,000 Hz는 wire argument `100.00`으로 전송됩니다.
- 입력값은 polling으로 덮어쓰지 않습니다. 각 숫자 설정의 Readback과
  USE READBACK으로 실제 조회값을 확인하고 불러올 수 있습니다.
- STOP/OFF는 대기 중 위험 명령을 취소하고 우선 처리하며 자동 DISARM합니다.
- Timeout/오래된 상태도 DISARM합니다. 다시 ARM하려면 정상 조회 응답이 필요합니다.
- HV ON/OFF 표시는 명령 ACK가 아닌 실제 readback으로 결정합니다.

## 포함 기능

- 원본의 패널명·통신 상태등·RUN/STOP 흐름을 살린 밝은 계측기형 GUI
- 원본의 9개 panel 기능을 7개 통합 tab으로 재구성
- Empower current, Q-switch frequency/pulse width/source와 실시간 readback
- TDG trigger/oscillator, 5-channel delay, BWD, dual-channel HV 설정/측정
- TCU temperature, humidity, TEC, service opt-out/override
- Empower/TDG/TCU/통신 fault 표시와 raw fault word 보존
- Amplifier motor forward/reverse/jog/stop/speed
- 전체 146개 복원 command ID를 탐색·전송하는 진단 console
- 별도 문구 입력으로 잠그는 Empower service/calibration 화면
- `Ctrl+Shift+R`로 여는 독립 raw RS-232 서비스 터미널
- RS-232 ASCII/HEX 송신, line ending, DTR/RTS, flow control, 양방향 byte log
- wire/audit CSV와 선택적 상태 CSV logging
- 하드웨어 없이 동작하는 deterministic simulator
- 하드웨어 write ARM, 위험 명령 재확인, newline injection 차단

## 바로 실행

Python 3.10 이상이 필요합니다. python.org의 Windows Python에는 Tk가
기본 포함됩니다. RS-232 기능은 pySerial 3.5를 사용하며, 인터넷이 없는
장비 PC에서도 설치할 수 있도록 wheel을 `release/vendor`에 포함했습니다.

```powershell
py -m pip install --no-index --find-links release\vendor pyserial
py run_spitfire.py
```

또는 설치 후 어느 디렉터리에서나 실행할 수 있습니다.

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install --no-index --find-links release\vendor release\spitfire_control-1.1.3-py3-none-any.whl
spitfire-control
```

Linux/macOS에서도 Python에 Tk가 설치돼 있으면 동일하게 실행됩니다.

```bash
python3 -m pip install --user release/vendor/pyserial-3.5-py2.py3-none-any.whl
python3 run_spitfire.py
```

처음에는 항상 **Simulator**로 시작하며 네트워크 packet을 전혀 보내지
않습니다.

## 실제 장비 연결

먼저 `py validate_spitfire.py offline`으로 자동 점검할 수 있습니다.
조회 전용 장비 검사까지 수행하려면 `py validate_spitfire.py hardware --host 10.19.70.13`을
실행합니다. 실제 주소를 확인하고 원본 GUI 등 UDP 포트 1024를 쓰는 프로그램은 닫으십시오.
장비 검증은 오프라인 필수 검사가 통과한 뒤에만 시작하며, 출력·HV·모터·설정 변경 명령을 보내지 않습니다.
결과는 `validation_reports/<실행별 폴더>/report.html`에 저장됩니다.

1. `File → Connection Settings`에서 mode를 `udp`로 바꿉니다.
2. legacy 기본값은 remote `10.19.70.13:1024`, local `0.0.0.0:1024`입니다.
3. ARM을 켜지 않은 상태로 identity/version/temperature 같은 read-only
   응답부터 검증합니다.
4. 상단 버튼은 기본 `DISARM`입니다. 실제 write가 필요할 때 누르면 `ARM`,
   다시 누르면 `DISARM`으로 전환됩니다. ARM 문구 입력창은 없습니다.
5. RUN은 별도로 `RUN` 입력과 마지막 확인이 필요합니다.

자세한 단계는 [docs/COMMISSIONING.md](docs/COMMISSIONING.md)를 따르십시오.
소프트웨어의 `SOFTWARE STANDBY`는 네트워크 명령일 뿐 물리적 emergency
stop이나 fail-safe가 아닙니다.

## Automatic polling과 연결 확인

- 체크박스를 꺼도 컨트롤러 식별 조회 `[1000]*idn?`를 주기적으로 전송합니다.
  연결 확인 완료 후 1초 간격이며, 응답 대기 시간은 별도입니다. 정상 응답이
  계속되는 동안 Automatic polling 해제만으로 연결이나 ARM이 해제되지 않습니다.
- Automatic polling은 측정·상태·fault의 반복 조회를 켜고 끕니다.
  꺼도 초기 조회, 수동 REFRESH, 명령 후 readback, 연결 확인은 동작합니다.
- 온도·습도(결정 온도, 습도, LBO 온도, TEC 온도)는 두 번의 poll cycle마다
  한 번 조회합니다. 다른 항목의 poll slot은 유지합니다. 설정상 기본 1초 cycle에서는
  온도·습도 목표 주기가 2초이며, 실제 간격에는 통신·스케줄링 지연이 더해집니다.
- 연결 확인은 메인 컨트롤러 응답만 검증합니다. Automatic polling을 끄면
  갱신되지 않는 측정값·하위 모듈 상태·fault는 시간이 지나면 `—` 또는
  unknown으로 표시됩니다. REFRESH로 필요한 값을 조회할 수 있습니다.
- 연결 실패·응답 timeout·STOP/OFF·재연결에서는 기존처럼 DISARM합니다.
  통신이 회복되어도 자동 ARM하지 않습니다. DISARM은 쓰기 권한 잠금이며,
  레이저 OFF 명령이 아닙니다.

## Raw RS-232 서비스 모드

어느 화면에서나 `Ctrl+Shift+R`을 누르거나
`Service → Raw RS-232 Terminal`을 선택하면 별도 터미널이 열립니다.
안전 경고를 확인한 뒤
포트와 통신 조건을 고르고 `CONNECT`를 눌러야 실제 포트가 열립니다.
기본값은 원본 화면에 남아 있던 `COM1`, `19200`, `8-N-1`입니다.

- ASCII 또는 HEX byte 송신
- `NONE`, `CR`, `LF`, `CRLF` line ending 선택
- 수신·송신 byte를 시간, HEX, printable ASCII로 동시 표시
- DTR/RTS와 XON/XOFF, RTS/CTS, DSR/DTR flow control
- 원문 byte log 저장

이 터미널은 정상 제어용 UDP/ECLIPSE 경로와 코드 수준에서 분리되어
있습니다. 특히 raw 송신에는 command 검증, ARM, 위험 명령 확인이
적용되지 않으므로 출력이 물리적으로 차단된 점검 환경에서만 사용하십시오.
서비스 모드의 존재가 원본 1.6.0의 주 통신 경로가 RS-232였다는 의미는
아닙니다.

## Windows 단일 EXE 만들기

PowerShell에서 다음을 실행합니다.

```powershell
.\build_windows.ps1
```

결과는 `dist\SpitfirePythonControl.exe`입니다. 빌드에만 PyInstaller가
필요합니다. 빌드 스크립트는 포함된 pySerial wheel을 먼저 설치합니다.

## 테스트

```powershell
$env:PYTHONPATH = "src"
py -m unittest discover -s tests -v
```

Linux/macOS:

```bash
PYTHONPATH=src python3 -m unittest discover -s tests -v
```

## 구조

```text
src/spitfire_control/
  commands.py      recovered command catalogue and risk classification
  protocol.py      exact CMD_ECLIPSE / REPLY_ECLIPSE wire codec
  transport.py     UDP hardware transport and safe simulator
  controller.py    worker, queue, polling, audit and write interlock
  serial_service.py raw RS-232 byte transport and codec
  serial_dialog.py standalone RS-232 service terminal
  state.py         lossless raw state plus conservative typed decoding
  ui.py            complete Tk operator GUI
docs/
  PROTOCOL.md      reverse-engineered protocol evidence and uncertainties
  COMMISSIONING.md staged hardware-validation procedure
  REVERSE_ENGINEERING_REPORT.md binary/resource analysis and implementation scope
  command_catalog.csv all 146 recovered query/write commands
tests/             protocol, simulator, state and safety regression tests
```

## 제한과 안전

Controller firmware별 status bit와 일부 service/delay argument는 실제
packet capture 및 해당 장비 service manual로 확인해야 합니다. 이 구현은
알 수 없는 값을 추정해서 버리지 않고 raw reply를 유지합니다. 원본 binary나
NI runtime은 포함하지 않았습니다. 자세한 법적 고지는 `NOTICE.md`에 있습니다.
