"""Persistent user settings."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import os
from pathlib import Path


@dataclass(slots=True)
class AppConfig:
    mode: str = "simulator"
    remote_host: str = "10.19.70.13"
    remote_port: int = 1024
    local_host: str = "0.0.0.0"
    local_port: int = 1024
    timeout_seconds: float = 2.0
    poll_interval_seconds: float = 1.0
    auto_poll: bool = True
    monitor_hv: bool = False
    log_directory: str = ""

    @staticmethod
    def config_path() -> Path:
        if os.name == "nt":
            base = Path(os.environ.get("APPDATA", Path.home()))
        else:
            base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
        return base / "spitfire-control" / "config.json"

    @classmethod
    def load(cls, path: Path | None = None) -> "AppConfig":
        path = path or cls.config_path()
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            return cls()
        known = {name for name in cls.__dataclass_fields__}
        return cls(**{key: value for key, value in raw.items() if key in known})

    def save(self, path: Path | None = None) -> None:
        path = path or self.config_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
        temp.replace(path)

