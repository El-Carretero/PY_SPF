"""Controller state model and conservative reply decoding."""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
import re
import math
from typing import Any

from .protocol import Reply


NUMERIC_IDS = {
    1007, 1008, 1009, 1010, 1011, 1012, 1013, 1015, 1018, 1019,
    1021, 1024, 1025, 1028, 1029, 1030, 1031, 1032, 1033, 1039,
    1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049,
    1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1060, 1061,
    1065, 1066, 1067, 1068, 1069, 1077, 1078, 1080, 1084, 1085,
    1086, 1087, 1088, 1089,
}

FIELD_IDS = {
    "diode_current_measured": 1007,
    "output_power": 1008,
    "diode_current_set": 1009,
    "qsw_frequency": 1010,
    "qsw_pulse_width": 1011,
    "qsw_source": 1012,
    "empower_status": 1013,
    "head_status": 1015,
    "tdg_status": 1019,
    "high_voltage_on": 1021,
    "oscillator_frequency": 1024,
    "divisor": 1025,
    "ecu_status": 1028,
    "ecu_health": 1029,
    "crystal_temperature": 1030,
    "humidity": 1031,
    "temperature_set": 1032,
    "ecu_opt_out": 1033,
    "hv1_set": 1040,
    "hv2_set": 1041,
    "hv1_measured": 1042,
    "hv2_measured": 1043,
    "humidity_override": 1044,
    "oscillator_mode": 1050,
    "trigger_mode": 1051,
    "trigger_frequency": 1053,
    "hv1_current": 1055,
    "hv2_current": 1056,
    "motor_speed": 1060,
    "measured_oscillator_frequency": 1065,
    "empower_opt_out": 1068,
    "compressor_opt_out": 1069,
    "lbo_temperature": 1077,
    "tec_temperature": 1084,
    "system_status": 1085,
    "communication_status": 1089,
}


def _number(value: str) -> int | float | str:
    stripped = value.strip()
    try:
        if re.fullmatch(r"[-+]?\d+", stripped):
            return int(stripped)
        if re.fullmatch(r"[-+]?0[xX][0-9a-fA-F]+", stripped):
            sign = -1 if stripped.startswith("-") else 1
            unsigned = stripped.lstrip("+-")
            return sign * int(unsigned, 16)
        number = float(stripped)
        return number if math.isfinite(number) else value
    except ValueError:
        return value


def is_error_reply(value: str) -> bool:
    return bool(re.match(r"^(?:ERR(?:OR)?|NACK|FAIL(?:ED)?)(?:\b|[:;,])", value.strip(), re.I))


@dataclass(frozen=True, slots=True)
class DelayState:
    value: float | None = None
    switch: str | None = None
    bwd: str | None = None
    enable: str | None = None


def decode_delay(value: str) -> DelayState:
    """Keep mode flags and the legacy six-prefix-field numeric value separate.

    _gextHandleReceivedMsg (1045..1049) searches OFF/NBWD/NENA;
    _decodenum at 0x40FE1E extracts the number after six spaces.
    A bare number is also accepted, without inventing mode flags.
    """
    tokens = value.upper().split()
    def flag(choices):
        found = [t for t in tokens if t in choices]
        return found[0] if len(found) == 1 else None
    number = None
    candidate = value.strip() if len(tokens) == 1 else " ".join(tokens[6:])
    if candidate:
        try:
            number = float(candidate.split()[0])
            if not math.isfinite(number):
                number = None
        except ValueError:
            pass
    return DelayState(number, flag({"ON", "OFF"}), flag({"BWD", "NBWD"}), flag({"ENA", "NENA"}))


# The original module decoders use MSB(status) & 8 as communication error.
MODULE_QUERY_IDS = {"EMPOWER": 1013, "TDG": 1019, "TCU": 1028, "COMPRESSOR": 1015}
MODULE_OPTOUT_IDS = {"EMPOWER": 1068, "TCU": 1033, "COMPRESSOR": 1069}


@dataclass(slots=True)
class DeviceState:
    values: dict[int, Any] = field(default_factory=dict)
    raw_values: dict[int, str] = field(default_factory=dict)
    updated_at: dict[int, datetime] = field(default_factory=dict)
    delays: dict[int, DelayState] = field(default_factory=dict)
    invalid_ids: set[int] = field(default_factory=set)
    pending_readbacks: set[int] = field(default_factory=set)
    fault_words: tuple[int, ...] = ()
    last_reply_at: datetime | None = None
    last_error: str = ""
    connected: bool = False
    transport_open: bool = False
    transport_name: str = "Disconnected"
    armed: bool = False
    stale_after_seconds: float = 5.0

    def copy(self) -> "DeviceState":
        return replace(self, values=dict(self.values), raw_values=dict(self.raw_values),
                       updated_at=dict(self.updated_at), delays=dict(self.delays),
                       invalid_ids=set(self.invalid_ids), pending_readbacks=set(self.pending_readbacks))

    def apply(self, reply: Reply) -> bool:
        now = datetime.now(timezone.utc)
        cid = reply.command_id
        self.raw_values[cid] = reply.value
        # ACK text is diagnostic data, never a substitute for a query readback.
        if cid >= 2000:
            self.values[cid] = reply.value
            return reply.value.strip().upper() in {"OK", "ACK"}
        if is_error_reply(reply.value) or not reply.value.strip():
            self.invalid_ids.add(cid)
            return False
        valid = True
        if cid == 1014:
            tokens = reply.value.split()
            valid = len(tokens) == 4 and all(re.fullmatch(r"\d+", t) for t in tokens)
            if valid:
                self.fault_words = tuple(int(t) for t in tokens)
                self.values[cid] = self.fault_words
        elif 1045 <= cid <= 1049 or cid in {1058, 1059, 1063, 1064}:
            channel = {1058: 1, 1059: 2, 1063: 1, 1064: 2}.get(cid, cid - 1044)
            delay = decode_delay(reply.value)
            self.delays[channel] = delay
            self.values[cid] = delay.value
            valid = delay.value is not None
        elif cid in NUMERIC_IDS:
            number = _number(reply.value)
            if isinstance(number, (float, int)):
                valid = math.isfinite(number)
                # Legacy readback: nonnegative EMP:QSW:PRF? units are 10 Hz.
                self.values[cid] = number * 10 if cid == 1010 and number >= 0 else number
            elif cid in {1050, 1051, 1080}:
                modes = {"INT": 0, "EXT": 1} if cid != 1080 else {"CONT": 0, "COUNT": 1, "COUNT 1": 2}
                valid = reply.value.strip().upper() in modes
                self.values[cid] = modes.get(reply.value.strip().upper())
            else:
                valid = False
        else:
            self.values[cid] = reply.value
        if not valid:
            self.invalid_ids.add(cid)
            return False
        self.invalid_ids.discard(cid)
        self.pending_readbacks.discard(cid)
        self.updated_at[cid] = now
        self.last_reply_at = now
        aliases = {1061: 1021, 1067: 1050, 1058: 1045, 1059: 1046, 1063: 1045, 1064: 1046}
        if cid in aliases:
            target = aliases[cid]
            self.values[target] = self.values[cid]
            self.updated_at[target] = now
            self.invalid_ids.discard(target)
            self.pending_readbacks.discard(target)
        return True

    def value(self, command_id: int, default: Any = None) -> Any:
        if command_id in self.invalid_ids or command_id in self.pending_readbacks:
            return default
        return self.values.get(command_id, default)

    def field(self, name: str, default: Any = None) -> Any:
        return self.value(FIELD_IDS[name], default)

    def link_fresh(self, now: datetime | None = None) -> bool:
        now = now or datetime.now(timezone.utc)
        return bool(self.connected and self.last_reply_at is not None and
                    (now - self.last_reply_at).total_seconds() <= self.stale_after_seconds)

    def is_fresh(self, command_id: int, now: datetime | None = None) -> bool:
        now = now or datetime.now(timezone.utc)
        stamp = self.updated_at.get(command_id)
        return bool(self.link_fresh(now) and stamp is not None and
                    command_id not in self.invalid_ids and command_id not in self.pending_readbacks and
                    (now - stamp).total_seconds() <= self.stale_after_seconds)

    def communication_state(self, name: str) -> str:
        if not self.transport_open:
            return "off"
        if not self.link_fresh():
            return "fault" if self.last_reply_at is not None else "unknown"
        if name == "MAIN":
            return "ok"
        opt = MODULE_OPTOUT_IDS.get(name)
        if opt is not None and self.value(opt) == 1:
            return "off"
        cid = MODULE_QUERY_IDS[name]
        if not self.is_fresh(cid):
            return "unknown"
        status = self.value(cid)
        if not isinstance(status, (int, float)) or status < 0 or int(status) != status:
            return "unknown"
        return "fault" if int(status) & 0x800 else "ok"

    @property
    def fault_active(self) -> bool:
        return self.is_fresh(1014) and any(word != 0 for word in self.fault_words)

    @property
    def laser_on(self) -> bool | None:
        value = self.value(1013)
        if self.is_fresh(1013) and isinstance(value, (int, float)) and value >= 0:
            return bool(int(value) & 1)
        return None

    @property
    def high_voltage(self) -> bool | None:
        value = self.value(1021)
        if self.is_fresh(1021) and value in (0, 1):
            return bool(value)
        return None


FAULT_LABELS = (
    "Empower: array open", "Empower: kill switch", "Empower: array overtemperature",
    "Empower: checksum", "Empower: overvoltage", "Empower: driver overtemperature",
    "Empower: overpower", "TDG: key interlock", "TDG: relay", "TDG: system",
    "Main communication", "TDG: user interlock", "Empower: VSWR",
    "Empower: underfrequency", "Empower: protection", "Empower communication",
    "TDG: head interlock", "Empower: keyswitch", "Empower: overcurrent",
    "Empower: Q-switch under-temperature", "TCU: humidity latch",
    "TCU: TEC overtemperature", "Empower: cover", "Empower: water flow",
    "TDG communication", "TCU communication", "Empower: LBO under-temperature",
    "Empower: LBO stability",
)

# Exact SetCtrlVal destinations observed in the legacy 1.6.0 EMP:FAULT?
# decoder and correlated with UIR control tags.  Unlisted indicators are driven
# by other module-status decoders whose firmware bit layouts remain uncertain.
FAULT_WORD_BITS = {
    0: (1, 0x10),   # array open
    3: (1, 0x08),   # checksum
    5: (0, 0x08),   # driver overtemperature
    11: (0, 0x40),  # TDG user interlock
    12: (1, 0x02),  # VSWR
    13: (0, 0x10),  # underfrequency
    14: (2, 0x10),  # protection
    16: (1, 0x20),  # TDG head interlock
    17: (1, 0x04),  # keyswitch
    18: (0, 0x20),  # overcurrent
    21: (1, 0x40),  # TEC overtemperature
    22: (1, 0x80),  # cover/door
    25: (2, 0x02),  # TCU communication
    26: (3, 0xFF),  # LBO under-temperature code/nonzero flag
}
