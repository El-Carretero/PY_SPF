"""Spitfire Python Control."""

__version__ = "1.1.3"
