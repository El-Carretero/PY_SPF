﻿검증 자료 — 실행 프로그램은 별도 Spitfire_XP_USB_OneShot_v1_1.zip입니다.

docs/VALIDATION.txt에 최종 성공 회차를 표시했습니다.
evidence/sessions에는 수정 전 부분 종료 회차도 포함됩니다.
각 회차의 result.json을 기준으로 구분하세요. 실패 회차를 성공으로 집계하지 않습니다.

원본 BMP 화면, PCAP 프레임, JSONL 타임라인은 변환하지 않았습니다.
시험 대상은 p07의 별도 VMware XP 사본과 격리 시뮬레이터입니다.
실물 제어 PC와 실물 컨트롤러의 동작을 검증한 자료가 아닙니다.
