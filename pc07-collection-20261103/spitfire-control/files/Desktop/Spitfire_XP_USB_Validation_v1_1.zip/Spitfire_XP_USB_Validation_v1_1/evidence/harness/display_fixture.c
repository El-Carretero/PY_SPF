/* Isolated VMware validation helper. Never part of the USB release. */
#define WINVER 0x0501
#define _WIN32_WINNT 0x0501
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <iphlpapi.h>
#include <shellapi.h>
typedef struct f FILE;
__declspec(dllimport) FILE* __cdecl fopen(const char*,const char*);
__declspec(dllimport) int __cdecl fclose(FILE*);
__declspec(dllimport) int __cdecl fprintf(FILE*,const char*,...);
__declspec(dllimport) int __cdecl strcmp(const char*,const char*);
__declspec(dllimport) size_t __cdecl strlen(const char*);
__declspec(dllimport) int __cdecl _wcsicmp(const wchar_t*,const wchar_t*);
static int isolated_guest(void){
 unsigned char buf[8192];ULONG n=sizeof(buf);IP_ADAPTER_INFO *p;int match=0,other=0;
 if(GetAdaptersInfo((IP_ADAPTER_INFO*)buf,&n)!=ERROR_SUCCESS)return 0;
 for(p=(IP_ADAPTER_INFO*)buf;p;p=p->Next){IP_ADDR_STRING *a;for(a=&p->IpAddressList;a;a=a->Next){
 if(!strcmp(a->IpAddress.String,"0.0.0.0"))continue;
 if(!strcmp(a->IpAddress.String,"10.19.70.2")&&p->AddressLength==6&&p->Address[0]==0&&p->Address[1]==12&&p->Address[2]==41&&p->Address[3]==209&&p->Address[4]==3&&p->Address[5]==153)match++;else other++;
 }}return match==1&&!other;
}
static int original_absent(void){HANDLE h;PROCESSENTRY32W p;int absent=1;
 h=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(h==INVALID_HANDLE_VALUE)return 0;ZeroMemory(&p,sizeof(p));p.dwSize=sizeof(p);
 if(!Process32FirstW(h,&p)){CloseHandle(h);return 0;}do{if(!_wcsicmp(p.szExeFile,L"Spitfire.exe"))absent=0;}while(Process32NextW(h,&p));CloseHandle(h);return absent;
}
static void describe(const char* path,const char* mode,NONCLIENTMETRICSW *m,int rc,DWORD err){
 FILE*f=fopen(path,"wb");char face[256];int i;if(!f)return;
 WideCharToMultiByte(CP_UTF8,0,m->lfMenuFont.lfFaceName,-1,face,sizeof(face),0,0);
 fprintf(f,"{\"fixture_only\":true,\"mode\":\"%s\",\"code\":%d,\"error\":%lu,\"menu_height\":%d,\"menu_width\":%d,\"font_height\":%ld,\"font_weight\":%ld,\"font_charset\":%u,\"font_face\":\"%s\",\"ncm_size\":%u,\"screen_width\":%d,\"screen_height\":%d,\"original_absent\":%s}\n",mode,rc,(unsigned long)err,m->iMenuHeight,m->iMenuWidth,m->lfMenuFont.lfHeight,m->lfMenuFont.lfWeight,m->lfMenuFont.lfCharSet,face,(unsigned)sizeof(*m),GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN),original_absent()?"true":"false");
 (void)i;fclose(f);
}
static int run(int argc,wchar_t**args){NONCLIENTMETRICSW m;char mode[32],out[MAX_PATH];HANDLE h;DWORD n=0,err=0;int rc=0;
 if(argc!=4)return 2;
 WideCharToMultiByte(CP_ACP,0,args[1],-1,mode,sizeof(mode),0,0);WideCharToMultiByte(CP_ACP,0,args[3],-1,out,sizeof(out),0,0);
 if(!isolated_guest())return 10;
 ZeroMemory(&m,sizeof(m));m.cbSize=sizeof(m);if(!SystemParametersInfoW(SPI_GETNONCLIENTMETRICS,sizeof(m),&m,0))return 11;
 if(!strcmp(mode,"read")){describe(out,mode,&m,0,0);return 0;}
 if(!original_absent()){describe(out,mode,&m,12,0);return 12;}
 if(!strcmp(mode,"tahoma")){
  h=CreateFileW(args[2],GENERIC_WRITE,0,0,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,0);if(h==INVALID_HANDLE_VALUE)return 13;
  if(!WriteFile(h,&m,sizeof(m),&n,0)||n!=sizeof(m)){CloseHandle(h);return 14;}FlushFileBuffers(h);CloseHandle(h);
  m.lfMenuFont.lfHeight=-11;m.lfMenuFont.lfWeight=400;m.lfMenuFont.lfCharSet=DEFAULT_CHARSET;lstrcpyW(m.lfMenuFont.lfFaceName,L"Tahoma");
 }else if(!strcmp(mode,"restore")){
  h=CreateFileW(args[2],GENERIC_READ,FILE_SHARE_READ,0,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,0);if(h==INVALID_HANDLE_VALUE)return 15;
  if(GetFileSize(h,0)!=sizeof(m)||!ReadFile(h,&m,sizeof(m),&n,0)||n!=sizeof(m)||m.cbSize!=sizeof(m)){CloseHandle(h);return 16;}CloseHandle(h);
 }else return 2;
 if(!original_absent())return 12;
 if(!SystemParametersInfoW(SPI_SETNONCLIENTMETRICS,sizeof(m),&m,SPIF_UPDATEINIFILE|SPIF_SENDCHANGE)){rc=17;err=GetLastError();}
 ZeroMemory(&m,sizeof(m));m.cbSize=sizeof(m);if(!SystemParametersInfoW(SPI_GETNONCLIENTMETRICS,sizeof(m),&m,0)){rc=18;err=GetLastError();}
 describe(out,mode,&m,rc,err);return rc;
}
void WINAPI fixture_entry(void){int argc=0,rc=2;wchar_t**args=CommandLineToArgvW(GetCommandLineW(),&argc);if(args){rc=run(argc,args);LocalFree(args);}ExitProcess(rc);}
unsigned long _tls_index=0;
