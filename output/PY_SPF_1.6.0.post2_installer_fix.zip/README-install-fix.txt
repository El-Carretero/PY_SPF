Extract into the existing PY_SPF project folder and replace files.
Run install.bat again. Keep existing Python and venv folders.
